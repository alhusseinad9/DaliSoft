# خطوتان يدويتان فقط، ثم تشغيل كامل

أعاد `setup.sh` تلقائياً 90% من الإعداد. ناقص فقط تعديلان صغيران في ملفين
(موجودان الآن بعد تشغيل Setup — لم يكونا موجودين قبله)، لأن هذين التعديلين
تغييرات دقيقة داخل مصفوفات PHP، وأي سكربت تلقائي قد يُفسدهما بصمت — أأمن أنك
تلصقهما بنفسك.

## 1) `config/permission.php`

ابحث عن:
```php
'teams' => false,
```
غيّرها إلى:
```php
'teams' => true,
```

ثم ابحث داخل `'column_names' => [ ... ]` عن السطر الخاص بـ `team_foreign_key`
(أو أضفه إن لم يكن موجوداً) ليصبح:
```php
'team_foreign_key' => 'business_id',
```

## 2) `config/database.php`

داخل `'connections' => [ ... ]`، أضف هذا الاتصال الجديد بجانب `'pgsql'` الموجود
(تُستخدم فقط عند تشغيل الـ Migrations، بصلاحية مالك الجداول):

```php
'pgsql_migrations' => [
    'driver' => 'pgsql',
    'host' => env('DB_HOST', '127.0.0.1'),
    'port' => env('DB_PORT', '5432'),
    'database' => env('DB_DATABASE'),
    'username' => env('DB_MIGRATION_USERNAME'),
    'password' => env('DB_MIGRATION_PASSWORD'),
    'charset' => 'utf8',
    'prefix' => '',
    'search_path' => 'public',
    'sslmode' => 'prefer',
],
```

## 3) انسخ ملفات هذا المشروع فوق هيكل Laravel

`setup.sh` نسخ ملفات Laravel الناقصة *إلينا* (`--ignore-existing`)، فملفاتنا
المخصّصة (`app/`, `database/migrations/`, إلخ) سليمة ولم تُمس. لا حاجة لأي
نسخ إضافي هنا.

## 4) شغّل

في الطرفية (Terminal) داخل Codespace:

```bash
php artisan migrate --database=pgsql_migrations
php artisan db:seed
php artisan test
```

أرسل لي أي سطر خطأ يظهر بالضبط كما هو.

## تشغيل الخادم للتجربة اليدوية (اختياري)

```bash
php artisan serve --host=0.0.0.0 --port=8000
```
Codespaces سيعرض عليك تلقائياً فتح المنفذ 8000 في المتصفح — هذا رابط API
مباشر (`/api/v1/...`)، لا واجهة رسومية بعد.
