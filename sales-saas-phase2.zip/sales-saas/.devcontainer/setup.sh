#!/usr/bin/env bash
# يُشغَّل تلقائياً مرة واحدة فقط عند أول فتح لهذا الريبو داخل GitHub Codespaces.
# يبني حوله هيكل Laravel كاملاً، ويجهّز قاعدتي بيانات PostgreSQL ومستخدميها،
# دون أن يمسّ أي ملف من ملفاتنا المخصّصة (app/, database/migrations/, config/saas.php, ...).
set -euo pipefail
cd /workspace

if [ -f artisan ]; then
  echo "==> الإعداد منفَّذ مسبقاً (يوجد ملف artisan). لا شيء لفعله."
  exit 0
fi

echo "==> انتظار جاهزية PostgreSQL..."
for i in $(seq 1 30); do
  if PGPASSWORD=postgres psql -h db -U postgres -c '\q' 2>/dev/null; then break; fi
  sleep 2
done

echo "==> إنشاء أدوار وقواعد PostgreSQL (app_owner / app_user)..."
PGPASSWORD=postgres psql -h db -U postgres <<'SQL'
DO $$ BEGIN
  CREATE ROLE app_owner LOGIN PASSWORD 'app_owner_pw' NOSUPERUSER NOBYPASSRLS NOCREATEROLE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE ROLE app_user LOGIN PASSWORD 'app_user_pw' NOSUPERUSER NOBYPASSRLS NOCREATEROLE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
SELECT 'CREATE DATABASE sales_saas OWNER app_owner' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'sales_saas')\gexec
SELECT 'CREATE DATABASE sales_saas_test OWNER app_owner' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'sales_saas_test')\gexec
SQL

for DBNAME in sales_saas sales_saas_test; do
  PGPASSWORD=postgres psql -h db -U postgres -d "$DBNAME" <<SQL
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_user;
ALTER DEFAULT PRIVILEGES FOR ROLE app_owner IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;
ALTER DEFAULT PRIVILEGES FOR ROLE app_owner IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO app_user;
ALTER DEFAULT PRIVILEGES FOR ROLE app_owner IN SCHEMA public GRANT EXECUTE ON FUNCTIONS TO app_user;
SQL
done

echo "==> تثبيت هيكل Laravel في مجلد مؤقت..."
TMP="$(mktemp -d)"
composer create-project laravel/laravel "$TMP/skeleton" "^11.0" --no-interaction

echo "==> نسخ كل ملفات Laravel الأساسية التي لا نملك نسخة مخصّصة منها..."
rsync -a --ignore-existing "$TMP/skeleton"/ /workspace/
rm -rf "$TMP"

echo "==> تثبيت الحزم المطلوبة (Sanctum + Spatie Permission)..."
composer require laravel/sanctum spatie/laravel-permission --no-interaction

echo "==> نشر إعدادات الحزم..."
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider" --no-interaction
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider" --no-interaction

echo "==> ضبط .env لمطابقة هذه البيئة (Codespaces)..."
sed -i \
  -e "s/^DB_CONNECTION=.*/DB_CONNECTION=pgsql/" \
  -e "s/^DB_HOST=.*/DB_HOST=db/" \
  -e "s/^DB_PORT=.*/DB_PORT=5432/" \
  -e "s/^DB_DATABASE=.*/DB_DATABASE=sales_saas/" \
  -e "s/^DB_USERNAME=.*/DB_USERNAME=app_user/" \
  -e "s/^DB_PASSWORD=.*/DB_PASSWORD=app_user_pw/" \
  -e "s/^SESSION_DRIVER=.*/SESSION_DRIVER=redis/" \
  -e "s/^CACHE_STORE=.*/CACHE_STORE=redis/" \
  -e "s/^QUEUE_CONNECTION=.*/QUEUE_CONNECTION=redis/" \
  .env
cat >> .env <<'ENVEOF'

# ==== إضافات هذا المشروع (sales-saas) ====
DB_MIGRATION_USERNAME=app_owner
DB_MIGRATION_PASSWORD=app_owner_pw
REDIS_HOST=redis
HASH_DRIVER=argon2id
SANCTUM_STATEFUL_DOMAINS=localhost:8000
SAAS_TRIAL_PLAN=trial
SAAS_TRIAL_DAYS=14
SAAS_CURRENCY=LYD
ENVEOF

echo ""
echo "=================================================================="
echo "تم تجهيز 90% تلقائياً. بقي خطوتان يدويتان بسيطتان قبل migrate — راجع"
echo ".devcontainer/MANUAL_STEPS.md (مفتوح تلقائياً في المتصفح الجانبي)."
echo "=================================================================="
