# المرحلة 0 — الأساس: Multi-Tenancy والأمان والمخطط الكامل

هذه الحزمة ليست مشروع Laravel كاملاً؛ هي ملفات تُنسخ فوق مشروع Laravel 12 جديد.
السبب: الإطار نفسه وملفات vendor تأتي من Composer، وما هنا هو كل ما كُتب خصيصاً للنظام.

## ما تحتويه

| الجزء | الملفات |
|---|---|
| عزل الأنشطة (4 طبقات) | `app/Core/Tenancy/*`، `2026_01_01_009000_enable_row_level_security.php` |
| المخطط الكامل (كل جداول النسخة الأولى) | `database/migrations/*` |
| الصلاحيات والأدوار الافتراضية | `app/Core/Auth/PermissionRegistry.php` |
| إنشاء نشاط جديد | `app/Core/Auth/ProvisionBusiness.php` |
| تسجيل الدخول وتبديل النشاط | `app/Core/Auth/Http/AuthController.php` |
| سجل التدقيق | `app/Core/Audit/*` |
| ترقيم الوثائق بلا تكرار ولا فجوات | `app/Core/Sequences/SequenceService.php` |
| منع تكرار العمليات (Idempotency) | `app/Core/Idempotency/EnsureIdempotency.php` |
| تشغيل/إيقاف الـ Modules | `app/Core/Modules/*` |
| Module العملاء (القالب المرجعي لبقية الـ Modules) | `app/Modules/Customers/*` |
| اختبارات العزل | `tests/Feature/TenantIsolation/*` |

## طبقات العزل

1. **ResolveTenant:** النشاط يُقرأ من جلسة المستخدم فقط، مع التحقق من العضوية. لا يُقبل `business_id` من الطلب.
2. **BelongsToBusiness + BusinessScope:** كل استعلام Eloquent محصور تلقائياً. بدون نشاط محدد يُرمى استثناء (fail closed).
3. **Composite Foreign Keys:** `(business_id, customer_id) → customers(business_id, id)`. قاعدة البيانات ترفض ربط سجل بسجل من نشاط آخر.
4. **PostgreSQL RLS:** حتى الاستعلامات الخام (`DB::table`) لا ترى إلا صفوف النشاط الحالي.

إضافة لذلك: جداول الدفتر وحركة المخزون وسجل التدقيق **Append-only** بـ Trigger في قاعدة البيانات.

## التثبيت

المتطلبات: PHP 8.3 مع امتدادات `pdo_pgsql` و`bcmath` و`redis`، وPostgreSQL 16، وRedis.

```bash
composer create-project laravel/laravel sales-saas
cd sales-saas
composer require laravel/sanctum spatie/laravel-permission
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
```

**1. عدّل `config/permission.php`** (قبل أول migrate):

```php
'teams' => true,
'column_names' => [
    // ...
    'team_foreign_key' => 'business_id',
],
```

**2. انسخ ملفات هذه الحزمة فوق المشروع** (استبدل الملفات الموجودة بنفس الاسم، بما فيها `bootstrap/app.php` وملف users migration و`phpunit.xml`).

**3. أضف اتصال الـ Migrations في `config/database.php`** داخل `connections`:

```php
'pgsql_migrations' => [
    'driver' => 'pgsql',
    'host' => env('DB_HOST', '127.0.0.1'),
    'port' => env('DB_PORT', '5432'),
    'database' => env('DB_DATABASE'),
    'username' => env('DB_MIGRATION_USERNAME'),
    'password' => env('DB_MIGRATION_PASSWORD'),
    'charset' => 'utf8',
    'prefix' => '',
    'search_path' => 'public',
    'sslmode' => 'prefer',
],
```

**4. أنشئ أدوار قاعدة البيانات** (مرة واحدة، كـ postgres):

```bash
psql -U postgres -f docs/sql/roles.sql
```

> مهم جداً: لا تشغّل التطبيق أو الاختبارات بمستخدم `postgres`. الـ Superuser يتجاوز RLS، وستُتخطّى اختبارات RLS تلقائياً مع رسالة توضيحية.

**5. انسخ القيم من `.env.example.additions` إلى `.env`.**

**6. شغّل:**

```bash
php artisan migrate --database=pgsql_migrations
php artisan db:seed
php artisan test --filter=TenantIsolation
```

## ملاحظات تشغيلية

- التطبيق يعمل بمستخدم `app_user` (بلا ملكية الجداول)، والـ Migrations تعمل بـ `app_owner`.
- إن استخدمت PgBouncer لاحقاً فاستخدم وضع `session` وليس `transaction`، لأن `app.business_id` إعداد على مستوى الجلسة.
- أي Job يعمل على بيانات نشاط يستخدم `TenantAware` ويستدعي `$this->captureTenant()` في الـ constructor.
- أي Module جديد: Model يستخدم `BelongsToBusiness` و`HasPublicId` و`Auditable`، وMigration يستخدم `businessId()` و`tenantForeign()` و`tenantKey()`، ويُضاف الجدول إلى قائمة RLS في migration جديد.

## المرحلة التالية (1)

المنتجات والتصنيفات، والفواتير (`IssueInvoice` و`VoidInvoice`)، والدفعات مع التوزيع على الفواتير، وكشف الحساب، واللوحة الرئيسية، والطباعة الحرارية وA4، وهيكل الواجهة (Vue 3 + PWA + RTL).

---

## المرحلة 1 — الفواتير، التحصيل، المشتريات، الموردين، المرتجعات

هذه المرحلة تترجم كل منطق الدقة المحاسبية الذي رُوجع وصُحِّح عبر عشرات الجولات
في معاينة تفاعلية (HTML/JS) سابقة، إلى كود Laravel حقيقي. المعاينة لم تعد
مرجعاً — هذا الكود هو المرجع الآن.

### الوحدات المضافة

| الوحدة | الملفات الأساسية |
|---|---|
| الموردون | `app/Modules/Suppliers/*` |
| الفواتير (بيع) | `app/Modules/Invoicing/*` — `IssueInvoice`, `VoidInvoice` |
| التحصيل | `app/Modules/Payments/*` — `RecordPayment` |
| فواتير الشراء | `app/Modules/Purchasing/*` — `IssuePurchaseInvoice`, `VoidPurchaseInvoice` |
| دفعات الموردين | `app/Modules/SupplierPayments/*` — `RecordSupplierPayment` |
| المرتجعات | `app/Modules/Returns/*` — `CreateSalesReturn` |
| المخزون المشترك | `app/Modules/Inventory/*` — `StockService` (نقطة واحدة لكل حركة مخزون) |
| الحساب الآمن | `app/Core/Money/Money.php` — bcmath بدل float، يمنع أخطاء مثل "متبقي 0.0000000001" |

### القرارات المحاسبية الحرجة المطبَّقة هنا (مو موجودة في المعاينة الأولى أصلاً)

1. **التحصيل يُوزَّع فعلياً على الفواتير** (`RecordPayment`) — الأقدم أولاً (FIFO)،
   عبر جدول `payment_allocations` الذي كان موجوداً بالمخطط من المرحلة 0 لكن لم
   يُستخدم. أي فائض يتجاوز كل الفواتير يبقى محسوباً عبر `Payment::unallocatedAmount()`
   بدل أن يُفقد أو يُحسب مرتين.
2. **الإلغاء يحفظ `paid_amount` الحقيقي دائماً** (`VoidInvoice`) — ولا يكتب
   فوقه أبداً. المستخدم يُسأل صراحة: المبلغ المحصَّل يتحول لرصيد دائن للعميل،
   أو أُرجع نقداً خارج النظام؟ هذا قرار تجاري، لا افتراض آلي.
3. **تكلفة الصنف تُحفظ وقت البيع** (`invoice_items.unit_cost`) — موجودة بالمخطط
   من المرحلة 0 أيضاً، والآن `IssueInvoice` يملأها فعلياً من `product.cost_price`
   وقت الإصدار، فلا يتأثر الربح التاريخي بتغيّر التكلفة لاحقاً.
4. **رصيد المورد بنفس اتجاه رصيد العميل بالضبط** — "عليه" و"له" لهما نفس
   المعنى لأي طرف، بعد ما اكتُشف أن النموذج الأولي استخدم اتجاهاً معكوساً للمورد.
5. **لا بيع بكمية أكبر من المتوفر بصمت** — `StockService::wouldGoNegative()`
   يُستخدم قبل أي خصم، ويرمي `InsufficientStockException` قابلة للتجاوز صراحة
   (`allow_negative_stock`)، بدل ما ينزل المخزون سالباً بلا تحذير.
6. **المرتجع محدود بما بيع فعلياً ناقص ما أُرجع سابقاً** — يستحيل إرجاع كمية
   أكبر من المتاح، والربح يُحتسب بعد استبعاد الكميات المرتجعة تلقائياً.

### الاختبارات

`tests/Feature/Invoicing/InvoicePrecisionTest.php` يثبّت بالضبط الأخطاء
المحاسبية المذكورة أعلاه عبر 10 اختبارات (تحصيل FIFO، فائض غير مفقود، حفظ
المدفوع الحقيقي عند الإلغاء بكلا الخيارين، ثبات التكلفة التاريخية، حد المرتجع،
الحد الائتماني مع التجاوز الصريح، منع البيع السالب مع التجاوز الصريح).

`tests/Feature/TenantIsolation/SupplierPurchasingIsolationTest.php` يثبّت أن
الوحدتين الجديدتين تخضعان لنفس عزل الأنشطة المطبَّق على بقية النظام.

> **تنبيه مهم:** لم تُشغَّل هذه الاختبارات فعلياً — بيئة إعداد هذه الحزمة لا
> تملك PHP ولا اتصال إنترنت لتثبيته. رُوجعت الملفات يدوياً (توازن الأقواس،
> تطابق كل `use` مع تعريف فعلي، تطابق PSR-4 بين المسار والـ namespace) لأقصى
> درجة ممكنة بلا تشغيل حقيقي. **شغّل `php artisan test` بنفسك أولاً وأرسل لي
> أي خطأ يظهر.**

### إعداد إضافي قبل أول تشغيل

أضف الحقل الجديد لإعدادات الوحدات الافتراضية — تم تغيير `inventory` إلى `true`
افتراضياً في `config/saas.php` (كان `false` في المرحلة 0)، لأن معظم الأنشطة
الصغيرة تتوقع تتبع الكمية من أول يوم.

### ما لم يُبنَ بعد (مؤجَّل للمرحلة 2 عمداً)

- واجهة HTTP كاملة لـ Catalog (المنتجات) — المخطط والـ Model جاهزان من المرحلة 0،
  لكن لا Action/Controller حقيقي بعد.
- شاشة المخزون المستقلة (نظرة عامة + حركات)، المصروفات، التقارير، الإعدادات،
  الموظفون — موجودة بالمخطط، لا HTTP layer لها بعد.
- اختبارات HTTP كاملة (Request/Response) للوحدات الجديدة — الاختبارات الحالية
  تستدعي الـ Actions مباشرة، وهذا يثبّت صحة المنطق لكن لا يثبّت صحة التحقق من
  المدخلات (Validation) أو رموز الاستجابة HTTP.
- أي واجهة أمامية (Frontend) — كل هذا Backend API فقط حتى الآن.

---

## المرحلة 2 — المنتجات، المخزون، المصروفات، الموظفون، التقارير، الإعدادات

أكملت كل ما أُجِّل عمداً من المرحلة 1. النظام الآن يغطي كل الوحدات المذكورة
في المواصفة الأصلية بأول هذا المستند.

### الوحدات المضافة

| الوحدة | أهم ما فيها |
|---|---|
| Catalog (منتجات) | `CreateProduct`/`UpdateProduct` — الكمية الابتدائية تُسجَّل كحركة مخزون من النوع `opening`، و`stock_qty` ليس Mass-Assignable أبداً |
| تسوية المخزون | `AdjustStock` (`app/Modules/Inventory/Actions`) — أي تصحيح يدوي للكمية يُسجَّل كحركة `adjustment` موثَّقة، بدل الكتابة فوق الرقم بصمت |
| نظرة عامة على المخزون | `InventoryController` — الكميات الحالية، تنبيه النقص، آخر 20 حركة؛ يرفض الطلب بوضوح إن كانت وحدة المخزون مطفأة |
| المصروفات | CRUD كامل + إلغاء (`VoidExpense`) بدل حذف نهائي — خلاف النموذج الأولي الذي لم يسمح بتعديل أو حذف مصروف بعد تسجيله |
| الموظفون | CRUD كامل؛ الراتب يظهر فقط لمن يملك `reports.financial.view` |
| التقارير | `ReportsController` — نفس احتياطات الدقة في كل مكان آخر: يستبعد الفواتير والمرتجعات الملغاة، يستخدم `Payment::unallocatedAmount()` بدل جمع الدفعات مرتين، والربح يعتمد على `unit_cost` وقت البيع |
| الإعدادات | عرض/تعديل بيانات النشاط، وتشغيل/إيقاف أي Module (`BusinessModule`) |

### قرار اتُّخذ بالنيابة عنك

**غيّرت `inventory` في `config/saas.php` من `false` إلى `true`** كحالة افتراضية
لأي نشاط جديد — معظم الأنشطة الصغيرة (مخبز، محل، موزّع) تتوقع تتبع الكمية من
أول يوم؛ من لا يحتاجها يطفئها بنفسه من `/settings/modules`.

### مراجعة الصياغة

أعدت فحص الريبو **كاملاً** (175 ملف PHP) بعد إضافة هذه المرحلة: توازن الأقواس،
تطابق كل `use` مع تعريف فعلي (132 صنف)، تطابق كل مسار مع الـ namespace (PSR-4)،
ولا تكرار بأسماء أي من الـ 47 route الجديدة. **كلها نظيفة.** هذا يمسك أخطاء
الصياغة فقط — لم تُشغَّل الاختبارات فعلياً بعد (لا PHP في بيئة الإعداد هذه).

### ما زال غير مبني

- اختبارات HTTP/Feature لوحدات هذه المرحلة تحديداً (Catalog, Expenses, Employees,
  Reports, Settings) — موجودة فقط لوحدات المرحلة 1 الحرجة محاسبياً.
- أي Frontend. كل هذا Backend API حتى الآن.
- لوحة إدارة المنصة (Platform Admin) المذكورة بالمواصفة الأصلية — القسم 20.

---

## كيف تشغّله (من المتصفح، بلا جهاز كمبيوتر)

أضفت إعداد **GitHub Codespaces** كامل (`.devcontainer/`) — بيئة Linux حقيقية
بـ PHP وPostgreSQL وRedis جاهزة تلقائياً، تفتح وتشتغل بالكامل من متصفح
الهاتف، بلا تثبيت أي شيء محلياً.

### الخطوات

1. أنشئ مستودع (repo) جديد خاص على GitHub، وارفع محتوى هذا الملف المضغوط إليه
   كاملاً (المجلد `sales-saas/` بكل ما فيه، بما فيها `.devcontainer/` المخفي).
2. من صفحة المستودع على GitHub (بالمتصفح): **Code ‹ Codespaces ‹ Create
   codespace on main**.
3. انتظر دقيقتين تقريباً — Codespaces يبني البيئة تلقائياً ويشغّل
   `setup.sh` بنفسه (يجهّز قواعد PostgreSQL والأدوار وهيكل Laravel كاملاً).
4. افتح `.devcontainer/MANUAL_STEPS.md` من قائمة الملفات على اليسار، واتبع
   الخطوتين الصغيرتين فيه (تعديلان بسيطان في ملفي إعدادات)، ثم شغّل الأوامر
   المذكورة فيه آخرها:
   ```bash
   php artisan test
   ```
5. أرسل لي أي خطأ يظهر، بالضبط كما طلعت — هذا أول تشغيل حقيقي للكود كله.

### لماذا هذا الخيار بالذات

كل العمل يصير داخل طرفية (Terminal) حقيقية مفتوحة في تبويب متصفح — نفس فكرة
GitHub Actions اللي استخدمتها لنشر Pronto، لكن هنا تفاعلية ومباشرة. لا حاجة
لأي تطبيق إضافي ولا جهاز كمبيوتر.

### بعد ما يشتغل وتتأكد منه

هذا للتطوير والاختبار فقط. للتشغيل الفعلي مع عملاء حقيقيين، الخطة الأصلية
(VPS واحد يستضيف Laravel + PostgreSQL + Redis، كما في قسم "خطة النشر" بأول
هذا المستند) تبقى صحيحة — ننتقل لها بعد ما نتأكد إن كل الاختبارات تعدي هنا.
