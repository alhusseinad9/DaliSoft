<?php

declare(strict_types=1);

namespace App\Core\Audit;

use App\Core\Tenancy\TenantContext;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

final class AuditLogger
{
    /**
     * تسجيل تغيير على Model.
     *
     * @param  array<string, mixed>  $old
     * @param  array<string, mixed>  $new
     * @param  array<string, mixed>  $meta
     */
    public static function forModel(string $action, Model $model, array $old = [], array $new = [], array $meta = []): void
    {
        self::write($action, $model, $old, $new, $meta);
    }

    /**
     * تسجيل عملية صريحة، مثل: invoice.voided أو payment.recorded أو auth.business_switched.
     *
     * @param  array<string, mixed>  $meta
     */
    public static function action(string $action, ?Model $model = null, array $meta = []): void
    {
        self::write($action, $model, [], [], $meta);
    }

    private static function write(string $action, ?Model $model, array $old, array $new, array $meta): void
    {
        // الكيانات على مستوى المنصة (مثل Business نفسه) تُسجّل في سجل المنصة لاحقاً.
        if (! app(TenantContext::class)->hasTenant()) {
            return;
        }

        $request = request();

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => $action,
            'auditable_type' => $model?->getMorphClass(),
            'auditable_id' => $model?->getKey(),
            'old_values' => $old === [] ? null : $old,
            'new_values' => $new === [] ? null : $new,
            'meta' => $meta === [] ? null : $meta,
            'ip' => $request->ip(),
            'user_agent' => Str::limit((string) $request->userAgent(), 250, ''),
        ]);
    }
}
