<?php

declare(strict_types=1);

namespace App\Core\Audit;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;

/**
 * يسجّل تلقائياً: الإنشاء، والتعديل (القيم القديمة والجديدة للحقول المتغيرة فقط)، والحذف، والاستعادة.
 * الحقول المخفية ($hidden) و$auditExclude لا تُسجّل.
 */
trait Auditable
{
    public static function bootAuditable(): void
    {
        static::created(function (Model $model): void {
            AuditLogger::forModel('created', $model, [], $model->auditPayload($model->getAttributes()));
        });

        static::updated(function (Model $model): void {
            $changes = $model->auditPayload($model->getChanges());

            if ($changes === []) {
                return;
            }

            $old = Arr::only($model->getRawOriginal(), array_keys($changes));
            AuditLogger::forModel('updated', $model, $old, $changes);
        });

        static::deleted(function (Model $model): void {
            AuditLogger::forModel('deleted', $model, $model->auditPayload($model->getAttributes()));
        });

        if (method_exists(static::class, 'restored')) {
            static::restored(function (Model $model): void {
                AuditLogger::forModel('restored', $model);
            });
        }
    }

    /**
     * @param  array<string, mixed>  $attributes
     * @return array<string, mixed>
     */
    public function auditPayload(array $attributes): array
    {
        $exclude = array_merge(
            $this->getHidden(),
            property_exists($this, 'auditExclude') ? $this->auditExclude : [],
            ['created_at', 'updated_at']
        );

        return Arr::except($attributes, $exclude);
    }
}
