<?php

declare(strict_types=1);

namespace App\Core\Auth\Http;

use App\Core\Audit\AuditLogger;
use App\Core\Auth\Http\Requests\LoginRequest;
use App\Core\Auth\PermissionRegistry;
use App\Core\Tenancy\TenantContext;
use App\Models\Business;
use App\Models\BusinessUser;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class AuthController
{
    public function __construct(private readonly TenantContext $tenant)
    {
    }

    public function login(LoginRequest $request): JsonResponse
    {
        $login = Str::lower(trim((string) $request->input('login')));
        $field = filter_var($login, FILTER_VALIDATE_EMAIL) ? 'email' : 'phone';

        $credentials = [$field => $login, 'password' => (string) $request->input('password'), 'is_active' => true];

        if (! Auth::guard('web')->attempt($credentials, $request->boolean('remember'))) {
            // رسالة موحّدة: لا نكشف إن كان الحساب موجوداً.
            throw ValidationException::withMessages(['login' => 'بيانات الدخول غير صحيحة.']);
        }

        $request->session()->regenerate();

        /** @var User $user */
        $user = $request->user();
        $user->forceFill(['last_login_at' => now()])->saveQuietly();

        $activeIds = $user->activeMemberships()->pluck('business_id');

        if ($activeIds->count() === 1) {
            $request->session()->put('current_business_id', (int) $activeIds->first());
        }

        return $this->me($request);
    }

    public function me(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $currentId = $request->session()->get('current_business_id');

        $memberships = BusinessUser::query()
            ->with('business:id,public_id,name,status,currency')
            ->where('user_id', $user->id)
            ->where('status', BusinessUser::STATUS_ACTIVE)
            ->whereHas('business', fn ($q) => $q->where('status', Business::STATUS_ACTIVE))
            ->get();

        $current = $memberships->firstWhere('business_id', $currentId);
        $roles = [];
        $permissions = [];

        if ($current !== null) {
            $this->tenant->runAs((int) $current->business_id, function () use ($user, &$roles, &$permissions): void {
                $user->unsetRelation('roles')->unsetRelation('permissions');
                $roles = $user->getRoleNames()->values()->all();
                $permissions = in_array('owner', $roles, true)
                    ? PermissionRegistry::all()
                    : $user->getAllPermissions()->pluck('name')->values()->all();
            });
        }

        return response()->json(['data' => [
            'user' => [
                'id' => $user->public_id,
                'name' => $user->name,
                'email' => $user->email,
                'phone' => $user->phone,
            ],
            'businesses' => $memberships->map(fn (BusinessUser $m) => [
                'id' => $m->business->public_id,
                'name' => $m->business->name,
                'currency' => $m->business->currency,
            ])->values(),
            'current_business' => $current?->business->public_id,
            'roles' => $roles,
            'permissions' => $permissions,
        ]]);
    }

    public function switchBusiness(Request $request): JsonResponse
    {
        $data = $request->validate(['business' => ['required', 'string', 'size:26']]);

        $membership = BusinessUser::query()
            ->where('user_id', $request->user()->getAuthIdentifier())
            ->where('status', BusinessUser::STATUS_ACTIVE)
            ->whereHas('business', fn ($q) => $q
                ->where('public_id', $data['business'])
                ->where('status', Business::STATUS_ACTIVE))
            ->first();

        if ($membership === null) {
            return response()->json(['message' => 'لا تملك صلاحية الوصول إلى هذا النشاط.', 'code' => 'business_access_denied'], 403);
        }

        $request->session()->put('current_business_id', (int) $membership->business_id);

        $this->tenant->runAs((int) $membership->business_id, fn () => AuditLogger::action('auth.business_switched'));

        return $this->me($request);
    }

    public function logout(Request $request): Response
    {
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->noContent();
    }
}
