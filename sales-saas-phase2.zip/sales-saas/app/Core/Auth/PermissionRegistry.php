<?php

declare(strict_types=1);

namespace App\Core\Auth;

use Illuminate\Support\Str;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

/**
 * مصدر واحد لكل الصلاحيات والأدوار الافتراضية.
 * الصيغة: resource.action — مثل invoices.create
 */
final class PermissionRegistry
{
    public const GUARD = 'web';

    public const ACTIONS = ['view', 'create', 'edit', 'delete', 'print', 'export'];

    public const RESOURCES = [
        'customers', 'suppliers', 'products', 'categories', 'orders',
        'invoices', 'payments', 'purchase_invoices', 'supplier_payments', 'returns',
        'inventory', 'expenses', 'employees', 'reports', 'users', 'roles', 'settings', 'audit_logs',
    ];

    /** صلاحيات حساسة منفصلة عن CRUD */
    public const SPECIAL = [
        'records.view_all',               // رؤية سجلات كل الموظفين، وليس ما أنشأه المستخدم فقط
        'invoices.void',
        'invoices.edit_price',
        'payments.void',
        'purchase_invoices.void',
        'customers.exceed_credit_limit',
        'inventory.adjust',
        'reports.financial.view',
        'reports.profit.view',
        'subscription.manage',
    ];

    /** @return list<string> */
    public static function all(): array
    {
        $permissions = [];

        foreach (self::RESOURCES as $resource) {
            foreach (self::ACTIONS as $action) {
                $permissions[] = "{$resource}.{$action}";
            }
        }

        return array_values(array_merge($permissions, self::SPECIAL));
    }

    /** @return array<string, list<string>> */
    public static function defaultRoles(): array
    {
        $all = self::all();

        $manager = array_values(array_filter($all, fn (string $p): bool =>
            ! Str::startsWith($p, ['users.', 'roles.', 'settings.', 'audit_logs.', 'subscription.'])
            && $p !== 'reports.profit.view'
        ));

        return [
            'owner' => $all,
            'admin' => array_values(array_diff($all, ['subscription.manage'])),
            'manager' => $manager,
            'sales' => [
                'customers.view', 'customers.create', 'customers.edit', 'customers.print',
                'products.view', 'categories.view',
                'orders.view', 'orders.create', 'orders.edit', 'orders.print',
                'invoices.view', 'invoices.create', 'invoices.print',
                'payments.view', 'payments.create', 'payments.print',
            ],
            'accountant' => [
                'customers.view', 'customers.print', 'customers.export',
                'products.view',
                'invoices.view', 'invoices.print', 'invoices.export',
                'payments.view', 'payments.create', 'payments.print', 'payments.export', 'payments.void',
                'returns.view',
                'expenses.view', 'expenses.create', 'expenses.edit', 'expenses.delete', 'expenses.print', 'expenses.export',
                'reports.view', 'reports.print', 'reports.export',
                'reports.financial.view', 'reports.profit.view', 'records.view_all',
            ],
        ];
    }

    /** إنشاء أي صلاحية ناقصة (آمن للتكرار). */
    public static function sync(): void
    {
        foreach (self::all() as $name) {
            Permission::findOrCreate($name, self::GUARD);
        }

        app(PermissionRegistrar::class)->forgetCachedPermissions();
    }
}
