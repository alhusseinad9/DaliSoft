<?php

declare(strict_types=1);

namespace App\Core\Auth;

use App\Core\Modules\BusinessModule;
use App\Core\Tenancy\TenantContext;
use App\Models\Business;
use App\Models\BusinessUser;
use App\Models\User;
use App\Modules\Catalog\Models\Unit;
use App\Modules\Expenses\Models\ExpenseCategory;
use App\Platform\Models\Plan;
use App\Platform\Models\Subscription;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

/**
 * إنشاء نشاط تجاري جديد بالكامل في معاملة واحدة:
 * النشاط، عضوية المالك، الوحدات وفئات المصروفات الافتراضية،
 * الـ Modules، الأدوار الافتراضية، والفترة التجريبية.
 */
final class ProvisionBusiness
{
    public function __construct(private readonly TenantContext $tenant)
    {
    }

    /**
     * @param  array{name: string, currency: string, timezone: string, phone?: string, address?: string}  $data
     */
    public function handle(User $owner, array $data): Business
    {
        PermissionRegistry::sync();

        return DB::transaction(function () use ($owner, $data): Business {
            $business = new Business(Arr::only($data, ['name', 'phone', 'address', 'currency', 'timezone']));
            $business->forceFill(['status' => Business::STATUS_ACTIVE])->save();

            BusinessUser::create([
                'business_id' => $business->id,
                'user_id' => $owner->id,
                'status' => BusinessUser::STATUS_ACTIVE,
                'joined_at' => now(),
            ]);

            $this->tenant->runAs($business->id, function () use ($owner): void {
                foreach (config('saas.default_units') as $name) {
                    Unit::create(['name' => $name, 'is_system' => true]);
                }

                foreach (config('saas.default_expense_categories') as $name) {
                    ExpenseCategory::create(['name' => $name, 'is_system' => true]);
                }

                foreach (config('saas.modules') as $module => $enabled) {
                    BusinessModule::create(['module' => $module, 'enabled' => $enabled]);
                }

                foreach (PermissionRegistry::defaultRoles() as $roleName => $permissions) {
                    Role::create(['name' => $roleName, 'guard_name' => PermissionRegistry::GUARD])
                        ->syncPermissions($permissions);
                }

                $owner->unsetRelation('roles')->assignRole('owner');
            });

            $this->startTrial($business);

            return $business;
        });
    }

    private function startTrial(Business $business): void
    {
        $plan = Plan::query()->where('code', config('saas.trial_plan'))->first();

        if ($plan === null) {
            return;
        }

        Subscription::create([
            'business_id' => $business->id,
            'plan_id' => $plan->id,
            'status' => Subscription::STATUS_TRIAL,
            'starts_at' => now(),
            'ends_at' => now()->addDays((int) config('saas.trial_days')),
        ]);
    }
}
