<?php

declare(strict_types=1);

namespace App\Core\Idempotency;

use App\Core\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

/**
 * يمنع تكرار العمليات المالية عند الضغط مرتين أو إعادة الإرسال بعد انقطاع الشبكة.
 * الواجهة ترسل Idempotency-Key فريداً لكل محاولة إنشاء (فاتورة، دفعة...).
 * - نفس المفتاح ونفس البيانات بعد النجاح  → تُعاد الاستجابة المحفوظة دون تنفيذ جديد.
 * - نفس المفتاح وبيانات مختلفة           → 422.
 * - الطلب الأول ما زال قيد التنفيذ        → 409.
 */
final class EnsureIdempotency
{
    public function handle(Request $request, Closure $next): Response
    {
        $key = (string) $request->header('Idempotency-Key', '');

        if (preg_match('/^[A-Za-z0-9_\-]{8,100}$/', $key) !== 1) {
            return response()->json([
                'message' => 'ترويسة Idempotency-Key مطلوبة وبصيغة صحيحة.',
                'code' => 'idempotency_key_required',
            ], 400);
        }

        $businessId = app(TenantContext::class)->requireId();
        $userId = (int) $request->user()->getAuthIdentifier();
        $hash = hash('sha256', $request->method().'|'.$request->path().'|'.json_encode($request->all()));
        $now = now();

        $inserted = DB::table('idempotency_keys')->insertOrIgnore([
            'business_id' => $businessId,
            'user_id' => $userId,
            'key' => $key,
            'request_hash' => $hash,
            'status' => 'processing',
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $record = fn () => DB::table('idempotency_keys')
            ->where('business_id', $businessId)
            ->where('user_id', $userId)
            ->where('key', $key);

        if ($inserted === 0) {
            $existing = $record()->first();

            if ($existing === null || $existing->status !== 'completed') {
                return response()->json(['message' => 'الطلب قيد المعالجة.', 'code' => 'request_in_progress'], 409);
            }

            if (! hash_equals($existing->request_hash, $hash)) {
                return response()->json(['message' => 'تم استخدام هذا المفتاح لطلب مختلف.', 'code' => 'idempotency_key_reused'], 422);
            }

            return response((string) $existing->response_body, (int) $existing->response_code, [
                'Content-Type' => 'application/json',
                'Idempotent-Replay' => 'true',
            ]);
        }

        $response = $next($request);

        if ($response->isSuccessful()) {
            $record()->update([
                'status' => 'completed',
                'response_code' => $response->getStatusCode(),
                'response_body' => $response->getContent(),
                'updated_at' => now(),
            ]);
        } else {
            // الفشل لا يُحفظ: يمكن إعادة المحاولة بنفس المفتاح.
            $record()->delete();
        }

        return $response;
    }
}
