<?php

declare(strict_types=1);

namespace App\Core\Modules;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;

class BusinessModule extends Model
{
    use BelongsToBusiness;

    protected $fillable = ['module', 'enabled'];

    protected function casts(): array
    {
        return ['enabled' => 'boolean'];
    }

    public static function isEnabled(string $module): bool
    {
        return (bool) static::query()->where('module', $module)->value('enabled');
    }
}
