<?php

declare(strict_types=1);

namespace App\Core\Modules;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** الاستخدام في المسارات: ->middleware('module:inventory') */
final class EnsureModuleEnabled
{
    public function handle(Request $request, Closure $next, string $module): Response
    {
        if (! BusinessModule::isEnabled($module)) {
            return response()->json([
                'message' => 'هذه الوحدة غير مفعّلة لهذا النشاط.',
                'code' => 'module_disabled',
                'module' => $module,
            ], 403);
        }

        return $next($request);
    }
}
