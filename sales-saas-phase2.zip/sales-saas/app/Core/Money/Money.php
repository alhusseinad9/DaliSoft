<?php

declare(strict_types=1);

namespace App\Core\Money;

/**
 * مساعد حسابي بسيط: يمنع انحراف الفاصلة العائمة الذي كان يجعل فاتورة
 * مدفوعة بالكامل تبدو وكأنها "متبقي 0.0000000001" بسبب مقارنات float مباشرة.
 * كل القيم المالية في النظام مقرّبة لثلاث خانات عشرية دائماً عبر bcmath.
 */
final class Money
{
    public const SCALE = 3;

    public static function add(string|float|int $a, string|float|int $b): string
    {
        return bcadd((string) $a, (string) $b, self::SCALE);
    }

    public static function sub(string|float|int $a, string|float|int $b): string
    {
        return bcsub((string) $a, (string) $b, self::SCALE);
    }

    public static function mul(string|float|int $a, string|float|int $b): string
    {
        return bcmul((string) $a, (string) $b, self::SCALE);
    }

    public static function max(string|float|int $a, string|float|int $b): string
    {
        return bccomp((string) $a, (string) $b, self::SCALE) >= 0 ? (string) $a : (string) $b;
    }

    public static function isZero(string|float|int $a): bool
    {
        return bccomp((string) $a, '0', self::SCALE) === 0;
    }

    public static function isPositive(string|float|int $a): bool
    {
        return bccomp((string) $a, '0', self::SCALE) > 0;
    }

    public static function min(string|float|int $a, string|float|int $b): string
    {
        return bccomp((string) $a, (string) $b, self::SCALE) <= 0 ? (string) $a : (string) $b;
    }
}
