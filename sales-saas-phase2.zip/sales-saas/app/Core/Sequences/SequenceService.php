<?php

declare(strict_types=1);

namespace App\Core\Sequences;

use App\Core\Tenancy\TenantContext;
use Illuminate\Support\Facades\DB;
use LogicException;

/**
 * ترقيم الوثائق (فواتير، دفعات، طلبات...) لكل نشاط على حدة.
 *
 * يجب استدعاؤه داخل نفس المعاملة التي تنشئ الوثيقة:
 * - SELECT ... FOR UPDATE يمنع تكرار الرقم عند التزامن.
 * - إذا فشلت المعاملة يُسترجع الرقم، فلا تحدث فجوات في الترقيم.
 */
final class SequenceService
{
    public function __construct(private readonly TenantContext $tenant)
    {
    }

    public function next(string $type): string
    {
        if (DB::transactionLevel() === 0) {
            throw new LogicException('SequenceService::next() must be called inside a database transaction.');
        }

        $businessId = $this->tenant->requireId();
        $prefix = config("saas.sequences.{$type}");

        if ($prefix === null) {
            throw new LogicException("Unknown sequence type [{$type}].");
        }

        DB::statement(
            'insert into document_sequences (business_id, type, prefix, next_number, padding, created_at, updated_at)
             values (?, ?, ?, 1, 6, now(), now())
             on conflict (business_id, type) do nothing',
            [$businessId, $type, $prefix]
        );

        $row = DB::selectOne(
            'select id, prefix, next_number, padding from document_sequences
             where business_id = ? and type = ? for update',
            [$businessId, $type]
        );

        DB::update(
            'update document_sequences set next_number = next_number + 1, updated_at = now() where id = ?',
            [$row->id]
        );

        return $row->prefix.str_pad((string) $row->next_number, (int) $row->padding, '0', STR_PAD_LEFT);
    }
}
