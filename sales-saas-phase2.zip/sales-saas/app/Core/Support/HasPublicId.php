<?php

declare(strict_types=1);

namespace App\Core\Support;

use Illuminate\Support\Str;

/**
 * معرّف عام (ULID) يظهر في الروابط والـ API بدل الرقم المتسلسل الداخلي،
 * حتى لا يمكن تخمين عدد السجلات أو تعداد المعرّفات.
 */
trait HasPublicId
{
    public static function bootHasPublicId(): void
    {
        static::creating(function ($model): void {
            if (empty($model->public_id)) {
                $model->public_id = (string) Str::ulid();
            }
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }
}
