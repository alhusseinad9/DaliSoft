<?php

declare(strict_types=1);

namespace App\Core\Tenancy\Concerns;

use App\Core\Tenancy\Exceptions\TenantViolationException;
use App\Core\Tenancy\Scopes\BusinessScope;
use App\Core\Tenancy\TenantContext;
use App\Models\Business;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * يُستخدم في كل Model تشغيلي.
 * - يحصر كل الاستعلامات في النشاط الحالي.
 * - يملأ business_id تلقائياً عند الإنشاء ويرفض أي قيمة مختلفة.
 * - يمنع نقل السجل إلى نشاط آخر.
 */
trait BelongsToBusiness
{
    public static function bootBelongsToBusiness(): void
    {
        static::addGlobalScope(new BusinessScope());

        static::creating(function (Model $model): void {
            $currentId = app(TenantContext::class)->requireId();

            if ($model->getAttribute('business_id') !== null
                && (int) $model->getAttribute('business_id') !== $currentId) {
                throw new TenantViolationException(sprintf(
                    'Attempt to create %s for another business.',
                    $model::class
                ));
            }

            $model->setAttribute('business_id', $currentId);
        });

        static::updating(function (Model $model): void {
            if ($model->isDirty('business_id')) {
                throw new TenantViolationException(sprintf(
                    'business_id of %s cannot be changed.',
                    $model::class
                ));
            }
        });
    }

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }
}
