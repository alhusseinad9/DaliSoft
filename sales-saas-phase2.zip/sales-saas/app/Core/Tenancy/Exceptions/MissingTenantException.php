<?php

declare(strict_types=1);

namespace App\Core\Tenancy\Exceptions;

use RuntimeException;

/** يُرمى عند أي استعلام على بيانات تشغيلية دون تحديد النشاط. النظام يفشل مغلقاً (fail closed). */
final class MissingTenantException extends RuntimeException
{
    public function __construct()
    {
        parent::__construct('No tenant is set for the current context.');
    }
}
