<?php

declare(strict_types=1);

namespace App\Core\Tenancy\Exceptions;

use RuntimeException;

/** محاولة كتابة سجل لنشاط غير النشاط الحالي أو نقله بين الأنشطة. */
final class TenantViolationException extends RuntimeException
{
}
