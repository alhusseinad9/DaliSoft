<?php

declare(strict_types=1);

namespace App\Core\Tenancy\Jobs;

use App\Core\Tenancy\TenantContext;

/**
 * يُضاف لأي Job يعمل على بيانات نشاط:
 *   use TenantAware;  ثم في الـ constructor:  $this->captureTenant();
 */
trait TenantAware
{
    public int $businessId;

    protected function captureTenant(): void
    {
        $this->businessId = app(TenantContext::class)->requireId();
    }

    /** @return array<int, object> */
    public function middleware(): array
    {
        return [new WithTenant($this->businessId)];
    }
}
