<?php

declare(strict_types=1);

namespace App\Core\Tenancy\Jobs;

use App\Core\Tenancy\TenantContext;
use Closure;

/** Job middleware: يشغّل الـ Job داخل النشاط الذي أُرسل منه ثم يعيد السياق. */
final class WithTenant
{
    public function __construct(public readonly int $businessId)
    {
    }

    public function handle(object $job, Closure $next): mixed
    {
        return app(TenantContext::class)->runAs($this->businessId, fn () => $next($job));
    }
}
