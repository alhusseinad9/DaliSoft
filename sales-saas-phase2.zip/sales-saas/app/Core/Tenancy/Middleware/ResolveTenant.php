<?php

declare(strict_types=1);

namespace App\Core\Tenancy\Middleware;

use App\Core\Tenancy\TenantContext;
use App\Models\Business;
use App\Models\BusinessUser;
use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * يحدد النشاط الحالي من جلسة المستخدم الموثّق فقط.
 * لا يُقبل business_id من الطلب (Header / Query / Body) أبداً.
 * يعمل قبل SubstituteBindings حتى يكون Route Model Binding محصوراً في النشاط.
 */
final class ResolveTenant
{
    public function __construct(private readonly TenantContext $tenant)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        $businessId = $request->hasSession() ? $request->session()->get('current_business_id') : null;

        if ($user === null || $businessId === null) {
            return $this->deny('business_not_selected', 'لم يتم تحديد النشاط التجاري.');
        }

        $membership = BusinessUser::query()
            ->where('user_id', $user->getAuthIdentifier())
            ->where('business_id', (int) $businessId)
            ->where('status', BusinessUser::STATUS_ACTIVE)
            ->whereHas('business', fn ($q) => $q->where('status', Business::STATUS_ACTIVE))
            ->first();

        if ($membership === null) {
            $request->session()->forget('current_business_id');

            return $this->deny('business_access_denied', 'لا تملك صلاحية الوصول إلى هذا النشاط.');
        }

        $this->tenant->set((int) $membership->business_id);

        // الأدوار تختلف من نشاط لآخر؛ لا نعتمد على علاقات محمّلة مسبقاً.
        $user->unsetRelation('roles')->unsetRelation('permissions');
        $request->attributes->set('membership', $membership);

        return $next($request);
    }

    public function terminate(Request $request, Response $response): void
    {
        $this->tenant->clear();
    }

    private function deny(string $code, string $message): JsonResponse
    {
        return response()->json(['message' => $message, 'code' => $code], 403);
    }
}
