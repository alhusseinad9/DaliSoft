<?php

declare(strict_types=1);

namespace App\Core\Tenancy\Scopes;

use App\Core\Tenancy\TenantContext;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;

final class BusinessScope implements Scope
{
    public function apply(Builder $builder, Model $model): void
    {
        $tenant = app(TenantContext::class);

        if ($tenant->isScopeBypassed()) {
            return;
        }

        // requireId يرمي استثناء إن لم يُحدد النشاط: لا يوجد استعلام "بلا فلتر" بالخطأ.
        $builder->where($model->qualifyColumn('business_id'), $tenant->requireId());
    }
}
