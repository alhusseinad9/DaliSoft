<?php

declare(strict_types=1);

namespace App\Core\Tenancy;

use App\Core\Tenancy\Exceptions\MissingTenantException;
use Illuminate\Support\Facades\DB;

/**
 * يحمل النشاط التجاري (Tenant) الحالي طوال الطلب أو الـ Job.
 *
 * مسجّل كـ scoped في الحاوية: نسخة جديدة لكل طلب ولكل Job.
 * عند التعيين يضبط ثلاثة أشياء معاً:
 *   1) السياق داخل التطبيق (يستخدمه BusinessScope).
 *   2) إعداد app.business_id في جلسة PostgreSQL (تقرأه سياسات RLS).
 *   3) الفريق الحالي لصلاحيات Spatie (الأدوار مستقلة لكل نشاط).
 */
final class TenantContext
{
    private ?int $businessId = null;

    private int $scopeBypassDepth = 0;

    public function set(?int $businessId): void
    {
        $this->businessId = $businessId;

        DB::statement(
            "select set_config('app.business_id', ?, false)",
            [$businessId === null ? '' : (string) $businessId]
        );

        setPermissionsTeamId($businessId);
    }

    public function clear(): void
    {
        if ($this->businessId !== null) {
            $this->set(null);
        }
    }

    public function id(): ?int
    {
        return $this->businessId;
    }

    public function hasTenant(): bool
    {
        return $this->businessId !== null;
    }

    public function requireId(): int
    {
        if ($this->businessId === null) {
            throw new MissingTenantException();
        }

        return $this->businessId;
    }

    /**
     * تنفيذ كود داخل نشاط محدد ثم استعادة السياق السابق (للـ Jobs والأوامر والاختبارات).
     *
     * @template T
     * @param  callable(): T  $callback
     * @return T
     */
    public function runAs(int $businessId, callable $callback): mixed
    {
        $previous = $this->businessId;
        $this->set($businessId);

        try {
            return $callback();
        } finally {
            $this->set($previous);
        }
    }

    /**
     * تعطيل الـ Global Scope في Eloquent فقط (للوحة المنصة).
     * تنبيه: RLS في قاعدة البيانات يبقى فعّالاً؛ الوصول عبر أكثر من نشاط
     * يتطلب اتصال pgsql_platform بدور يملك BYPASSRLS (المرحلة 4).
     *
     * @template T
     * @param  callable(): T  $callback
     * @return T
     */
    public function withoutScope(callable $callback): mixed
    {
        $this->scopeBypassDepth++;

        try {
            return $callback();
        } finally {
            $this->scopeBypassDepth--;
        }
    }

    public function isScopeBypassed(): bool
    {
        return $this->scopeBypassDepth > 0;
    }
}
