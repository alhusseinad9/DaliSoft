<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * عضوية مستخدم في نشاط. يُستعلم عنه قبل تحديد الـ Tenant (لذلك بلا BusinessScope)،
 * ودائماً مع شرط user_id صريح.
 */
class BusinessUser extends Model
{
    public const STATUS_ACTIVE = 'active';
    public const STATUS_DISABLED = 'disabled';

    protected $table = 'business_users';

    protected $fillable = ['business_id', 'user_id', 'employee_id', 'status', 'joined_at'];

    protected function casts(): array
    {
        return ['joined_at' => 'datetime'];
    }

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
