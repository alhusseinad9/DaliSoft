<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Support\HasPublicId;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

/**
 * المستخدم كيان عام (ليس داخل Tenant): يمكن أن ينتمي لأكثر من نشاط عبر business_users.
 * أدواره وصلاحياته تختلف حسب النشاط الحالي (Spatie teams).
 */
class User extends Authenticatable
{
    use HasPublicId, HasRoles, Notifiable;

    protected string $guard_name = 'web';

    protected $fillable = ['name', 'email', 'phone', 'password'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'last_login_at' => 'datetime',
            'is_active' => 'boolean',
            'password' => 'hashed',   // Argon2id عبر HASH_DRIVER
        ];
    }

    protected function email(): Attribute
    {
        return Attribute::set(fn (?string $value) => $value === null ? null : mb_strtolower(trim($value)));
    }

    public function memberships(): HasMany
    {
        return $this->hasMany(BusinessUser::class);
    }

    public function activeMemberships(): HasMany
    {
        return $this->memberships()->where('status', BusinessUser::STATUS_ACTIVE);
    }
}
