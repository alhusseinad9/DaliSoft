<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Actions;

use App\Models\User;
use App\Modules\Catalog\Models\Product;
use App\Modules\Inventory\Services\StockService;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

/**
 * الكمية الابتدائية (opening_stock) تُسجَّل كحركة مخزون من النوع 'opening' بدل
 * أن تُكتب مباشرة في stock_qty — حتى يبقى لكل رقم كمية أثر في stock_movements
 * منذ أول لحظة، بلا استثناء.
 */
final class CreateProduct
{
    public function __construct(private readonly StockService $stock)
    {
    }

    /** @param  array<string, mixed>  $data */
    public function handle(array $data, User $actor): Product
    {
        return DB::transaction(function () use ($data, $actor): Product {
            $product = new Product(Arr::only($data, [
                'category_id', 'unit_id', 'name', 'sku', 'barcode',
                'sale_price', 'cost_price', 'track_stock', 'min_stock',
            ]));
            $product->forceFill(['is_active' => true])->save();

            $openingStock = (string) ($data['opening_stock'] ?? '0');

            if ($product->track_stock && bccomp($openingStock, '0', 3) !== 0) {
                $this->stock->move(
                    product: $product,
                    qty: $openingStock,
                    type: 'opening',
                    allowNegative: true, // الكمية الابتدائية قد تكون سالبة نادراً (تصحيح افتتاحي)؛ قرار المستخدم
                );
            }

            return $product->fresh();
        });
    }
}
