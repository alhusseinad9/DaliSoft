<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Actions;

use App\Modules\Catalog\Models\Product;

/**
 * لا يسمح هذا الـ Action أبداً بتعديل stock_qty — الكمية تتغيّر فقط عبر
 * AdjustStock (تسوية يدوية موثَّقة) أو فواتير الشراء/البيع/المرتجعات.
 * كان السماح بتعديل الكمية مباشرة من نموذج المنتج أحد الأخطاء التي اكتُشفت
 * وصُحِّحت في المعاينة الأولى: كان يكسر أثر تتبع حركة المخزون بصمت.
 */
final class UpdateProduct
{
    /** @param  array<string, mixed>  $data */
    public function handle(Product $product, array $data): Product
    {
        $product->update(array_intersect_key($data, array_flip([
            'category_id', 'unit_id', 'name', 'sku', 'barcode',
            'sale_price', 'cost_price', 'is_active', 'track_stock', 'min_stock',
        ])));

        return $product;
    }
}
