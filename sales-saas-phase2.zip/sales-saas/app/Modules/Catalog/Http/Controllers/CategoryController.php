<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Http\Controllers;

use App\Modules\Catalog\Http\Requests\StoreCategoryRequest;
use App\Modules\Catalog\Models\Category;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

/** قائمة بسيطة (تصنيفات المنتجات) — لا تحتاج Policy مستقلة، صلاحيات المنتجات تكفيها. */
final class CategoryController
{
    use AuthorizesRequests;

    public function index(): JsonResponse
    {
        Gate::authorize('products.view');

        return response()->json(['data' => Category::query()->orderBy('sort')->orderBy('name')
            ->get(['id', 'public_id', 'name'])
            ->map(fn ($c) => ['id' => $c->public_id, 'name' => $c->name])]);
    }

    public function store(StoreCategoryRequest $request): JsonResponse
    {
        Gate::authorize('products.create');

        $category = Category::create($request->validated());

        return response()->json(['data' => ['id' => $category->public_id, 'name' => $category->name]], 201);
    }
}
