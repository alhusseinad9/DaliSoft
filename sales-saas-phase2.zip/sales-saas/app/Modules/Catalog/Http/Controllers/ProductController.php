<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Http\Controllers;

use App\Modules\Catalog\Actions\CreateProduct;
use App\Modules\Catalog\Actions\UpdateProduct;
use App\Modules\Catalog\Http\Requests\StoreProductRequest;
use App\Modules\Catalog\Http\Requests\UpdateProductRequest;
use App\Modules\Catalog\Http\Resources\ProductResource;
use App\Modules\Catalog\Models\Product;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

final class ProductController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Product::class);

        $term = trim((string) $request->query('q', ''));
        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $products = Product::query()
            ->with(['category:id,public_id,name', 'unit:id,name'])
            ->when($term !== '', function ($query) use ($term): void {
                $like = '%'.addcslashes($term, '%_\\').'%';
                $query->where(fn ($w) => $w->where('name', 'ilike', $like)->orWhere('sku', 'ilike', $like)->orWhere('barcode', $term));
            })
            ->when($request->boolean('low_stock'), fn ($q) => $q->where('track_stock', true)->whereColumn('stock_qty', '<=', 'min_stock'))
            ->orderBy('name')
            ->cursorPaginate($perPage);

        return ProductResource::collection($products);
    }

    public function store(StoreProductRequest $request, CreateProduct $action): JsonResponse
    {
        $this->authorize('create', Product::class);

        $product = $action->handle($request->validated(), $request->user());

        return ProductResource::make($product)->response()->setStatusCode(201);
    }

    public function show(Product $product): ProductResource
    {
        $this->authorize('view', $product);

        return ProductResource::make($product);
    }

    public function update(UpdateProductRequest $request, Product $product, UpdateProduct $action): ProductResource
    {
        $this->authorize('update', $product);

        return ProductResource::make($action->handle($product, $request->validated()));
    }

    public function destroy(Product $product): Response|JsonResponse
    {
        $this->authorize('delete', $product);

        $hasHistory = $product->invoiceItems()->exists() || $product->purchaseInvoiceItems()->exists();

        if ($hasHistory) {
            return response()->json([
                'message' => 'لا يمكن حذف منتج له فواتير سابقة — عطّله بدل حذفه.',
                'code' => 'product_has_history',
            ], 422);
        }

        $product->delete();

        return response()->noContent();
    }
}
