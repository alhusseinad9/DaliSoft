<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Http\Controllers;

use App\Modules\Catalog\Http\Requests\AdjustStockRequest;
use App\Modules\Catalog\Http\Resources\ProductResource;
use App\Modules\Catalog\Models\Product;
use App\Modules\Inventory\Actions\AdjustStock;
use Illuminate\Support\Facades\Gate;

final class StockAdjustmentController
{
    public function __invoke(AdjustStockRequest $request, Product $product, AdjustStock $action): ProductResource
    {
        // تسوية يدوية للكمية صلاحية حساسة منفصلة عن مجرد تعديل بيانات المنتج
        Gate::authorize('inventory.adjust');

        $product = $action->handle($product, (string) $request->validated('new_qty'), $request->validated('note'));

        return ProductResource::make($product);
    }
}
