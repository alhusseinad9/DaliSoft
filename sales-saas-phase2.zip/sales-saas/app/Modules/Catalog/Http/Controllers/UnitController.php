<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Http\Controllers;

use App\Modules\Catalog\Http\Requests\StoreUnitRequest;
use App\Modules\Catalog\Models\Unit;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

final class UnitController
{
    public function index(): JsonResponse
    {
        Gate::authorize('products.view');

        return response()->json(['data' => Unit::query()->orderBy('name')
            ->get(['id', 'public_id', 'name'])
            ->map(fn ($u) => ['id' => $u->public_id, 'name' => $u->name])]);
    }

    public function store(StoreUnitRequest $request): JsonResponse
    {
        Gate::authorize('products.create');

        $unit = Unit::create($request->validated());

        return response()->json(['data' => ['id' => $unit->public_id, 'name' => $unit->name]], 201);
    }
}
