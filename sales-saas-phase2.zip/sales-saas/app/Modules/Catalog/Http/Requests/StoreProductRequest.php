<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'category_id' => ['nullable', 'integer', 'exists:categories,id'],
            'unit_id' => ['required', 'integer', 'exists:units,id'],
            'name' => ['required', 'string', 'max:150'],
            'sku' => ['nullable', 'string', 'max:64'],
            'barcode' => ['nullable', 'string', 'max:64'],
            'sale_price' => ['required', 'decimal:0,3', 'min:0'],
            'cost_price' => ['nullable', 'decimal:0,3', 'min:0'],
            'track_stock' => ['sometimes', 'boolean'],
            'min_stock' => ['nullable', 'decimal:0,3', 'min:0'],
            'opening_stock' => ['nullable', 'decimal:0,3'],
        ];
    }
}
