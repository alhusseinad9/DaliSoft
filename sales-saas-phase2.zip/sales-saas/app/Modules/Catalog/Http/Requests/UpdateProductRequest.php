<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/** stock_qty عمداً غير موجود هنا — يُعدَّل فقط عبر AdjustStock. */
final class UpdateProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'category_id' => ['sometimes', 'nullable', 'integer', 'exists:categories,id'],
            'unit_id' => ['sometimes', 'required', 'integer', 'exists:units,id'],
            'name' => ['sometimes', 'required', 'string', 'max:150'],
            'sku' => ['sometimes', 'nullable', 'string', 'max:64'],
            'barcode' => ['sometimes', 'nullable', 'string', 'max:64'],
            'sale_price' => ['sometimes', 'required', 'decimal:0,3', 'min:0'],
            'cost_price' => ['sometimes', 'nullable', 'decimal:0,3', 'min:0'],
            'is_active' => ['sometimes', 'boolean'],
            'track_stock' => ['sometimes', 'boolean'],
            'min_stock' => ['sometimes', 'nullable', 'decimal:0,3', 'min:0'],
        ];
    }
}
