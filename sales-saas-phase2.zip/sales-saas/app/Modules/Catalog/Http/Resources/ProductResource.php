<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class ProductResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'category_id' => $this->category?->public_id,
            'unit' => $this->unit?->name,
            'name' => $this->name,
            'sku' => $this->sku,
            'barcode' => $this->barcode,
            'sale_price' => $this->sale_price,
            'cost_price' => $this->when(
                $request->user()?->can('reports.profit.view'),
                $this->cost_price
            ),
            'is_active' => $this->is_active,
            'track_stock' => $this->track_stock,
            'stock_qty' => $this->when($this->track_stock, $this->stock_qty),
            'min_stock' => $this->when($this->track_stock, $this->min_stock),
            'low_stock' => $this->when(
                $this->track_stock,
                fn () => bccomp((string) $this->stock_qty, (string) $this->min_stock, 3) <= 0
            ),
        ];
    }
}
