<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Models;

use App\Core\Audit\Auditable;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use Auditable, BelongsToBusiness, SoftDeletes;

    protected $fillable = ['name', 'sort'];

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }
}
