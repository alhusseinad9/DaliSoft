<?php

declare(strict_types=1);

namespace App\Modules\Catalog\Models;

use App\Core\Audit\Auditable;
use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Invoicing\Models\InvoiceItem;
use App\Modules\Purchasing\Models\PurchaseInvoiceItem;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/** stock_qty لا يُعدَّل مباشرة: يتغير فقط عبر StockService (المرحلة 3) مع حركة في stock_movements. */
class Product extends Model
{
    use Auditable, BelongsToBusiness, HasPublicId, SoftDeletes;

    protected $fillable = [
        'category_id', 'unit_id', 'name', 'sku', 'barcode',
        'sale_price', 'cost_price', 'image_path', 'is_active', 'track_stock', 'min_stock',
    ];

    protected function casts(): array
    {
        return [
            'sale_price' => 'decimal:3',
            'cost_price' => 'decimal:3',
            'stock_qty' => 'decimal:3',
            'min_stock' => 'decimal:3',
            'is_active' => 'boolean',
            'track_stock' => 'boolean',
        ];
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }

    public function invoiceItems(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    public function purchaseInvoiceItems(): HasMany
    {
        return $this->hasMany(PurchaseInvoiceItem::class);
    }
}
