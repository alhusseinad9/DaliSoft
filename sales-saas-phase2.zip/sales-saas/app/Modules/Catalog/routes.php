<?php

use App\Modules\Catalog\Http\Controllers\CategoryController;
use App\Modules\Catalog\Http\Controllers\ProductController;
use App\Modules\Catalog\Http\Controllers\StockAdjustmentController;
use App\Modules\Catalog\Http\Controllers\UnitController;
use Illuminate\Support\Facades\Route;

Route::get('products', [ProductController::class, 'index'])->name('products.index');
Route::post('products', [ProductController::class, 'store'])->middleware('idempotent')->name('products.store');
Route::get('products/{product}', [ProductController::class, 'show'])->name('products.show');
Route::patch('products/{product}', [ProductController::class, 'update'])->name('products.update');
Route::delete('products/{product}', [ProductController::class, 'destroy'])->name('products.destroy');
Route::post('products/{product}/adjust-stock', StockAdjustmentController::class)->name('products.adjust-stock');

Route::get('categories', [CategoryController::class, 'index'])->name('categories.index');
Route::post('categories', [CategoryController::class, 'store'])->name('categories.store');

Route::get('units', [UnitController::class, 'index'])->name('units.index');
Route::post('units', [UnitController::class, 'store'])->name('units.store');
