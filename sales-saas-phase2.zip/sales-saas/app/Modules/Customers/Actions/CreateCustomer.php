<?php

declare(strict_types=1);

namespace App\Modules\Customers\Actions;

use App\Models\User;
use App\Modules\Customers\Models\Customer;
use App\Modules\Customers\Models\CustomerLedgerEntry;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

/**
 * النمط المعتمد لكل العمليات المالية: Action واحد، معاملة واحدة، وقيود في الدفتر.
 * الرصيد الافتتاحي يُسجَّل كقيد، فيظهر في كشف الحساب ويبقى الرصيد قابلاً لإعادة الحساب.
 */
final class CreateCustomer
{
    /** @param  array<string, mixed>  $data */
    public function handle(array $data, User $actor): Customer
    {
        return DB::transaction(function () use ($data, $actor): Customer {
            $opening = $this->normalize($data['opening_balance'] ?? '0');

            $customer = new Customer(Arr::only($data, ['name', 'phone', 'address', 'area', 'notes', 'credit_limit']));
            $customer->forceFill([
                'opening_balance' => $opening,
                'balance' => $opening,
                'created_by' => $actor->id,
            ])->save();

            $sign = bccomp($opening, '0', 3);

            if ($sign !== 0) {
                CustomerLedgerEntry::create([
                    'customer_id' => $customer->id,
                    'source_type' => 'opening_balance',
                    'source_id' => $customer->id,
                    'description' => 'رصيد افتتاحي',
                    'debit' => $sign > 0 ? $opening : '0',
                    'credit' => $sign < 0 ? bcmul($opening, '-1', 3) : '0',
                    'occurred_at' => now(),
                    'created_by' => $actor->id,
                ]);
            }

            return $customer;
        });
    }

    private function normalize(mixed $amount): string
    {
        return bcadd((string) ($amount ?? '0'), '0', 3);
    }
}
