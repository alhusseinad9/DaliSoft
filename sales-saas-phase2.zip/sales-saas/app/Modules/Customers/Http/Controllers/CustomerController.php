<?php

declare(strict_types=1);

namespace App\Modules\Customers\Http\Controllers;

use App\Modules\Customers\Actions\CreateCustomer;
use App\Modules\Customers\Http\Requests\StoreCustomerRequest;
use App\Modules\Customers\Http\Requests\UpdateCustomerRequest;
use App\Modules\Customers\Http\Resources\CustomerResource;
use App\Modules\Customers\Models\Customer;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

final class CustomerController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Customer::class);

        $term = trim((string) $request->query('q', ''));
        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $customers = Customer::query()
            ->when($term !== '', function ($query) use ($term): void {
                $like = '%'.addcslashes($term, '%_\\').'%';
                $query->where(fn ($w) => $w->where('name', 'ilike', $like)->orWhere('phone', 'like', $like));
            })
            ->orderBy('name')
            ->orderBy('id')
            ->cursorPaginate($perPage);

        return CustomerResource::collection($customers);
    }

    public function store(StoreCustomerRequest $request, CreateCustomer $action): JsonResponse
    {
        $this->authorize('create', Customer::class);

        $customer = $action->handle($request->validated(), $request->user());

        return CustomerResource::make($customer)->response()->setStatusCode(201);
    }

    public function show(Customer $customer): CustomerResource
    {
        $this->authorize('view', $customer);

        return CustomerResource::make($customer);
    }

    public function update(UpdateCustomerRequest $request, Customer $customer): CustomerResource
    {
        $this->authorize('update', $customer);

        $customer->update($request->validated());

        return CustomerResource::make($customer);
    }

    public function destroy(Customer $customer): Response|JsonResponse
    {
        $this->authorize('delete', $customer);

        if (bccomp((string) $customer->balance, '0', 3) !== 0) {
            return response()->json([
                'message' => 'لا يمكن حذف عميل عليه رصيد مستحق.',
                'code' => 'customer_has_balance',
            ], 422);
        }

        $customer->delete(); // Soft delete — الفواتير والقيود السابقة تبقى مرتبطة به

        return response()->noContent();
    }
}
