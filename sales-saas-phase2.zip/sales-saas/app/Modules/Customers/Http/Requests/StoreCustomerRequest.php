<?php

declare(strict_types=1);

namespace App\Modules\Customers\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreCustomerRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // التحقق من الصلاحية في الـ Policy داخل الـ Controller
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:150'],
            'phone' => ['nullable', 'string', 'max:32', 'regex:/^[0-9+\-\s]{5,32}$/'],
            'address' => ['nullable', 'string', 'max:255'],
            'area' => ['nullable', 'string', 'max:100'],
            'notes' => ['nullable', 'string', 'max:2000'],
            'opening_balance' => ['nullable', 'decimal:0,3', 'between:-999999999999,999999999999'],
            'credit_limit' => ['nullable', 'decimal:0,3', 'min:0', 'max:999999999999'],
        ];
    }
}
