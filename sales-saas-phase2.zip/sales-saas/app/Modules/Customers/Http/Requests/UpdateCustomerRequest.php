<?php

declare(strict_types=1);

namespace App\Modules\Customers\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/** الرصيد الافتتاحي لا يُعدَّل بعد الإنشاء؛ التصحيح عبر تسوية تُسجَّل في الدفتر. */
final class UpdateCustomerRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'required', 'string', 'max:150'],
            'phone' => ['sometimes', 'nullable', 'string', 'max:32', 'regex:/^[0-9+\-\s]{5,32}$/'],
            'address' => ['sometimes', 'nullable', 'string', 'max:255'],
            'area' => ['sometimes', 'nullable', 'string', 'max:100'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
            'credit_limit' => ['sometimes', 'nullable', 'decimal:0,3', 'min:0', 'max:999999999999'],
        ];
    }
}
