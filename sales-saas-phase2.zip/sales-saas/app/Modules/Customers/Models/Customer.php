<?php

declare(strict_types=1);

namespace App\Modules\Customers\Models;

use App\Core\Audit\Auditable;
use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * balance = مجموع (مدين − دائن) في customer_ledger_entries.
 * يُحدَّث فقط داخل Actions مالية وفي نفس المعاملة؛ ليس في $fillable.
 */
class Customer extends Model
{
    use Auditable, BelongsToBusiness, HasPublicId, SoftDeletes;

    protected $fillable = ['name', 'phone', 'address', 'area', 'notes', 'credit_limit'];

    protected function casts(): array
    {
        return [
            'opening_balance' => 'decimal:3',
            'credit_limit' => 'decimal:3',
            'balance' => 'decimal:3',
        ];
    }

    public function ledgerEntries(): HasMany
    {
        return $this->hasMany(CustomerLedgerEntry::class);
    }
}
