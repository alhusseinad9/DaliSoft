<?php

declare(strict_types=1);

namespace App\Modules\Customers\Models;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * قيد في كشف حساب العميل — Append-only (Trigger في قاعدة البيانات يمنع UPDATE/DELETE).
 * التصحيح يكون بقيد عكسي، وليس بتعديل القيد.
 */
class CustomerLedgerEntry extends Model
{
    use BelongsToBusiness;

    public $timestamps = false;

    protected $fillable = [
        'customer_id', 'source_type', 'source_id', 'description',
        'debit', 'credit', 'occurred_at', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'debit' => 'decimal:3',
            'credit' => 'decimal:3',
            'occurred_at' => 'datetime',
            'created_at' => 'datetime',
        ];
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }
}
