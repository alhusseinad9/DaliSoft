<?php

declare(strict_types=1);

namespace App\Modules\Customers\Policies;

use App\Models\User;
use App\Modules\Customers\Models\Customer;

/**
 * الـ Policy تتحقق من الصلاحية فقط. انتماء السجل للنشاط الحالي مضمون مسبقاً
 * (BusinessScope + RLS)، وأي عميل من نشاط آخر يعطي 404 قبل الوصول إلى هنا.
 */
final class CustomerPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('customers.view');
    }

    public function view(User $user, Customer $customer): bool
    {
        return $user->can('customers.view');
    }

    public function create(User $user): bool
    {
        return $user->can('customers.create');
    }

    public function update(User $user, Customer $customer): bool
    {
        return $user->can('customers.edit');
    }

    public function delete(User $user, Customer $customer): bool
    {
        return $user->can('customers.delete');
    }
}
