<?php

declare(strict_types=1);

namespace App\Modules\Employees\Actions;

use App\Modules\Employees\Models\Employee;

final class CreateEmployee
{
    /** @param  array<string, mixed>  $data */
    public function handle(array $data): Employee
    {
        $employee = new Employee($data);
        $employee->forceFill(['status' => 'active'])->save();

        return $employee;
    }
}
