<?php

declare(strict_types=1);

namespace App\Modules\Employees\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:150'],
            'phone' => ['nullable', 'string', 'max:32'],
            'job_title' => ['nullable', 'string', 'max:100'],
            'hired_at' => ['nullable', 'date'],
            // الراتب معلومة حساسة ماثلة للتكلفة والربح — من يُنشئ موظفاً يحتاج صلاحية مناسبة أصلاً، تُفحص بالـ Policy
            'salary' => ['nullable', 'decimal:0,3', 'min:0'],
        ];
    }
}
