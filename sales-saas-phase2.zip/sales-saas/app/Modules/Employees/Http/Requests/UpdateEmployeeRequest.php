<?php

declare(strict_types=1);

namespace App\Modules\Employees\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class UpdateEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'required', 'string', 'max:150'],
            'phone' => ['sometimes', 'nullable', 'string', 'max:32'],
            'job_title' => ['sometimes', 'nullable', 'string', 'max:100'],
            'hired_at' => ['sometimes', 'nullable', 'date'],
            'salary' => ['sometimes', 'nullable', 'decimal:0,3', 'min:0'],
            'status' => ['sometimes', 'in:active,inactive'],
        ];
    }
}
