<?php

declare(strict_types=1);

namespace App\Modules\Employees\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class EmployeeResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'name' => $this->name,
            'phone' => $this->phone,
            'job_title' => $this->job_title,
            'hired_at' => $this->hired_at?->toDateString(),
            // الراتب لا يظهر إلا لمن يملك صلاحية عرض التقارير المالية
            'salary' => $this->when($request->user()?->can('reports.financial.view'), $this->salary),
            'status' => $this->status,
        ];
    }
}
