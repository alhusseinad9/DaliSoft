<?php

declare(strict_types=1);

namespace App\Modules\Employees\Models;

use App\Core\Audit\Auditable;
use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employee extends Model
{
    use Auditable, BelongsToBusiness, HasPublicId, SoftDeletes;

    protected $fillable = ['name', 'phone', 'job_title', 'hired_at', 'salary', 'status'];

    protected function casts(): array
    {
        return [
            'hired_at' => 'date',
            'salary' => 'decimal:3',
        ];
    }
}
