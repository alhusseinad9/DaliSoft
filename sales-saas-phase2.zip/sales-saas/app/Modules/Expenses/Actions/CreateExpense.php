<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Actions;

use App\Core\Sequences\SequenceService;
use App\Models\User;
use App\Modules\Expenses\Models\Expense;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

final class CreateExpense
{
    public function __construct(private readonly SequenceService $sequences)
    {
    }

    /** @param  array<string, mixed>  $data */
    public function handle(array $data, User $actor): Expense
    {
        return DB::transaction(function () use ($data, $actor): Expense {
            $expense = new Expense(Arr::only($data, ['category_id', 'employee_id', 'amount', 'spent_at', 'method', 'notes']));
            $expense->forceFill([
                'number' => $this->sequences->next('expense'),
                'status' => 'posted',
                'created_by' => $actor->id,
            ])->save();

            return $expense;
        });
    }
}
