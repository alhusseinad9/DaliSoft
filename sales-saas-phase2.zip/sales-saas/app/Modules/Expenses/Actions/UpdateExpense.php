<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Actions;

use App\Modules\Expenses\Models\Expense;
use Illuminate\Validation\ValidationException;

final class UpdateExpense
{
    /** @param  array<string, mixed>  $data */
    public function handle(Expense $expense, array $data): Expense
    {
        if ($expense->status === 'void') {
            throw ValidationException::withMessages(['status' => 'لا يمكن تعديل مصروف ملغى.']);
        }

        $expense->update(array_intersect_key($data, array_flip(['category_id', 'employee_id', 'amount', 'spent_at', 'method', 'notes'])));

        return $expense;
    }
}
