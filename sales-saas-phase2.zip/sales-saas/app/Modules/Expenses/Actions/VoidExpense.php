<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Actions;

use App\Models\User;
use App\Modules\Expenses\Models\Expense;
use Illuminate\Validation\ValidationException;

final class VoidExpense
{
    public function handle(Expense $expense, User $actor, string $reason): Expense
    {
        if ($expense->status === 'void') {
            throw ValidationException::withMessages(['status' => 'المصروف ملغى بالفعل.']);
        }

        $expense->forceFill([
            'status' => 'void',
            'voided_at' => now(),
            'voided_by' => $actor->id,
            'void_reason' => $reason,
        ])->save();

        return $expense;
    }
}
