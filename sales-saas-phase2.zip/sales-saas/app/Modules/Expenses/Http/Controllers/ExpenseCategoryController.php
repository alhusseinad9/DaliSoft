<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Http\Controllers;

use App\Modules\Expenses\Models\ExpenseCategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

final class ExpenseCategoryController
{
    public function index(): JsonResponse
    {
        Gate::authorize('expenses.view');

        return response()->json(['data' => ExpenseCategory::query()->orderBy('name')
            ->get(['id', 'name'])
            ->map(fn ($c) => ['id' => $c->id, 'name' => $c->name])]);
    }
}
