<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Http\Controllers;

use App\Modules\Expenses\Actions\CreateExpense;
use App\Modules\Expenses\Actions\UpdateExpense;
use App\Modules\Expenses\Actions\VoidExpense;
use App\Modules\Expenses\Http\Requests\StoreExpenseRequest;
use App\Modules\Expenses\Http\Requests\UpdateExpenseRequest;
use App\Modules\Expenses\Http\Requests\VoidExpenseRequest;
use App\Modules\Expenses\Http\Resources\ExpenseResource;
use App\Modules\Expenses\Models\Expense;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

final class ExpenseController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Expense::class);

        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $expenses = Expense::query()
            ->with('category:id,name')
            ->when($request->filled('from'), fn ($q) => $q->where('spent_at', '>=', $request->query('from')))
            ->when($request->filled('to'), fn ($q) => $q->where('spent_at', '<=', $request->query('to')))
            ->orderByDesc('spent_at')
            ->cursorPaginate($perPage);

        return ExpenseResource::collection($expenses);
    }

    public function store(StoreExpenseRequest $request, CreateExpense $action): JsonResponse
    {
        $this->authorize('create', Expense::class);

        $expense = $action->handle($request->validated(), $request->user());

        return ExpenseResource::make($expense)->response()->setStatusCode(201);
    }

    public function update(UpdateExpenseRequest $request, Expense $expense, UpdateExpense $action): ExpenseResource
    {
        $this->authorize('update', $expense);

        return ExpenseResource::make($action->handle($expense, $request->validated()));
    }

    public function void(VoidExpenseRequest $request, Expense $expense, VoidExpense $action): ExpenseResource
    {
        $this->authorize('delete', $expense);

        return ExpenseResource::make($action->handle($expense, $request->user(), (string) $request->validated('reason')));
    }
}
