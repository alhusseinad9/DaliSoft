<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreExpenseRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'category_id' => ['required', 'integer', 'exists:expense_categories,id'],
            'employee_id' => ['nullable', 'integer', 'exists:employees,id'],
            'amount' => ['required', 'decimal:0,3', 'gt:0'],
            'spent_at' => ['required', 'date'],
            'method' => ['required', 'in:cash,transfer,card,other'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
