<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class UpdateExpenseRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'category_id' => ['sometimes', 'required', 'integer', 'exists:expense_categories,id'],
            'employee_id' => ['sometimes', 'nullable', 'integer', 'exists:employees,id'],
            'amount' => ['sometimes', 'required', 'decimal:0,3', 'gt:0'],
            'spent_at' => ['sometimes', 'required', 'date'],
            'method' => ['sometimes', 'required', 'in:cash,transfer,card,other'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
        ];
    }
}
