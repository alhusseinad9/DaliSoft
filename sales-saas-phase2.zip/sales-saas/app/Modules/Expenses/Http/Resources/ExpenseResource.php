<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class ExpenseResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'number' => $this->number,
            'category' => $this->category?->name,
            'employee_id' => $this->employee?->public_id,
            'amount' => $this->amount,
            'spent_at' => $this->spent_at?->toDateString(),
            'method' => $this->method,
            'notes' => $this->notes,
            'status' => $this->status,
            'void_reason' => $this->void_reason,
        ];
    }
}
