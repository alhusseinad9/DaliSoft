<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Models;

use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Models\User;
use App\Modules\Employees\Models\Employee;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Expense extends Model
{
    use BelongsToBusiness, HasPublicId;

    protected $fillable = ['category_id', 'employee_id', 'amount', 'spent_at', 'method', 'notes'];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:3',
            'spent_at' => 'date',
            'voided_at' => 'datetime',
        ];
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(ExpenseCategory::class);
    }

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
