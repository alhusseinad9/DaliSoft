<?php

declare(strict_types=1);

namespace App\Modules\Expenses\Models;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;

class ExpenseCategory extends Model
{
    use BelongsToBusiness;

    protected $fillable = ['name', 'is_system'];

    protected function casts(): array
    {
        return ['is_system' => 'boolean'];
    }
}
