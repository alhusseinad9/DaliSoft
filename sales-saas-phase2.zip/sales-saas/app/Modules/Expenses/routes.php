<?php

use App\Modules\Expenses\Http\Controllers\ExpenseCategoryController;
use App\Modules\Expenses\Http\Controllers\ExpenseController;
use Illuminate\Support\Facades\Route;

Route::get('expenses', [ExpenseController::class, 'index'])->name('expenses.index');
Route::post('expenses', [ExpenseController::class, 'store'])->middleware('idempotent')->name('expenses.store');
Route::patch('expenses/{expense}', [ExpenseController::class, 'update'])->name('expenses.update');
Route::post('expenses/{expense}/void', [ExpenseController::class, 'void'])->name('expenses.void');

Route::get('expense-categories', [ExpenseCategoryController::class, 'index'])->name('expense-categories.index');
