<?php

declare(strict_types=1);

namespace App\Modules\Inventory\Actions;

use App\Modules\Catalog\Models\Product;
use App\Modules\Inventory\Services\StockService;
use Illuminate\Support\Facades\DB;

/**
 * التصحيح اليدوي الوحيد المسموح للكمية (جرد فعلي، خطأ عدّ...). يُسجَّل دائماً
 * كحركة 'adjustment' موثَّقة — بعكس النموذج الأولي الذي كان يسمح بتعديل رقم
 * الكمية مباشرة من نموذج المنتج بلا أي أثر في سجل الحركة.
 */
final class AdjustStock
{
    public function __construct(private readonly StockService $stock)
    {
    }

    public function handle(Product $product, string $newQty, ?string $note = null): Product
    {
        return DB::transaction(function () use ($product, $newQty) {
            $delta = bcsub($newQty, (string) $product->stock_qty, 3);

            if (bccomp($delta, '0', 3) !== 0) {
                $this->stock->move(
                    product: $product,
                    qty: $delta,
                    type: 'adjustment',
                    allowNegative: true, // تسوية يدوية صريحة من المستخدم — لا نمنعها حتى لو سالبة
                );
            }

            return $product->fresh();
        });
    }
}
