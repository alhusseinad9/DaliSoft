<?php

declare(strict_types=1);

namespace App\Modules\Inventory\Exceptions;

use App\Modules\Catalog\Models\Product;
use RuntimeException;

/**
 * يُرمى عند محاولة إنزال المخزون تحت الصفر بلا إذن صريح بتجاوز ذلك.
 * الواجهة تلتقطه وتعرض على المستخدم خيار "تأكيد رغم ذلك" (allow_negative_stock=true)
 * بدل ما يسمح للمخزون ينزل سالب بصمت — وهذا بالضبط الخلل الذي اكتُشف في النموذج الأولي.
 */
final class InsufficientStockException extends RuntimeException
{
    public function __construct(public readonly Product $product, public readonly string $resultingBalance)
    {
        parent::__construct("Insufficient stock for product [{$product->id}]: resulting balance {$resultingBalance}");
    }
}
