<?php

declare(strict_types=1);

namespace App\Modules\Inventory\Http\Controllers;

use App\Core\Modules\BusinessModule;
use App\Modules\Catalog\Models\Product;
use App\Modules\Inventory\Http\Resources\StockMovementResource;
use App\Modules\Inventory\Models\StockMovement;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

/** نظرة عامة للمخزون: الكميات الحالية وآخر الحركات. قراءة فقط — التعديل عبر AdjustStock أو المستندات. */
final class InventoryController
{
    public function index(): JsonResponse
    {
        Gate::authorize('inventory.view');

        if (! BusinessModule::isEnabled('inventory')) {
            return response()->json([
                'message' => 'وحدة المخزون غير مفعّلة لهذا النشاط.',
                'code' => 'module_disabled',
                'module' => 'inventory',
            ], 403);
        }

        $tracked = Product::query()->where('track_stock', true)->orderBy('name')->get(['id', 'public_id', 'name', 'stock_qty', 'min_stock']);
        $low = $tracked->filter(fn (Product $p) => bccomp((string) $p->stock_qty, (string) $p->min_stock, 3) <= 0)->values();

        $recentMovements = StockMovement::query()
            ->with('product:id,public_id,name')
            ->orderByDesc('created_at')
            ->limit(20)
            ->get();

        return response()->json([
            'data' => [
                'tracked_products' => $tracked->map(fn (Product $p) => [
                    'id' => $p->public_id, 'name' => $p->name, 'stock_qty' => $p->stock_qty, 'min_stock' => $p->min_stock,
                ]),
                'low_stock_count' => $low->count(),
                'low_stock_products' => $low->map(fn (Product $p) => ['id' => $p->public_id, 'name' => $p->name, 'stock_qty' => $p->stock_qty]),
                'recent_movements' => StockMovementResource::collection($recentMovements),
            ],
        ]);
    }
}
