<?php

declare(strict_types=1);

namespace App\Modules\Inventory\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class StockMovementResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'product_id' => $this->product?->public_id,
            'product_name' => $this->product?->name,
            'type' => $this->type,
            'qty' => $this->qty,
            'balance_after' => $this->balance_after,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
