<?php

declare(strict_types=1);

namespace App\Modules\Inventory\Models;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Catalog\Models\Product;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** سجل حركة المخزون — Append-only. qty موجبة للإضافة وسالبة للخصم. */
class StockMovement extends Model
{
    use BelongsToBusiness;

    public $timestamps = false;

    protected $fillable = [
        'product_id', 'type', 'qty', 'balance_after', 'unit_cost',
        'source_type', 'source_id', 'notes', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'qty' => 'decimal:3',
            'balance_after' => 'decimal:3',
            'unit_cost' => 'decimal:3',
            'created_at' => 'datetime',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
