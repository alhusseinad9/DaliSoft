<?php

declare(strict_types=1);

namespace App\Modules\Inventory\Services;

use App\Core\Modules\BusinessModule;
use App\Modules\Catalog\Models\Product;
use App\Modules\Inventory\Exceptions\InsufficientStockException;
use App\Modules\Inventory\Models\StockMovement;

/**
 * نقطة واحدة لكل حركة مخزون في النظام — تستخدمها كل الوحدات (الفواتير، المشتريات،
 * المرتجعات، تسويات المنتج اليدوية) بدل ما يكرر كل Action منطق الخصم والتحقق بنفسه.
 *
 * تحترم وحدة المخزون (Settings → تفعيل المخزون): لو كانت مطفأة، أو المنتج نفسه
 * لا يتابع كمية (track_stock=false)، لا تفعل شيئاً إطلاقاً — بلا حركة وبلا تغيير كمية.
 */
final class StockService
{
    /**
     * @param  string  $qty  موجبة لإضافة كمية، سالبة لخصمها
     *
     * @throws InsufficientStockException عندما تُنزل الحركة الكمية تحت الصفر ولم يُسمح بذلك صراحة
     */
    public function move(
        Product $product,
        string $qty,
        string $type,
        ?string $sourceType = null,
        ?int $sourceId = null,
        bool $allowNegative = false,
        ?string $unitCost = null,
    ): void {
        if (! $product->track_stock || ! BusinessModule::isEnabled('inventory')) {
            return;
        }

        $newBalance = bcadd((string) $product->stock_qty, $qty, 3);

        if (bccomp($newBalance, '0', 3) < 0 && ! $allowNegative) {
            throw new InsufficientStockException($product, $newBalance);
        }

        $product->forceFill(['stock_qty' => $newBalance])->save();

        StockMovement::create([
            'product_id' => $product->id,
            'type' => $type,
            'qty' => $qty,
            'balance_after' => $newBalance,
            'unit_cost' => $unitCost,
            'source_type' => $sourceType,
            'source_id' => $sourceId,
            'created_by' => auth()->id(),
        ]);
    }

    /** يتحقق فقط دون تنفيذ — تستخدمه الواجهة لعرض تحذير قبل الحفظ، كما في نموذج الفاتورة. */
    public function wouldGoNegative(Product $product, string $qty): bool
    {
        if (! $product->track_stock || ! BusinessModule::isEnabled('inventory')) {
            return false;
        }

        return bccomp(bcadd((string) $product->stock_qty, $qty, 3), '0', 3) < 0;
    }
}
