<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Actions;

use App\Core\Money\Money;
use App\Core\Sequences\SequenceService;
use App\Models\User;
use App\Modules\Catalog\Models\Product;
use App\Modules\Customers\Models\Customer;
use App\Modules\Customers\Models\CustomerLedgerEntry;
use App\Modules\Inventory\Exceptions\InsufficientStockException;
use App\Modules\Inventory\Services\StockService;
use App\Modules\Invoicing\Exceptions\CreditLimitExceededException;
use App\Modules\Invoicing\Models\Invoice;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * يصدر فاتورة بيع كاملة في معاملة واحدة: يحسب الإجمالي، يحدد حالة الدفع
 * (نقدي/جزئي/آجل) بناءً على pay_way، يتحقق من الحد الائتماني وتوفر المخزون
 * (قابلان للتجاوز صراحة)، يحفظ تكلفة كل صنف وقت البيع، يحدّث رصيد العميل
 * عبر قيد دفتر، ويخصم المخزون عبر StockService.
 */
final class IssueInvoice
{
    public function __construct(
        private readonly SequenceService $sequences,
        private readonly StockService $stock,
    ) {
    }

    /** @param  array<string, mixed>  $data */
    public function handle(array $data, User $actor): Invoice
    {
        return DB::transaction(function () use ($data, $actor): Invoice {
            $customer = isset($data['customer_id'])
                ? Customer::query()->lockForUpdate()->findOrFail($data['customer_id'])
                : null;

            $items = $this->prepareItems($data['items']);
            $total = $items->reduce(fn (string $sum, array $it) => Money::add($sum, $it['line_total']), '0');

            [$paid, $method] = $this->resolvePayment($data, $total);
            $due = Money::max(Money::sub($total, $paid), '0');

            if (! Money::isZero($due) && $customer === null) {
                throw ValidationException::withMessages([
                    'customer_id' => 'الفاتورة الآجلة أو الجزئية تتطلب عميلاً مسجلاً.',
                ]);
            }

            if ($customer !== null && $customer->credit_limit !== null) {
                $projected = Money::add((string) $customer->balance, $due);

                if (bccomp($projected, (string) $customer->credit_limit, Money::SCALE) > 0
                    && empty($data['override_credit_limit'])) {
                    throw new CreditLimitExceededException($customer, $projected);
                }
            }

            $allowNegativeStock = (bool) ($data['allow_negative_stock'] ?? false);

            if (! $allowNegativeStock) {
                foreach ($items as $it) {
                    if ($it['product'] !== null && $this->stock->wouldGoNegative($it['product'], Money::mul($it['qty'], '-1'))) {
                        throw new InsufficientStockException(
                            $it['product'],
                            Money::sub((string) $it['product']->stock_qty, $it['qty'])
                        );
                    }
                }
            }

            $invoice = new Invoice();
            $invoice->forceFill([
                'number' => $this->sequences->next('invoice'),
                'customer_id' => $customer?->id,
                'status' => $this->statusFor($due, $paid),
                'issued_at' => now(),
                'subtotal' => $total,
                'discount' => '0',
                'tax' => '0',
                'total' => $total,
                'paid_amount' => $paid,
                'due_amount' => $due,
                'created_by' => $actor->id,
            ]);
            $invoice->save();

            foreach ($items as $it) {
                $invoice->items()->create(Arr::except($it, ['product']));

                if ($it['product'] !== null) {
                    $this->stock->move(
                        product: $it['product'],
                        qty: Money::mul($it['qty'], '-1'),
                        type: 'sale',
                        sourceType: Invoice::class,
                        sourceId: $invoice->id,
                        allowNegative: $allowNegativeStock,
                    );
                }
            }

            if ($customer !== null && ! Money::isZero($due)) {
                CustomerLedgerEntry::create([
                    'customer_id' => $customer->id,
                    'source_type' => 'invoice',
                    'source_id' => $invoice->id,
                    'description' => 'فاتورة '.$invoice->number,
                    'debit' => $due,
                    'credit' => '0',
                    'occurred_at' => now(),
                    'created_by' => $actor->id,
                ]);
                $customer->forceFill(['balance' => Money::add((string) $customer->balance, $due)])->save();
            }

            return $invoice->fresh('items');
        });
    }

    /**
     * @param  array<int, array<string, mixed>>  $rawItems
     * @return \Illuminate\Support\Collection<int, array<string, mixed>>
     */
    private function prepareItems(array $rawItems): \Illuminate\Support\Collection
    {
        return collect($rawItems)->map(function (array $raw): array {
            $product = isset($raw['product_id'])
                ? Product::query()->lockForUpdate()->find($raw['product_id'])
                : null;

            $qty = (string) $raw['qty'];
            $unitPrice = (string) $raw['unit_price'];
            $discount = (string) ($raw['discount'] ?? '0');
            $lineTotal = Money::sub(Money::mul($qty, $unitPrice), $discount);

            return [
                'product' => $product,
                'product_id' => $product?->id,
                'product_name' => $product?->name ?? (string) ($raw['product_name'] ?? 'صنف'),
                'unit_name' => $product?->unit?->name,
                'qty' => $qty,
                'unit_price' => $unitPrice,
                // لقطة التكلفة في لحظة البيع بالضبط — لا تتغير حتى لو تغيّرت تكلفة المنتج لاحقاً
                'unit_cost' => $product !== null ? (string) $product->cost_price : '0',
                'discount' => $discount,
                'line_total' => $lineTotal,
            ];
        });
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array{0: string, 1: string}
     */
    private function resolvePayment(array $data, string $total): array
    {
        $payWay = (string) ($data['pay_way'] ?? 'credit');
        $methodMap = [
            'cash_full' => 'cash', 'cash_partial' => 'cash',
            'transfer_full' => 'transfer', 'transfer_partial' => 'transfer',
            'other_full' => 'other', 'credit' => 'cash',
        ];
        $method = $methodMap[$payWay] ?? 'cash';

        $paid = match (true) {
            $payWay === 'credit' => '0',
            str_ends_with($payWay, '_partial') => Money::min($total, (string) ($data['paid_amount'] ?? '0')),
            default => $total,
        };

        return [$paid, $method];
    }

    private function statusFor(string $due, string $paid): string
    {
        if (Money::isZero($due)) {
            return 'paid';
        }

        return Money::isZero($paid) ? 'issued' : 'partially_paid';
    }
}
