<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Actions;

use App\Core\Money\Money;
use App\Models\User;
use App\Modules\Catalog\Models\Product;
use App\Modules\Customers\Models\Customer;
use App\Modules\Customers\Models\CustomerLedgerEntry;
use App\Modules\Inventory\Services\StockService;
use App\Modules\Invoicing\Models\Invoice;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * يلغي فاتورة صادرة. القرار الأهم هنا هو كيف نتعامل مع ما جُمع منها فعلاً:
 *
 * - paid_amount لا يُعدَّل أبداً إلى غير قيمته الحقيقية. كان هذا أخطر خلل اكتُشف
 *   في النموذج الأولي: الإلغاء كان يكتب فوق المبلغ المحصَّل الحقيقي بقيمة الإجمالي
 *   كاملاً، فيختفي أثر ما حُصِّل فعلاً من السجلات نهائياً — لا يُرد للعميل ولا
 *   ينعكس كرصيد.
 * - $creditCustomerForPaidAmount يحدّد صراحة: هل يتحول المبلغ المحصَّل مسبقاً إلى
 *   رصيد دائن للعميل (true)، أم أنه أُرجع له نقداً خارج النظام فلا يمسّ رصيده (false)؟
 *   هذا قرار تجاري يجب أن يُسأل عنه المستخدم دائماً، لا افتراض آلي.
 * - الجزء غير المحصَّل (due_amount) يُعكس تلقائياً بلا حاجة لسؤال، لأنه لم يكن
 *   نقداً حقيقياً أصلاً.
 */
final class VoidInvoice
{
    public function __construct(private readonly StockService $stock)
    {
    }

    public function handle(Invoice $invoice, User $actor, string $reason, bool $creditCustomerForPaidAmount): Invoice
    {
        return DB::transaction(function () use ($invoice, $actor, $reason, $creditCustomerForPaidAmount): Invoice {
            if ($invoice->status === 'void') {
                throw new RuntimeException('Invoice is already void.');
            }

            $customer = $invoice->customer_id !== null
                ? Customer::query()->lockForUpdate()->find($invoice->customer_id)
                : null;

            if ($customer !== null) {
                $reversal = (string) $invoice->due_amount;

                if ($creditCustomerForPaidAmount && ! Money::isZero((string) $invoice->paid_amount)) {
                    $reversal = Money::add($reversal, (string) $invoice->paid_amount);
                }

                if (! Money::isZero($reversal)) {
                    CustomerLedgerEntry::create([
                        'customer_id' => $customer->id,
                        'source_type' => 'invoice_void',
                        'source_id' => $invoice->id,
                        'description' => 'إلغاء فاتورة '.$invoice->number
                            .($creditCustomerForPaidAmount ? ' (مع تحويل المحصَّل لرصيد دائن)' : ''),
                        'debit' => '0',
                        'credit' => $reversal,
                        'occurred_at' => now(),
                        'created_by' => $actor->id,
                    ]);
                    $customer->forceFill(['balance' => Money::sub((string) $customer->balance, $reversal)])->save();
                }
            }

            foreach ($invoice->items as $item) {
                if ($item->product_id === null) {
                    continue;
                }

                $product = Product::query()->lockForUpdate()->find($item->product_id);

                if ($product !== null) {
                    $this->stock->move(
                        product: $product,
                        qty: (string) $item->qty, // إعادة كمية موجبة دائماً — لا خطر سلبية هنا
                        type: 'sale_void',
                        sourceType: Invoice::class,
                        sourceId: $invoice->id,
                    );
                }
            }

            $invoice->forceFill([
                'status' => 'void',
                'voided_at' => now(),
                'voided_by' => $actor->id,
                'void_reason' => $reason,
                'due_amount' => '0',
            ])->save();

            return $invoice;
        });
    }
}
