<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Exceptions;

use App\Modules\Customers\Models\Customer;
use RuntimeException;

/**
 * يُرمى عند تجاوز الحد الائتماني بلا إذن صريح (override_credit_limit=true).
 * الواجهة تلتقطه وتعرض تأكيداً للمستخدم بدل رفض العملية نهائياً —
 * صاحب النشاط قد يقرر البيع رغم التجاوز لعميل يثق به.
 */
final class CreditLimitExceededException extends RuntimeException
{
    public function __construct(public readonly Customer $customer, public readonly string $projectedBalance)
    {
        parent::__construct("Credit limit exceeded for customer [{$customer->id}]: projected balance {$projectedBalance}");
    }
}
