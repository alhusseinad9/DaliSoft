<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Http\Controllers;

use App\Modules\Inventory\Exceptions\InsufficientStockException;
use App\Modules\Invoicing\Actions\IssueInvoice;
use App\Modules\Invoicing\Actions\VoidInvoice;
use App\Modules\Invoicing\Exceptions\CreditLimitExceededException;
use App\Modules\Invoicing\Http\Requests\StoreInvoiceRequest;
use App\Modules\Invoicing\Http\Requests\VoidInvoiceRequest;
use App\Modules\Invoicing\Http\Resources\InvoiceResource;
use App\Modules\Invoicing\Models\Invoice;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

final class InvoiceController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Invoice::class);

        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $invoices = Invoice::query()
            ->with('customer:id,public_id,name')
            ->when($request->filled('customer_id'), fn ($q) => $q->whereHas(
                'customer',
                fn ($c) => $c->where('public_id', $request->query('customer_id'))
            ))
            ->when($request->filled('from'), fn ($q) => $q->where('issued_at', '>=', $request->query('from')))
            ->when($request->filled('to'), fn ($q) => $q->where('issued_at', '<=', $request->query('to')))
            ->orderByDesc('issued_at')
            ->cursorPaginate($perPage);

        return InvoiceResource::collection($invoices);
    }

    public function store(StoreInvoiceRequest $request, IssueInvoice $action): JsonResponse
    {
        $this->authorize('create', Invoice::class);

        $data = $request->validated();

        if (! empty($data['override_credit_limit']) && ! $request->user()->can('customers.exceed_credit_limit')) {
            unset($data['override_credit_limit']);
        }

        try {
            $invoice = $action->handle($data, $request->user());
        } catch (CreditLimitExceededException $e) {
            return response()->json([
                'message' => 'هذه الفاتورة تتجاوز الحد الائتماني للعميل.',
                'code' => 'credit_limit_exceeded',
                'requires_confirmation' => 'override_credit_limit',
                'projected_balance' => $e->projectedBalance,
            ], 422);
        } catch (InsufficientStockException $e) {
            return response()->json([
                'message' => "الكمية المطلوبة من \"{$e->product->name}\" أكبر من المتوفر بالمخزون.",
                'code' => 'insufficient_stock',
                'requires_confirmation' => 'allow_negative_stock',
                'resulting_balance' => $e->resultingBalance,
            ], 422);
        }

        return InvoiceResource::make($invoice)->response()->setStatusCode(201);
    }

    public function show(Invoice $invoice): InvoiceResource
    {
        $this->authorize('view', $invoice);

        return InvoiceResource::make($invoice->load('items'));
    }

    public function void(VoidInvoiceRequest $request, Invoice $invoice, VoidInvoice $action): InvoiceResource|JsonResponse
    {
        $this->authorize('void', $invoice);

        if ($invoice->status === 'void') {
            return response()->json(['message' => 'الفاتورة ملغاة بالفعل.', 'code' => 'already_void'], 422);
        }

        $hasPaidAmount = bccomp((string) $invoice->paid_amount, '0', 3) > 0;

        if ($hasPaidAmount && ! $request->has('credit_customer_for_paid_amount')) {
            return response()->json([
                'message' => 'هذه الفاتورة محصَّل منها مبلغ فعلياً. حدد كيف تريد معالجته.',
                'code' => 'void_requires_refund_choice',
                'paid_amount' => (string) $invoice->paid_amount,
            ], 422);
        }

        $invoice = $action->handle(
            $invoice,
            $request->user(),
            (string) $request->validated('reason'),
            (bool) $request->boolean('credit_customer_for_paid_amount'),
        );

        return InvoiceResource::make($invoice->load('items'));
    }
}
