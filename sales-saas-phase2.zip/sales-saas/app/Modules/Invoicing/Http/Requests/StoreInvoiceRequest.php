<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreInvoiceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'customer_id' => ['nullable', 'integer', 'exists:customers,id'],
            'pay_way' => ['required', 'in:cash_full,transfer_full,cash_partial,transfer_partial,credit,other_full'],
            'paid_amount' => ['required_if:pay_way,cash_partial,transfer_partial', 'nullable', 'decimal:0,3', 'min:0'],
            'override_credit_limit' => ['sometimes', 'boolean'],
            'allow_negative_stock' => ['sometimes', 'boolean'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['nullable', 'integer', 'exists:products,id'],
            'items.*.product_name' => ['required_without:items.*.product_id', 'nullable', 'string', 'max:150'],
            'items.*.qty' => ['required', 'decimal:0,3', 'gt:0'],
            'items.*.unit_price' => ['required', 'decimal:0,3', 'min:0'],
            'items.*.discount' => ['sometimes', 'decimal:0,3', 'min:0'],
        ];
    }
}
