<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class VoidInvoiceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'reason' => ['required', 'string', 'max:255'],
            // مطلوب صراحة فقط إذا كان على الفاتورة مبلغ محصَّل فعلاً؛ يتحقق منه الـ Controller بدل قاعدة ثابتة هنا
            'credit_customer_for_paid_amount' => ['sometimes', 'boolean'],
        ];
    }
}
