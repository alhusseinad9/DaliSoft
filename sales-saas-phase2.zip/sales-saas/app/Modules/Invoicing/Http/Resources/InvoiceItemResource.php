<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class InvoiceItemResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'product_id' => $this->product?->public_id,
            'product_name' => $this->product_name,
            'unit_name' => $this->unit_name,
            'qty' => $this->qty,
            'unit_price' => $this->unit_price,
            'discount' => $this->discount,
            'line_total' => $this->line_total,
            // unit_cost متعمّد إخفاؤه هنا: التكلفة والربح معلومة حساسة، تظهر فقط عبر مسار له صلاحية reports.profit.view
        ];
    }
}
