<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class InvoiceResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        $showProfit = $request->user()?->can('reports.profit.view') ?? false;

        return [
            'id' => $this->public_id,
            'number' => $this->number,
            'customer_id' => $this->customer?->public_id,
            'customer_name' => $this->customer?->name,
            'status' => $this->status,
            'issued_at' => $this->issued_at?->toIso8601String(),
            'total' => $this->total,
            'paid_amount' => $this->paid_amount,
            'due_amount' => $this->due_amount,
            'voided_at' => $this->voided_at?->toIso8601String(),
            'void_reason' => $this->void_reason,
            'items' => InvoiceItemResource::collection($this->whenLoaded('items')),
            // الربح التقديري معلومة حساسة — تظهر فقط لمن يملك صلاحية عرض الأرباح (المالك عادة)
            'estimated_profit' => $this->when($showProfit, fn () => $this->estimatedProfit()),
        ];
    }
}
