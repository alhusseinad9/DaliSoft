<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Models;

use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Customers\Models\Customer;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * الفاتورة الصادرة لا تُعدَّل بعد الإصدار؛ التصحيح بالإلغاء (void) أو مرتجع.
 * paid_amount يعكس دائماً المبلغ الحقيقي المحصَّل فعلياً — حتى بعد الإلغاء، لا يُعدَّل أبداً
 * إلى غير قيمته الحقيقية (كان هذا أخطر خلل اكتُشف في النموذج الأولي: الإلغاء كان
 * يُفقد أثر المبلغ المحصَّل مسبقاً بالكتابة فوقه).
 */
class Invoice extends Model
{
    use BelongsToBusiness, HasPublicId;

    protected $fillable = [
        'customer_id', 'order_id', 'status', 'issued_at',
        'subtotal', 'discount', 'tax', 'total', 'paid_amount', 'due_amount', 'cost_total', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'issued_at' => 'datetime',
            'subtotal' => 'decimal:3',
            'discount' => 'decimal:3',
            'tax' => 'decimal:3',
            'total' => 'decimal:3',
            'paid_amount' => 'decimal:3',
            'due_amount' => 'decimal:3',
            'cost_total' => 'decimal:3',
            'voided_at' => 'datetime',
        ];
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    /** الربح التقديري لهذه الفاتورة = الإيراد ناقص التكلفة المحفوظة وقت البيع (لا تتأثر بتغيّر تكلفة المنتج لاحقاً) */
    public function estimatedProfit(): string
    {
        return $this->items->reduce(
            fn (string $sum, InvoiceItem $item) => bcadd($sum, $item->lineProfit(), 3),
            '0'
        );
    }
}
