<?php

declare(strict_types=1);

namespace App\Modules\Invoicing\Models;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Catalog\Models\Product;
use App\Modules\Returns\Models\SalesReturnItem;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * unit_cost: لقطة من تكلفة المنتج في لحظة البيع بالضبط — وليس تكلفته الحالية.
 * هذا هو الحقل الذي كان غائباً تماماً في النموذج الأولي، فجعل أي تقرير أرباح
 * مستقبلي يحسب فواتير قديمة بتكلفة اليوم بدل تكلفة يوم البيع الحقيقية.
 */
class InvoiceItem extends Model
{
    use BelongsToBusiness;

    protected $fillable = [
        'invoice_id', 'product_id', 'product_name', 'unit_name',
        'qty', 'unit_price', 'unit_cost', 'discount', 'line_total',
    ];

    protected function casts(): array
    {
        return [
            'qty' => 'decimal:3',
            'unit_price' => 'decimal:3',
            'unit_cost' => 'decimal:3',
            'discount' => 'decimal:3',
            'line_total' => 'decimal:3',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function salesReturnItems(): HasMany
    {
        return $this->hasMany(SalesReturnItem::class);
    }

    /** الربح بعد استبعاد ما أُرجع من هذا البند (مرتجعات غير ملغاة فقط). */
    public function lineProfit(): string
    {
        $returned = (string) $this->salesReturnItems()
            ->whereHas('salesReturn', fn ($q) => $q->where('status', '!=', 'void'))
            ->sum('qty');

        $netQty = bcsub((string) $this->qty, $returned, 3);

        if (bccomp($netQty, '0', 3) <= 0) {
            return '0.000';
        }

        $unitMargin = bcsub((string) $this->unit_price, (string) $this->unit_cost, 3);
        $proratedDiscount = bccomp((string) $this->qty, '0', 3) > 0
            ? bcmul((string) $this->discount, bcdiv($netQty, (string) $this->qty, 6), 3)
            : '0';

        return bcsub(bcmul($netQty, $unitMargin, 3), $proratedDiscount, 3);
    }
}
