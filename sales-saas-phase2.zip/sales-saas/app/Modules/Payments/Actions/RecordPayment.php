<?php

declare(strict_types=1);

namespace App\Modules\Payments\Actions;

use App\Core\Money\Money;
use App\Core\Sequences\SequenceService;
use App\Models\User;
use App\Modules\Customers\Models\Customer;
use App\Modules\Customers\Models\CustomerLedgerEntry;
use App\Modules\Invoicing\Models\Invoice;
use App\Modules\Payments\Models\Payment;
use App\Modules\Payments\Models\PaymentAllocation;
use Illuminate\Support\Facades\DB;

/**
 * يسجّل تحصيلاً من عميل، ويوزّعه تلقائياً على فواتيره غير المسدَّدة، الأقدم
 * أولاً (FIFO) — هذا هو الإصلاح الجوهري الذي كان غائباً تماماً في النموذج
 * الأولي: كان التحصيل يُنقص رصيد العميل الإجمالي فقط، بينما تبقى كل فاتورة
 * على حدة تعرض "غير مدفوعة" للأبد لأن paid_amount فيها لم يكن يتحدّث أبداً.
 *
 * أي فائض يتجاوز كل الفواتير المستحقة لا يُفقَد ولا يُخصَّص قسراً — يبقى
 * ببساطة Payment::unallocatedAmount() ويظهر كرصيد دائن ضمن رصيد العميل العام.
 */
final class RecordPayment
{
    public function __construct(private readonly SequenceService $sequences)
    {
    }

    public function handle(Customer $customer, string $amount, string $method, User $actor): Payment
    {
        return DB::transaction(function () use ($customer, $amount, $method, $actor): Payment {
            $customer = Customer::query()->lockForUpdate()->findOrFail($customer->id);

            $payment = Payment::create([
                'number' => $this->sequences->next('payment'),
                'customer_id' => $customer->id,
                'method' => $method,
                'amount' => $amount,
                'paid_at' => now(),
                'status' => 'posted',
                'created_by' => $actor->id,
            ]);

            $remaining = $amount;

            $invoices = Invoice::query()
                ->where('customer_id', $customer->id)
                ->whereNotIn('status', ['void', 'paid', 'draft'])
                ->where('due_amount', '>', 0)
                ->orderBy('issued_at')
                ->lockForUpdate()
                ->get();

            foreach ($invoices as $invoice) {
                if (Money::isZero($remaining)) {
                    break;
                }

                $due = (string) $invoice->due_amount;
                $apply = Money::min($due, $remaining);

                PaymentAllocation::create([
                    'payment_id' => $payment->id,
                    'invoice_id' => $invoice->id,
                    'amount' => $apply,
                ]);

                $newDue = Money::sub($due, $apply);
                $invoice->forceFill([
                    'paid_amount' => Money::add((string) $invoice->paid_amount, $apply),
                    'due_amount' => $newDue,
                    'status' => Money::isZero($newDue) ? 'paid' : 'partially_paid',
                ])->save();

                $remaining = Money::sub($remaining, $apply);
            }

            CustomerLedgerEntry::create([
                'customer_id' => $customer->id,
                'source_type' => 'payment',
                'source_id' => $payment->id,
                'description' => 'تحصيل '.$payment->number,
                'debit' => '0',
                'credit' => $amount,
                'occurred_at' => now(),
                'created_by' => $actor->id,
            ]);
            $customer->forceFill(['balance' => Money::sub((string) $customer->balance, $amount)])->save();

            return $payment->fresh('allocations');
        });
    }
}
