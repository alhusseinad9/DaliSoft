<?php

declare(strict_types=1);

namespace App\Modules\Payments\Http\Controllers;

use App\Modules\Customers\Models\Customer;
use App\Modules\Payments\Actions\RecordPayment;
use App\Modules\Payments\Http\Requests\StorePaymentRequest;
use App\Modules\Payments\Http\Resources\PaymentResource;
use App\Modules\Payments\Models\Payment;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

final class PaymentController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Payment::class);

        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $payments = Payment::query()
            ->with('customer:id,public_id,name,balance')
            ->orderByDesc('paid_at')
            ->cursorPaginate($perPage);

        return PaymentResource::collection($payments);
    }

    public function store(StorePaymentRequest $request, RecordPayment $action): JsonResponse
    {
        $this->authorize('create', Payment::class);

        $customer = Customer::query()->findOrFail($request->validated('customer_id'));

        $payment = $action->handle(
            $customer,
            (string) $request->validated('amount'),
            (string) $request->validated('method'),
            $request->user(),
        );

        return PaymentResource::make($payment->load('customer'))->response()->setStatusCode(201);
    }
}
