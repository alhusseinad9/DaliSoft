<?php

declare(strict_types=1);

namespace App\Modules\Payments\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class PaymentResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'number' => $this->number,
            'customer_id' => $this->customer?->public_id,
            'customer_name' => $this->customer?->name,
            'amount' => $this->amount,
            'method' => $this->method,
            'paid_at' => $this->paid_at?->toIso8601String(),
            'unallocated_amount' => $this->unallocatedAmount(),
            'customer_balance_after' => $this->customer?->balance,
        ];
    }
}
