<?php

declare(strict_types=1);

namespace App\Modules\Payments\Models;

use App\Core\Money\Money;
use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Customers\Models\Customer;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Payment extends Model
{
    use BelongsToBusiness, HasPublicId;

    protected $fillable = ['customer_id', 'method', 'amount', 'paid_at', 'status', 'notes'];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:3',
            'paid_at' => 'datetime',
            'voided_at' => 'datetime',
        ];
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function allocations(): HasMany
    {
        return $this->hasMany(PaymentAllocation::class);
    }

    /**
     * الجزء من الدفعة الذي لم يُطبَّق على أي فاتورة (فائض تحول لرصيد دائن للعميل).
     * يُحسَب دائماً من العلاقة، لا يُخزَّن — فلا يمكن أن ينحرف عن الحقيقة.
     */
    public function unallocatedAmount(): string
    {
        $allocated = $this->allocations()->sum('amount');

        return Money::max(Money::sub((string) $this->amount, (string) $allocated), '0');
    }
}
