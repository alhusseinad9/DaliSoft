<?php

use App\Modules\Payments\Http\Controllers\PaymentController;
use Illuminate\Support\Facades\Route;

Route::get('payments', [PaymentController::class, 'index'])->name('payments.index');
Route::post('payments', [PaymentController::class, 'store'])->middleware('idempotent')->name('payments.store');
