<?php

declare(strict_types=1);

namespace App\Modules\Purchasing\Actions;

use App\Core\Money\Money;
use App\Core\Sequences\SequenceService;
use App\Models\User;
use App\Modules\Catalog\Models\Product;
use App\Modules\Inventory\Services\StockService;
use App\Modules\Purchasing\Models\PurchaseInvoice;
use App\Modules\Suppliers\Models\Supplier;
use App\Modules\Suppliers\Models\SupplierLedgerEntry;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * يصدر فاتورة شراء: يزيد المخزون (الشراء لا يخاطر بالسالب أبداً، فلا حاجة لتحقق
 * توفر)، يحدّث تكلفة المنتج الحالية (cost_price) لتعكس آخر سعر شراء، ويرفع
 * رصيد المورد بالمبلغ غير المدفوع — بنفس اتجاه رصيد العميل بالضبط (balance
 * سالب = نحن مدينون له)، وهو الإصلاح الذي صحّح خللاً حقيقياً في النموذج الأولي.
 */
final class IssuePurchaseInvoice
{
    public function __construct(
        private readonly SequenceService $sequences,
        private readonly StockService $stock,
    ) {
    }

    /** @param  array<string, mixed>  $data */
    public function handle(array $data, User $actor): PurchaseInvoice
    {
        return DB::transaction(function () use ($data, $actor): PurchaseInvoice {
            $supplier = isset($data['supplier_id'])
                ? Supplier::query()->lockForUpdate()->findOrFail($data['supplier_id'])
                : null;

            $items = collect($data['items'])->map(function (array $raw): array {
                $product = isset($raw['product_id'])
                    ? Product::query()->lockForUpdate()->find($raw['product_id'])
                    : null;

                $qty = (string) $raw['qty'];
                $unitCost = (string) $raw['unit_cost'];

                return [
                    'product' => $product,
                    'product_id' => $product?->id,
                    'product_name' => $product?->name ?? (string) ($raw['product_name'] ?? 'صنف'),
                    'qty' => $qty,
                    'unit_cost' => $unitCost,
                    'line_total' => Money::mul($qty, $unitCost),
                ];
            });

            $total = $items->reduce(fn (string $sum, array $it) => Money::add($sum, $it['line_total']), '0');

            $payWay = (string) ($data['pay_way'] ?? 'credit');
            $paid = match (true) {
                $payWay === 'credit' => '0',
                $payWay === 'partial' => Money::min($total, (string) ($data['paid_amount'] ?? '0')),
                default => $total,
            };
            $due = Money::max(Money::sub($total, $paid), '0');

            if (! Money::isZero($due) && $supplier === null) {
                throw ValidationException::withMessages([
                    'supplier_id' => 'فاتورة الشراء غير المدفوعة بالكامل تتطلب مورداً محدداً.',
                ]);
            }

            $invoice = new PurchaseInvoice();
            $invoice->forceFill([
                'number' => $this->sequences->next('purchase_invoice'),
                'supplier_id' => $supplier?->id,
                'status' => Money::isZero($due) ? 'paid' : (Money::isZero($paid) ? 'issued' : 'partially_paid'),
                'issued_at' => now(),
                'total' => $total,
                'paid_amount' => $paid,
                'due_amount' => $due,
                'created_by' => $actor->id,
            ]);
            $invoice->save();

            foreach ($items as $it) {
                $invoice->items()->create(Arr::except($it, ['product']));

                if ($it['product'] !== null) {
                    // الشراء يزيد المخزون ويحدّث تكلفة المنتج الحالية لآخر سعر شراء
                    $it['product']->forceFill(['cost_price' => $it['unit_cost']])->save();
                    $this->stock->move(
                        product: $it['product'],
                        qty: $it['qty'],
                        type: 'purchase',
                        sourceType: PurchaseInvoice::class,
                        sourceId: $invoice->id,
                        unitCost: $it['unit_cost'],
                    );
                }
            }

            if ($supplier !== null && ! Money::isZero($due)) {
                SupplierLedgerEntry::create([
                    'supplier_id' => $supplier->id,
                    'source_type' => 'purchase_invoice',
                    'source_id' => $invoice->id,
                    'description' => 'فاتورة مشتريات '.$invoice->number,
                    'debit' => $due,
                    'credit' => '0',
                    'occurred_at' => now(),
                    'created_by' => $actor->id,
                ]);
                // سالب = نحن مدينون أكثر للمورد (نفس اتجاه رصيد العميل بالضبط)
                $supplier->forceFill(['balance' => Money::sub((string) $supplier->balance, $due)])->save();
            }

            return $invoice->fresh('items');
        });
    }
}
