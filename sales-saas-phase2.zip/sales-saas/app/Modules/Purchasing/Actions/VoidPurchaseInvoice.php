<?php

declare(strict_types=1);

namespace App\Modules\Purchasing\Actions;

use App\Core\Money\Money;
use App\Models\User;
use App\Modules\Catalog\Models\Product;
use App\Modules\Inventory\Exceptions\InsufficientStockException;
use App\Modules\Inventory\Services\StockService;
use App\Modules\Purchasing\Models\PurchaseInvoice;
use App\Modules\Suppliers\Models\Supplier;
use App\Modules\Suppliers\Models\SupplierLedgerEntry;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * يلغي فاتورة شراء. نفس منطق VoidInvoice بالضبط: paid_amount يبقى محفوظاً كما
 * هو حقيقةً، والمستخدم يختار صراحة هل المبلغ المدفوع مسبقاً يتحول لرصيد دائن
 * لنا عند المورد، أم استُرجع نقداً خارج النظام.
 *
 * عكس كمية شراء سابقة يُنقص المخزون — وقد يكون جزء منها بيع بالفعل، فيحتاج
 * $allowNegativeStock صريحاً لو كانت النتيجة ستنزل تحت الصفر.
 */
final class VoidPurchaseInvoice
{
    public function __construct(private readonly StockService $stock)
    {
    }

    public function handle(
        PurchaseInvoice $invoice,
        User $actor,
        string $reason,
        bool $creditUsForPaidAmount,
        bool $allowNegativeStock = false,
    ): PurchaseInvoice {
        return DB::transaction(function () use ($invoice, $actor, $reason, $creditUsForPaidAmount, $allowNegativeStock): PurchaseInvoice {
            if ($invoice->status === 'void') {
                throw new RuntimeException('Purchase invoice is already void.');
            }

            foreach ($invoice->items as $item) {
                if ($item->product_id === null) {
                    continue;
                }

                $product = Product::query()->lockForUpdate()->find($item->product_id);

                if ($product === null) {
                    continue;
                }

                if (! $allowNegativeStock && $this->stock->wouldGoNegative($product, Money::mul((string) $item->qty, '-1'))) {
                    throw new InsufficientStockException(
                        $product,
                        Money::sub((string) $product->stock_qty, (string) $item->qty)
                    );
                }
            }

            foreach ($invoice->items as $item) {
                if ($item->product_id === null) {
                    continue;
                }

                $product = Product::query()->find($item->product_id);

                if ($product !== null) {
                    $this->stock->move(
                        product: $product,
                        qty: Money::mul((string) $item->qty, '-1'),
                        type: 'adjustment',
                        sourceType: PurchaseInvoice::class,
                        sourceId: $invoice->id,
                        allowNegative: $allowNegativeStock,
                    );
                }
            }

            $supplier = $invoice->supplier_id !== null
                ? Supplier::query()->lockForUpdate()->find($invoice->supplier_id)
                : null;

            if ($supplier !== null) {
                $reversal = (string) $invoice->due_amount;

                if ($creditUsForPaidAmount && ! Money::isZero((string) $invoice->paid_amount)) {
                    $reversal = Money::add($reversal, (string) $invoice->paid_amount);
                }

                if (! Money::isZero($reversal)) {
                    SupplierLedgerEntry::create([
                        'supplier_id' => $supplier->id,
                        'source_type' => 'purchase_invoice_void',
                        'source_id' => $invoice->id,
                        'description' => 'إلغاء فاتورة مشتريات '.$invoice->number
                            .($creditUsForPaidAmount ? ' (مع تحويل المدفوع لرصيد دائن لنا)' : ''),
                        'debit' => '0',
                        'credit' => $reversal,
                        'occurred_at' => now(),
                        'created_by' => $actor->id,
                    ]);
                    // عكس "سالب = نحن مدينون" يعني أننا ندين أقل الآن، فيزيد الرصيد
                    $supplier->forceFill(['balance' => Money::add((string) $supplier->balance, $reversal)])->save();
                }
            }

            $invoice->forceFill([
                'status' => 'void',
                'voided_at' => now(),
                'voided_by' => $actor->id,
                'void_reason' => $reason,
                'due_amount' => '0',
            ])->save();

            return $invoice;
        });
    }
}
