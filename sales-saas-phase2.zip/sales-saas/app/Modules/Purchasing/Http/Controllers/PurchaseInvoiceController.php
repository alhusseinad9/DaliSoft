<?php

declare(strict_types=1);

namespace App\Modules\Purchasing\Http\Controllers;

use App\Modules\Inventory\Exceptions\InsufficientStockException;
use App\Modules\Purchasing\Actions\IssuePurchaseInvoice;
use App\Modules\Purchasing\Actions\VoidPurchaseInvoice;
use App\Modules\Purchasing\Http\Requests\StorePurchaseInvoiceRequest;
use App\Modules\Purchasing\Http\Requests\VoidPurchaseInvoiceRequest;
use App\Modules\Purchasing\Http\Resources\PurchaseInvoiceResource;
use App\Modules\Purchasing\Models\PurchaseInvoice;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

final class PurchaseInvoiceController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', PurchaseInvoice::class);

        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $invoices = PurchaseInvoice::query()
            ->with('supplier:id,public_id,name')
            ->orderByDesc('issued_at')
            ->cursorPaginate($perPage);

        return PurchaseInvoiceResource::collection($invoices);
    }

    public function store(StorePurchaseInvoiceRequest $request, IssuePurchaseInvoice $action): JsonResponse
    {
        $this->authorize('create', PurchaseInvoice::class);

        $invoice = $action->handle($request->validated(), $request->user());

        return PurchaseInvoiceResource::make($invoice)->response()->setStatusCode(201);
    }

    public function show(PurchaseInvoice $purchaseInvoice): PurchaseInvoiceResource
    {
        $this->authorize('view', $purchaseInvoice);

        return PurchaseInvoiceResource::make($purchaseInvoice->load('items'));
    }

    public function void(VoidPurchaseInvoiceRequest $request, PurchaseInvoice $purchaseInvoice, VoidPurchaseInvoice $action): PurchaseInvoiceResource|JsonResponse
    {
        $this->authorize('void', $purchaseInvoice);

        if ($purchaseInvoice->status === 'void') {
            return response()->json(['message' => 'الفاتورة ملغاة بالفعل.', 'code' => 'already_void'], 422);
        }

        $hasPaidAmount = bccomp((string) $purchaseInvoice->paid_amount, '0', 3) > 0;

        if ($hasPaidAmount && ! $request->has('credit_us_for_paid_amount')) {
            return response()->json([
                'message' => 'دُفع مبلغ فعلياً على هذه الفاتورة. حدد كيف تريد معالجته.',
                'code' => 'void_requires_refund_choice',
                'paid_amount' => (string) $purchaseInvoice->paid_amount,
            ], 422);
        }

        try {
            $purchaseInvoice = $action->handle(
                $purchaseInvoice,
                $request->user(),
                (string) $request->validated('reason'),
                (bool) $request->boolean('credit_us_for_paid_amount'),
                (bool) $request->boolean('allow_negative_stock'),
            );
        } catch (InsufficientStockException $e) {
            return response()->json([
                'message' => "إلغاء الفاتورة سيُنقص مخزون \"{$e->product->name}\" تحت الصفر (رُبما بيع بالفعل).",
                'code' => 'insufficient_stock',
                'requires_confirmation' => 'allow_negative_stock',
                'resulting_balance' => $e->resultingBalance,
            ], 422);
        }

        return PurchaseInvoiceResource::make($purchaseInvoice->load('items'));
    }
}
