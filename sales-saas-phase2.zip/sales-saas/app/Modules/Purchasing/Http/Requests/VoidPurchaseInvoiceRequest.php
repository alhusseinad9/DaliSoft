<?php

declare(strict_types=1);

namespace App\Modules\Purchasing\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class VoidPurchaseInvoiceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'reason' => ['required', 'string', 'max:255'],
            'credit_us_for_paid_amount' => ['sometimes', 'boolean'],
            'allow_negative_stock' => ['sometimes', 'boolean'],
        ];
    }
}
