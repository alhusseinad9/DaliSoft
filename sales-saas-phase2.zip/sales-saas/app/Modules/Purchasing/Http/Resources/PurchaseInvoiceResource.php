<?php

declare(strict_types=1);

namespace App\Modules\Purchasing\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class PurchaseInvoiceResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'number' => $this->number,
            'supplier_id' => $this->supplier?->public_id,
            'supplier_name' => $this->supplier?->name,
            'status' => $this->status,
            'issued_at' => $this->issued_at?->toIso8601String(),
            'total' => $this->total,
            'paid_amount' => $this->paid_amount,
            'due_amount' => $this->due_amount,
            'voided_at' => $this->voided_at?->toIso8601String(),
            'void_reason' => $this->void_reason,
            'items' => PurchaseInvoiceItemResource::collection($this->whenLoaded('items')),
        ];
    }
}
