<?php

declare(strict_types=1);

namespace App\Modules\Purchasing\Models;

use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Suppliers\Models\Supplier;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PurchaseInvoice extends Model
{
    use BelongsToBusiness, HasPublicId;

    protected $fillable = [
        'supplier_id', 'status', 'issued_at', 'total', 'paid_amount', 'due_amount',
    ];

    protected function casts(): array
    {
        return [
            'issued_at' => 'datetime',
            'total' => 'decimal:3',
            'paid_amount' => 'decimal:3',
            'due_amount' => 'decimal:3',
            'voided_at' => 'datetime',
        ];
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(PurchaseInvoiceItem::class);
    }
}
