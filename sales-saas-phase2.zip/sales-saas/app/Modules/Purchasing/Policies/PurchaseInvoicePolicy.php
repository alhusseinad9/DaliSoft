<?php

declare(strict_types=1);

namespace App\Modules\Purchasing\Policies;

use App\Models\User;
use App\Modules\Purchasing\Models\PurchaseInvoice;

final class PurchaseInvoicePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('purchase_invoices.view');
    }

    public function view(User $user, PurchaseInvoice $invoice): bool
    {
        return $user->can('purchase_invoices.view');
    }

    public function create(User $user): bool
    {
        return $user->can('purchase_invoices.create');
    }

    public function void(User $user, PurchaseInvoice $invoice): bool
    {
        return $user->can('purchase_invoices.void');
    }
}
