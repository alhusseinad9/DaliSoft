<?php

use App\Modules\Purchasing\Http\Controllers\PurchaseInvoiceController;
use Illuminate\Support\Facades\Route;

Route::get('purchase-invoices', [PurchaseInvoiceController::class, 'index'])->name('purchase-invoices.index');
Route::post('purchase-invoices', [PurchaseInvoiceController::class, 'store'])->middleware('idempotent')->name('purchase-invoices.store');
Route::get('purchase-invoices/{purchaseInvoice}', [PurchaseInvoiceController::class, 'show'])->name('purchase-invoices.show');
Route::post('purchase-invoices/{purchaseInvoice}/void', [PurchaseInvoiceController::class, 'void'])->name('purchase-invoices.void');
