<?php

declare(strict_types=1);

namespace App\Modules\Reports\Http\Controllers;

use App\Core\Money\Money;
use App\Modules\Customers\Models\Customer;
use App\Modules\Expenses\Models\Expense;
use App\Modules\Invoicing\Models\Invoice;
use App\Modules\Payments\Models\Payment;
use App\Modules\Returns\Models\SalesReturn;
use App\Modules\Suppliers\Models\Supplier;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

/**
 * ملخص مالي مبسّط. نفس احتياطات الدقة المطبَّقة بكل مكان آخر بالنظام:
 * - الفواتير الملغاة مستبعدة من كل الإجماليات (لم تكن مستبعدة في النموذج الأولي).
 * - "المحصَّل" = مجموع paid_amount للفواتير النشطة + الفائض غير المخصَّص من
 *   الدفعات (unallocatedAmount) — وليس مجموع الفواتير + مجموع الدفعات معاً،
 *   لأن ذلك كان يُحسب التحصيل اللاحق مرتين بعد ربطه بالفواتير.
 * - الربح يعتمد على unit_cost المحفوظ وقت البيع، فلا يتأثر بتغيّر التكلفة لاحقاً.
 */
final class ReportsController
{
    public function index(Request $request): JsonResponse
    {
        Gate::authorize('reports.view');

        $from = $request->query('from');
        $to = $request->query('to');

        $invoices = Invoice::query()
            ->with('items')
            ->where('status', '!=', 'void')
            ->when($from, fn ($q) => $q->where('issued_at', '>=', $from))
            ->when($to, fn ($q) => $q->where('issued_at', '<=', $to))
            ->get();

        $totalSales = $invoices->reduce(fn (string $sum, Invoice $i) => Money::add($sum, (string) $i->total), '0');
        $totalCollectedViaInvoices = $invoices->reduce(fn (string $sum, Invoice $i) => Money::add($sum, (string) $i->paid_amount), '0');
        $totalUnallocated = Payment::query()
            ->when($from, fn ($q) => $q->where('paid_at', '>=', $from))
            ->when($to, fn ($q) => $q->where('paid_at', '<=', $to))
            ->get()
            ->reduce(fn (string $sum, Payment $p) => Money::add($sum, $p->unallocatedAmount()), '0');
        $totalCollected = Money::add($totalCollectedViaInvoices, $totalUnallocated);

        $totalReturns = SalesReturn::query()
            ->where('status', '!=', 'void')
            ->when($from, fn ($q) => $q->where('returned_at', '>=', $from))
            ->when($to, fn ($q) => $q->where('returned_at', '<=', $to))
            ->get()
            ->reduce(fn (string $sum, SalesReturn $r) => Money::add($sum, (string) $r->total), '0');

        $totalExpenses = Expense::query()
            ->where('status', '!=', 'void')
            ->when($from, fn ($q) => $q->where('spent_at', '>=', $from))
            ->when($to, fn ($q) => $q->where('spent_at', '<=', $to))
            ->sum('amount');

        $data = [
            'total_sales' => $totalSales,
            'total_collected' => $totalCollected,
            'total_returns' => $totalReturns,
            'total_expenses' => (string) $totalExpenses,
            'customers_owe_us' => (string) Customer::query()->where('balance', '>', 0)->sum('balance'),
            'we_owe_suppliers' => bcmul((string) Supplier::query()->where('balance', '<', 0)->sum('balance'), '-1', Money::SCALE),
        ];

        if ($request->user()->can('reports.profit.view')) {
            $grossProfit = $invoices->reduce(fn (string $sum, Invoice $i) => Money::add($sum, $i->estimatedProfit()), '0');
            $data['gross_profit'] = $grossProfit;
            $data['net_profit'] = Money::sub($grossProfit, (string) $totalExpenses);
        }

        return response()->json(['data' => $data]);
    }
}
