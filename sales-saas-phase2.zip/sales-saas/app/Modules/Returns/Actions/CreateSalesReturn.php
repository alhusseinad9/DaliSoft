<?php

declare(strict_types=1);

namespace App\Modules\Returns\Actions;

use App\Core\Money\Money;
use App\Core\Sequences\SequenceService;
use App\Models\User;
use App\Modules\Catalog\Models\Product;
use App\Modules\Customers\Models\Customer;
use App\Modules\Customers\Models\CustomerLedgerEntry;
use App\Modules\Inventory\Services\StockService;
use App\Modules\Invoicing\Models\Invoice;
use App\Modules\Invoicing\Models\InvoiceItem;
use App\Modules\Returns\Models\SalesReturn;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * يسجّل مرتجعاً على فاتورة صادرة (غير ملغاة). الكمية المسموح إرجاعها محدودة
 * بـ (المباع − المرتجع سابقاً) لكل بند — يستحيل إرجاع أكثر مما بيع فعلياً.
 *
 * refund_method يحدّد الأثر على رصيد العميل صراحة:
 * - credit: يُخصم من دين العميل (أو يزيد رصيده الدائن)
 * - cash: أُرجع نقداً خارج النظام، لا يمسّ الرصيد
 * نفس القرار الذي نسأل عنه عند إلغاء الفاتورة بالضبط — اتساق متعمّد.
 */
final class CreateSalesReturn
{
    public function __construct(
        private readonly SequenceService $sequences,
        private readonly StockService $stock,
    ) {
    }

    /** @param  array<int, array{invoice_item_id: int, qty: string}>  $items */
    public function handle(Invoice $invoice, array $items, string $refundMethod, ?string $reason, User $actor): SalesReturn
    {
        return DB::transaction(function () use ($invoice, $items, $refundMethod, $reason, $actor): SalesReturn {
            if ($invoice->status === 'void') {
                throw ValidationException::withMessages(['invoice' => 'لا يمكن إنشاء مرتجع على فاتورة ملغاة.']);
            }

            $invoice->loadMissing('items');
            $returnItems = [];
            $total = '0';

            foreach ($items as $raw) {
                /** @var InvoiceItem|null $invoiceItem */
                $invoiceItem = $invoice->items->firstWhere('id', $raw['invoice_item_id']);

                if ($invoiceItem === null) {
                    throw ValidationException::withMessages(['items' => 'بند غير موجود على هذه الفاتورة.']);
                }

                $alreadyReturned = (string) $invoiceItem->salesReturnItems()
                    ->whereHas('salesReturn', fn ($q) => $q->where('status', '!=', 'void'))
                    ->sum('qty');
                $remaining = Money::sub((string) $invoiceItem->qty, $alreadyReturned);
                $qty = (string) $raw['qty'];

                if (bccomp($qty, $remaining, Money::SCALE) > 0) {
                    throw ValidationException::withMessages([
                        'items' => "الكمية المطلوب إرجاعها من \"{$invoiceItem->product_name}\" أكبر من المتاح ({$remaining}).",
                    ]);
                }

                $lineTotal = Money::mul($qty, (string) $invoiceItem->unit_price);
                $total = Money::add($total, $lineTotal);

                $returnItems[] = [
                    'invoice_item_id' => $invoiceItem->id,
                    'product_id' => $invoiceItem->product_id,
                    'qty' => $qty,
                    'unit_price' => (string) $invoiceItem->unit_price,
                    'line_total' => $lineTotal,
                ];
            }

            if ($returnItems === []) {
                throw ValidationException::withMessages(['items' => 'حدد كمية صنف واحد على الأقل.']);
            }

            $return = SalesReturn::create([
                'number' => $this->sequences->next('return'),
                'invoice_id' => $invoice->id,
                'customer_id' => $invoice->customer_id,
                'returned_at' => now(),
                'total' => $total,
                'refund_method' => $refundMethod,
                'reason' => $reason,
                'created_by' => $actor->id,
            ]);

            foreach ($returnItems as $it) {
                $return->items()->create($it);

                $product = $it['product_id'] !== null
                    ? Product::query()->lockForUpdate()->find($it['product_id'])
                    : null;

                if ($product !== null) {
                    $this->stock->move(
                        product: $product,
                        qty: $it['qty'],
                        type: 'return',
                        sourceType: SalesReturn::class,
                        sourceId: $return->id,
                    );
                }
            }

            if ($invoice->customer_id !== null && $refundMethod === 'credit') {
                CustomerLedgerEntry::create([
                    'customer_id' => $invoice->customer_id,
                    'source_type' => 'sales_return',
                    'source_id' => $return->id,
                    'description' => 'مرتجع '.$return->number,
                    'debit' => '0',
                    'credit' => $total,
                    'occurred_at' => now(),
                    'created_by' => $actor->id,
                ]);

                $customer = Customer::query()->lockForUpdate()->find($invoice->customer_id);
                $customer?->forceFill(['balance' => Money::sub((string) $customer->balance, $total)])->save();
            }

            return $return->fresh('items');
        });
    }
}
