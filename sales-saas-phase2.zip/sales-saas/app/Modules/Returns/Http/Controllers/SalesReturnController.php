<?php

declare(strict_types=1);

namespace App\Modules\Returns\Http\Controllers;

use App\Modules\Invoicing\Models\Invoice;
use App\Modules\Returns\Actions\CreateSalesReturn;
use App\Modules\Returns\Http\Requests\StoreSalesReturnRequest;
use App\Modules\Returns\Http\Resources\SalesReturnResource;
use App\Modules\Returns\Models\SalesReturn;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;

final class SalesReturnController
{
    use AuthorizesRequests;

    public function store(StoreSalesReturnRequest $request, Invoice $invoice, CreateSalesReturn $action): JsonResponse
    {
        $this->authorize('create', SalesReturn::class);

        $return = $action->handle(
            $invoice,
            $request->validated('items'),
            (string) $request->validated('refund_method'),
            $request->validated('reason'),
            $request->user(),
        );

        return SalesReturnResource::make($return->load('items.product'))->response()->setStatusCode(201);
    }
}
