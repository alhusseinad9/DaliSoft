<?php

declare(strict_types=1);

namespace App\Modules\Returns\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreSalesReturnRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'refund_method' => ['required', 'in:credit,cash'],
            'reason' => ['nullable', 'string', 'max:255'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.invoice_item_id' => ['required', 'integer'],
            'items.*.qty' => ['required', 'decimal:0,3', 'gt:0'],
        ];
    }
}
