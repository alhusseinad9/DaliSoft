<?php

declare(strict_types=1);

namespace App\Modules\Returns\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class SalesReturnResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'number' => $this->number,
            'invoice_id' => $this->invoice?->public_id,
            'customer_id' => $this->customer?->public_id,
            'returned_at' => $this->returned_at?->toIso8601String(),
            'total' => $this->total,
            'refund_method' => $this->refund_method,
            'reason' => $this->reason,
            'items' => $this->whenLoaded('items', fn () => $this->items->map(fn ($it) => [
                'product_id' => $it->product?->public_id,
                'qty' => $it->qty,
                'unit_price' => $it->unit_price,
                'line_total' => $it->line_total,
            ])),
        ];
    }
}
