<?php

declare(strict_types=1);

namespace App\Modules\Returns\Models;

use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Customers\Models\Customer;
use App\Modules\Invoicing\Models\Invoice;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SalesReturn extends Model
{
    use BelongsToBusiness, HasPublicId;

    protected $fillable = ['invoice_id', 'customer_id', 'returned_at', 'total', 'cost_total', 'refund_method', 'reason'];

    protected function casts(): array
    {
        return [
            'returned_at' => 'datetime',
            'total' => 'decimal:3',
            'cost_total' => 'decimal:3',
        ];
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(SalesReturnItem::class);
    }
}
