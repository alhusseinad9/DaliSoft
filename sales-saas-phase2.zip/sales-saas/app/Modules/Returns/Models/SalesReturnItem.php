<?php

declare(strict_types=1);

namespace App\Modules\Returns\Models;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Catalog\Models\Product;
use App\Modules\Invoicing\Models\InvoiceItem;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SalesReturnItem extends Model
{
    use BelongsToBusiness;

    protected $fillable = ['sales_return_id', 'invoice_item_id', 'product_id', 'qty', 'unit_price', 'line_total'];

    protected function casts(): array
    {
        return ['qty' => 'decimal:3', 'unit_price' => 'decimal:3', 'line_total' => 'decimal:3'];
    }

    public function invoiceItem(): BelongsTo
    {
        return $this->belongsTo(InvoiceItem::class);
    }

    public function salesReturn(): BelongsTo
    {
        return $this->belongsTo(SalesReturn::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
