<?php

declare(strict_types=1);

namespace App\Modules\Returns\Policies;

use App\Models\User;
use App\Modules\Returns\Models\SalesReturn;

final class SalesReturnPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('returns.view');
    }

    public function view(User $user, SalesReturn $return): bool
    {
        return $user->can('returns.view');
    }

    public function create(User $user): bool
    {
        return $user->can('returns.create');
    }
}
