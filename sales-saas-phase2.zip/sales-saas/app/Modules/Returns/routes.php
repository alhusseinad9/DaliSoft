<?php

use App\Modules\Returns\Http\Controllers\SalesReturnController;
use Illuminate\Support\Facades\Route;

Route::post('invoices/{invoice}/returns', [SalesReturnController::class, 'store'])
    ->middleware('idempotent')
    ->name('invoices.returns.store');
