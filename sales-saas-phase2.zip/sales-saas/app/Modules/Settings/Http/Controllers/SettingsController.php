<?php

declare(strict_types=1);

namespace App\Modules\Settings\Http\Controllers;

use App\Core\Modules\BusinessModule;
use App\Core\Tenancy\TenantContext;
use App\Models\Business;
use App\Modules\Settings\Http\Requests\UpdateBusinessRequest;
use App\Modules\Settings\Http\Requests\UpdateModulesRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

final class SettingsController
{
    public function __construct(private readonly TenantContext $tenant)
    {
    }

    public function show(): JsonResponse
    {
        Gate::authorize('settings.view');

        $business = Business::query()->findOrFail($this->tenant->requireId());
        $modules = BusinessModule::query()->pluck('enabled', 'module');

        return response()->json(['data' => [
            'name' => $business->name,
            'phone' => $business->phone,
            'address' => $business->address,
            'currency' => $business->currency,
            'modules' => $modules,
        ]]);
    }

    public function update(UpdateBusinessRequest $request): JsonResponse
    {
        Gate::authorize('settings.edit');

        $business = Business::query()->findOrFail($this->tenant->requireId());
        $business->update($request->validated());

        return response()->json(['data' => ['name' => $business->name, 'currency' => $business->currency]]);
    }

    public function updateModules(UpdateModulesRequest $request): JsonResponse
    {
        Gate::authorize('settings.edit');

        foreach ($request->validated('modules') as $module => $enabled) {
            BusinessModule::query()->updateOrCreate(['module' => $module], ['enabled' => (bool) $enabled]);
        }

        return response()->json(['data' => BusinessModule::query()->pluck('enabled', 'module')]);
    }
}
