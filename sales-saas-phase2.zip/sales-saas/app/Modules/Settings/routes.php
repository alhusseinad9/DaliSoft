<?php

use App\Modules\Settings\Http\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;

Route::get('settings', [SettingsController::class, 'show'])->name('settings.show');
Route::patch('settings', [SettingsController::class, 'update'])->name('settings.update');
Route::patch('settings/modules', [SettingsController::class, 'updateModules'])->name('settings.modules');
