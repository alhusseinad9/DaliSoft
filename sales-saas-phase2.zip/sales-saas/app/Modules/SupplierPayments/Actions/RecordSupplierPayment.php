<?php

declare(strict_types=1);

namespace App\Modules\SupplierPayments\Actions;

use App\Core\Money\Money;
use App\Core\Sequences\SequenceService;
use App\Models\User;
use App\Modules\Purchasing\Models\PurchaseInvoice;
use App\Modules\SupplierPayments\Models\SupplierPayment;
use App\Modules\SupplierPayments\Models\SupplierPaymentAllocation;
use App\Modules\Suppliers\Models\Supplier;
use App\Modules\Suppliers\Models\SupplierLedgerEntry;
use Illuminate\Support\Facades\DB;

/** يسجّل دفعة لمورد ويوزّعها على فواتير الشراء الأقدم أولاً — مرآة RecordPayment بالضبط. */
final class RecordSupplierPayment
{
    public function __construct(private readonly SequenceService $sequences)
    {
    }

    public function handle(Supplier $supplier, string $amount, string $method, User $actor): SupplierPayment
    {
        return DB::transaction(function () use ($supplier, $amount, $method, $actor): SupplierPayment {
            $supplier = Supplier::query()->lockForUpdate()->findOrFail($supplier->id);

            $payment = SupplierPayment::create([
                'number' => $this->sequences->next('supplier_payment'),
                'supplier_id' => $supplier->id,
                'method' => $method,
                'amount' => $amount,
                'paid_at' => now(),
                'status' => 'posted',
                'created_by' => $actor->id,
            ]);

            $remaining = $amount;

            $invoices = PurchaseInvoice::query()
                ->where('supplier_id', $supplier->id)
                ->whereNotIn('status', ['void', 'paid'])
                ->where('due_amount', '>', 0)
                ->orderBy('issued_at')
                ->lockForUpdate()
                ->get();

            foreach ($invoices as $invoice) {
                if (Money::isZero($remaining)) {
                    break;
                }

                $due = (string) $invoice->due_amount;
                $apply = Money::min($due, $remaining);

                SupplierPaymentAllocation::create([
                    'supplier_payment_id' => $payment->id,
                    'purchase_invoice_id' => $invoice->id,
                    'amount' => $apply,
                ]);

                $newDue = Money::sub($due, $apply);
                $invoice->forceFill([
                    'paid_amount' => Money::add((string) $invoice->paid_amount, $apply),
                    'due_amount' => $newDue,
                    'status' => Money::isZero($newDue) ? 'paid' : 'partially_paid',
                ])->save();

                $remaining = Money::sub($remaining, $apply);
            }

            SupplierLedgerEntry::create([
                'supplier_id' => $supplier->id,
                'source_type' => 'supplier_payment',
                'source_id' => $payment->id,
                'description' => 'دفعة '.$payment->number,
                'debit' => $amount,
                'credit' => '0',
                'occurred_at' => now(),
                'created_by' => $actor->id,
            ]);
            // موجب = ندين أقل الآن (دفعنا)
            $supplier->forceFill(['balance' => Money::add((string) $supplier->balance, $amount)])->save();

            return $payment->fresh('allocations');
        });
    }
}
