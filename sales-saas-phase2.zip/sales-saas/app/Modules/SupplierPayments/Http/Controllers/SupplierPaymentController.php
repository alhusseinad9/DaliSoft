<?php

declare(strict_types=1);

namespace App\Modules\SupplierPayments\Http\Controllers;

use App\Modules\SupplierPayments\Actions\RecordSupplierPayment;
use App\Modules\SupplierPayments\Http\Requests\StoreSupplierPaymentRequest;
use App\Modules\SupplierPayments\Http\Resources\SupplierPaymentResource;
use App\Modules\SupplierPayments\Models\SupplierPayment;
use App\Modules\Suppliers\Models\Supplier;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\Gate;

final class SupplierPaymentController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        Gate::authorize('supplier_payments.view');

        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $payments = SupplierPayment::query()
            ->with('supplier:id,public_id,name,balance')
            ->orderByDesc('paid_at')
            ->cursorPaginate($perPage);

        return SupplierPaymentResource::collection($payments);
    }

    public function store(StoreSupplierPaymentRequest $request, RecordSupplierPayment $action): JsonResponse
    {
        Gate::authorize('supplier_payments.create');

        $supplier = Supplier::query()->findOrFail($request->validated('supplier_id'));

        $payment = $action->handle(
            $supplier,
            (string) $request->validated('amount'),
            (string) $request->validated('method'),
            $request->user(),
        );

        return SupplierPaymentResource::make($payment->load('supplier'))->response()->setStatusCode(201);
    }
}
