<?php

declare(strict_types=1);

namespace App\Modules\SupplierPayments\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreSupplierPaymentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'supplier_id' => ['required', 'integer', 'exists:suppliers,id'],
            'amount' => ['required', 'decimal:0,3', 'gt:0'],
            'method' => ['required', 'in:cash,transfer,card,other'],
        ];
    }
}
