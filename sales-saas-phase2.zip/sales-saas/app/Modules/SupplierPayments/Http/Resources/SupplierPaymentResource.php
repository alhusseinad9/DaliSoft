<?php

declare(strict_types=1);

namespace App\Modules\SupplierPayments\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

final class SupplierPaymentResource extends JsonResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'number' => $this->number,
            'supplier_id' => $this->supplier?->public_id,
            'supplier_name' => $this->supplier?->name,
            'amount' => $this->amount,
            'method' => $this->method,
            'paid_at' => $this->paid_at?->toIso8601String(),
            'unallocated_amount' => $this->unallocatedAmount(),
            'supplier_balance_after' => $this->supplier?->balance,
        ];
    }
}
