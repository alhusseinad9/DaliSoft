<?php

declare(strict_types=1);

namespace App\Modules\SupplierPayments\Models;

use App\Core\Money\Money;
use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Suppliers\Models\Supplier;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SupplierPayment extends Model
{
    use BelongsToBusiness, HasPublicId;

    protected $fillable = ['supplier_id', 'method', 'amount', 'paid_at', 'status', 'notes'];

    protected function casts(): array
    {
        return ['amount' => 'decimal:3', 'paid_at' => 'datetime'];
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function allocations(): HasMany
    {
        return $this->hasMany(SupplierPaymentAllocation::class);
    }

    public function unallocatedAmount(): string
    {
        $allocated = $this->allocations()->sum('amount');

        return Money::max(Money::sub((string) $this->amount, (string) $allocated), '0');
    }
}
