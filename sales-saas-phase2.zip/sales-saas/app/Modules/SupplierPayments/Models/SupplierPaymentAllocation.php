<?php

declare(strict_types=1);

namespace App\Modules\SupplierPayments\Models;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use App\Modules\Purchasing\Models\PurchaseInvoice;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SupplierPaymentAllocation extends Model
{
    use BelongsToBusiness;

    protected $table = 'supplier_payment_allocations';

    protected $fillable = ['supplier_payment_id', 'purchase_invoice_id', 'amount'];

    protected function casts(): array
    {
        return ['amount' => 'decimal:3'];
    }

    public function supplierPayment(): BelongsTo
    {
        return $this->belongsTo(SupplierPayment::class);
    }

    public function purchaseInvoice(): BelongsTo
    {
        return $this->belongsTo(PurchaseInvoice::class);
    }
}
