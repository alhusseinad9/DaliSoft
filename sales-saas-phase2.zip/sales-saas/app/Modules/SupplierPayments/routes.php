<?php

use App\Modules\SupplierPayments\Http\Controllers\SupplierPaymentController;
use Illuminate\Support\Facades\Route;

Route::get('supplier-payments', [SupplierPaymentController::class, 'index'])->name('supplier-payments.index');
Route::post('supplier-payments', [SupplierPaymentController::class, 'store'])->middleware('idempotent')->name('supplier-payments.store');
