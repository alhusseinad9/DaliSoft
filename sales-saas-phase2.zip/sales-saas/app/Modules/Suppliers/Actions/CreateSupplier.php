<?php

declare(strict_types=1);

namespace App\Modules\Suppliers\Actions;

use App\Core\Money\Money;
use App\Models\User;
use App\Modules\Suppliers\Models\Supplier;
use App\Modules\Suppliers\Models\SupplierLedgerEntry;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

final class CreateSupplier
{
    /** @param  array<string, mixed>  $data */
    public function handle(array $data, User $actor): Supplier
    {
        return DB::transaction(function () use ($data, $actor): Supplier {
            // مبلغ مستحق له علينا وقت الإنشاء (كما يُدخله المستخدم) يعني نحن مدينون له،
            // أي رصيد سالب بموجب اتجاهنا الموحّد — فيُخزَّن بإشارة معكوسة لـ opening_balance المُدخل.
            $owedToSupplier = Money::add($data['opening_balance'] ?? '0', '0');
            $balance = bcmul($owedToSupplier, '-1', Money::SCALE);

            $supplier = new Supplier(Arr::only($data, ['name', 'phone', 'address']));
            $supplier->forceFill([
                'opening_balance' => $owedToSupplier,
                'balance' => $balance,
                'created_by' => $actor->id,
            ])->save();

            if (! Money::isZero($owedToSupplier)) {
                SupplierLedgerEntry::create([
                    'supplier_id' => $supplier->id,
                    'source_type' => 'opening_balance',
                    'source_id' => $supplier->id,
                    'description' => 'رصيد افتتاحي',
                    'debit' => Money::isPositive($owedToSupplier) ? $owedToSupplier : '0',
                    'credit' => '0',
                    'occurred_at' => now(),
                    'created_by' => $actor->id,
                ]);
            }

            return $supplier;
        });
    }
}
