<?php

declare(strict_types=1);

namespace App\Modules\Suppliers\Http\Controllers;

use App\Modules\Suppliers\Actions\CreateSupplier;
use App\Modules\Suppliers\Http\Requests\StoreSupplierRequest;
use App\Modules\Suppliers\Http\Requests\UpdateSupplierRequest;
use App\Modules\Suppliers\Http\Resources\SupplierResource;
use App\Modules\Suppliers\Models\Supplier;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

final class SupplierController
{
    use AuthorizesRequests;

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Supplier::class);

        $term = trim((string) $request->query('q', ''));
        $perPage = max(1, min((int) $request->query('per_page', 25), 100));

        $suppliers = Supplier::query()
            ->when($term !== '', function ($query) use ($term): void {
                $like = '%'.addcslashes($term, '%_\\').'%';
                $query->where(fn ($w) => $w->where('name', 'ilike', $like)->orWhere('phone', 'like', $like));
            })
            ->orderBy('name')
            ->orderBy('id')
            ->cursorPaginate($perPage);

        return SupplierResource::collection($suppliers);
    }

    public function store(StoreSupplierRequest $request, CreateSupplier $action): JsonResponse
    {
        $this->authorize('create', Supplier::class);

        $supplier = $action->handle($request->validated(), $request->user());

        return SupplierResource::make($supplier)->response()->setStatusCode(201);
    }

    public function show(Supplier $supplier): SupplierResource
    {
        $this->authorize('view', $supplier);

        return SupplierResource::make($supplier);
    }

    public function update(UpdateSupplierRequest $request, Supplier $supplier): SupplierResource
    {
        $this->authorize('update', $supplier);

        $supplier->update($request->validated());

        return SupplierResource::make($supplier);
    }

    public function destroy(Supplier $supplier): Response|JsonResponse
    {
        $this->authorize('delete', $supplier);

        if (bccomp((string) $supplier->balance, '0', 3) !== 0) {
            return response()->json([
                'message' => 'لا يمكن حذف مورد عليه رصيد مستحق أو له رصيد عندنا.',
                'code' => 'supplier_has_balance',
            ], 422);
        }

        $supplier->delete();

        return response()->noContent();
    }
}
