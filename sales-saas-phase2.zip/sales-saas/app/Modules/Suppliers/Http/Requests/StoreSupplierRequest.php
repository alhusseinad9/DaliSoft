<?php

declare(strict_types=1);

namespace App\Modules\Suppliers\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class StoreSupplierRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:150'],
            'phone' => ['nullable', 'string', 'max:32', 'regex:/^[0-9+\-\s]{5,32}$/'],
            'address' => ['nullable', 'string', 'max:255'],
            // مبلغ مستحق للمورد علينا وقت الإنشاء (موجب دائماً من وجهة نظر المستخدم؛ الـ Action يحوّله للإشارة الداخلية الصحيحة)
            'opening_balance' => ['nullable', 'decimal:0,3', 'min:0', 'max:999999999999'],
        ];
    }
}
