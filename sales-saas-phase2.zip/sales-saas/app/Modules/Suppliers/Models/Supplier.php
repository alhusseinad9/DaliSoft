<?php

declare(strict_types=1);

namespace App\Modules\Suppliers\Models;

use App\Core\Audit\Auditable;
use App\Core\Support\HasPublicId;
use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * balance = مجموع (مدين − دائن) في supplier_ledger_entries، بنفس اتجاه رصيد العميل بالضبط:
 * موجب = المورد مدين لنا (نادر)، سالب = نحن مدينون له (الحالة الشائعة).
 * هذا الاتجاه الموحّد عمداً — كان أحد أكبر الأخطاء في النموذج الأولي (معاينة JS)
 * حين استُخدم اتجاه معكوس للمورد، فأنتج تسميات "عليه/له" بمعنى مقلوب تماماً.
 */
class Supplier extends Model
{
    use Auditable, BelongsToBusiness, HasPublicId, SoftDeletes;

    protected $fillable = ['name', 'phone', 'address'];

    protected function casts(): array
    {
        return [
            'opening_balance' => 'decimal:3',
            'balance' => 'decimal:3',
        ];
    }

    public function ledgerEntries(): HasMany
    {
        return $this->hasMany(SupplierLedgerEntry::class);
    }
}
