<?php

declare(strict_types=1);

namespace App\Modules\Suppliers\Models;

use App\Core\Tenancy\Concerns\BelongsToBusiness;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** قيد في كشف حساب المورد — Append-only (Trigger يمنع UPDATE/DELETE). التصحيح بقيد عكسي فقط. */
class SupplierLedgerEntry extends Model
{
    use BelongsToBusiness;

    public $timestamps = false;

    protected $fillable = [
        'supplier_id', 'source_type', 'source_id', 'description',
        'debit', 'credit', 'occurred_at', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'debit' => 'decimal:3',
            'credit' => 'decimal:3',
            'occurred_at' => 'datetime',
            'created_at' => 'datetime',
        ];
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }
}
