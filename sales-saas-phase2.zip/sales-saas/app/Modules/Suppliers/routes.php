<?php

use App\Modules\Suppliers\Http\Controllers\SupplierController;
use Illuminate\Support\Facades\Route;

// هذا الملف يُحمَّل داخل مجموعة: auth:sanctum + tenant (انظر routes/api.php)
Route::get('suppliers', [SupplierController::class, 'index'])->name('suppliers.index');
Route::post('suppliers', [SupplierController::class, 'store'])->middleware('idempotent')->name('suppliers.store');
Route::get('suppliers/{supplier}', [SupplierController::class, 'show'])->name('suppliers.show');
Route::patch('suppliers/{supplier}', [SupplierController::class, 'update'])->name('suppliers.update');
Route::delete('suppliers/{supplier}', [SupplierController::class, 'destroy'])->name('suppliers.destroy');
