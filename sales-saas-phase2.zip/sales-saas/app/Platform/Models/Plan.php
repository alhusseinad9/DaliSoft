<?php

declare(strict_types=1);

namespace App\Platform\Models;

use Illuminate\Database\Eloquent\Model;

/** خطة اشتراك — تُدار بالكامل من لوحة المنصة. limits مثال: {"max_users":3,"max_products":200,"modules":["inventory"]} */
class Plan extends Model
{
    protected $fillable = ['code', 'name', 'price', 'currency', 'duration_days', 'limits', 'is_active', 'is_public', 'sort'];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:3',
            'limits' => 'array',
            'is_active' => 'boolean',
            'is_public' => 'boolean',
        ];
    }
}
