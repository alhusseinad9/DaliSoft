<?php

declare(strict_types=1);

namespace App\Providers;

use App\Modules\Catalog\Models\Product;
use App\Modules\Catalog\Policies\ProductPolicy;
use App\Modules\Customers\Models\Customer;
use App\Modules\Customers\Policies\CustomerPolicy;
use App\Modules\Employees\Models\Employee;
use App\Modules\Employees\Policies\EmployeePolicy;
use App\Modules\Expenses\Models\Expense;
use App\Modules\Expenses\Policies\ExpensePolicy;
use App\Modules\Invoicing\Models\Invoice;
use App\Modules\Invoicing\Policies\InvoicePolicy;
use App\Modules\Payments\Models\Payment;
use App\Modules\Payments\Policies\PaymentPolicy;
use App\Modules\Purchasing\Models\PurchaseInvoice;
use App\Modules\Purchasing\Policies\PurchaseInvoicePolicy;
use App\Modules\Returns\Models\SalesReturn;
use App\Modules\Returns\Policies\SalesReturnPolicy;
use App\Modules\Suppliers\Models\Supplier;
use App\Modules\Suppliers\Policies\SupplierPolicy;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

/** تسجيل Policies كل Module. كل Module جديد يضيف سطره هنا. */
final class ModulesServiceProvider extends ServiceProvider
{
    /** @var array<class-string, class-string> */
    private array $policies = [
        Customer::class => CustomerPolicy::class,
        Supplier::class => SupplierPolicy::class,
        Invoice::class => InvoicePolicy::class,
        Payment::class => PaymentPolicy::class,
        PurchaseInvoice::class => PurchaseInvoicePolicy::class,
        SalesReturn::class => SalesReturnPolicy::class,
        Product::class => ProductPolicy::class,
        Expense::class => ExpensePolicy::class,
        Employee::class => EmployeePolicy::class,
    ];

    public function boot(): void
    {
        foreach ($this->policies as $model => $policy) {
            Gate::policy($model, $policy);
        }
    }
}
