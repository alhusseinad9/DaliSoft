<?php

declare(strict_types=1);

namespace App\Providers;

use App\Core\Tenancy\TenantContext;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\ServiceProvider;

final class TenancyServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // scoped: نسخة جديدة لكل طلب ولكل Job في الطابور
        $this->app->scoped(TenantContext::class);
    }

    public function boot(): void
    {
        $this->registerBlueprintMacros();
    }

    /** اختصارات موحّدة للـ Migrations حتى لا يُنسى business_id أو الـ Composite FK. */
    private function registerBlueprintMacros(): void
    {
        // عمود business_id مع FK إلى businesses
        Blueprint::macro('businessId', function () {
            /** @var Blueprint $this */
            return $this->foreignId('business_id')->constrained('businesses')->restrictOnDelete();
        });

        // UNIQUE (business_id, id): هدف للـ Composite FKs من الجداول الأخرى
        Blueprint::macro('tenantKey', function () {
            /** @var Blueprint $this */
            return $this->unique(['business_id', 'id']);
        });

        // FK مركّب (business_id, col) → parent(business_id, id): يستحيل الربط بسجل من نشاط آخر
        Blueprint::macro('tenantForeign', function (string $column, string $on, bool $nullable = false) {
            /** @var Blueprint $this */
            $definition = $this->unsignedBigInteger($column);

            if ($nullable) {
                $definition->nullable();
            }

            $this->foreign(['business_id', $column], "{$this->getTable()}_{$column}_tenant_fk")
                ->references(['business_id', 'id'])
                ->on($on)
                ->restrictOnDelete();

            return $definition;
        });

        Blueprint::macro('publicId', function () {
            /** @var Blueprint $this */
            return $this->ulid('public_id')->unique();
        });

        // المبالغ: 3 خانات عشرية (تدعم عملات مثل الدينار الليبي). لا float أبداً.
        Blueprint::macro('money', function (string $column) {
            /** @var Blueprint $this */
            return $this->decimal($column, 18, 3);
        });

        // الكميات: 3 خانات عشرية (كيلوغرام، لتر)
        Blueprint::macro('quantity', function (string $column) {
            /** @var Blueprint $this */
            return $this->decimal($column, 14, 3);
        });

        Blueprint::macro('createdBy', function (string $column = 'created_by') {
            /** @var Blueprint $this */
            return $this->foreignId($column)->nullable()->constrained('users')->nullOnDelete();
        });
    }
}
