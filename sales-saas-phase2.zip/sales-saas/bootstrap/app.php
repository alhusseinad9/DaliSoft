<?php

use App\Core\Http\Middleware\SecurityHeaders;
use App\Core\Idempotency\EnsureIdempotency;
use App\Core\Modules\EnsureModuleEnabled;
use App\Core\Tenancy\Exceptions\MissingTenantException;
use App\Core\Tenancy\Exceptions\TenantViolationException;
use App\Core\Tenancy\Middleware\ResolveTenant;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
        then: function (): void {
            Route::middleware('web')
                ->prefix('api/v1')
                ->name('api.')
                ->group(base_path('routes/api.php'));
        },
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'tenant' => ResolveTenant::class,
            'idempotent' => EnsureIdempotency::class,
            'module' => EnsureModuleEnabled::class,
        ]);

        $middleware->web(append: [SecurityHeaders::class]);

        // حاسم: تحديد النشاط قبل Route Model Binding، حتى يكون البحث عن {customer} محصوراً فيه.
        $middleware->prependToPriorityList(SubstituteBindings::class, ResolveTenant::class);

        $middleware->redirectGuestsTo(fn (Request $request) => $request->is('api/*') ? null : '/login');
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(fn (Request $request) => $request->is('api/*') || $request->expectsJson());

        $exceptions->render(fn (MissingTenantException $e) => response()->json([
            'message' => 'لم يتم تحديد النشاط التجاري.',
            'code' => 'business_not_selected',
        ], 403));

        $exceptions->render(fn (TenantViolationException $e) => response()->json([
            'message' => 'عملية غير مسموحة.',
            'code' => 'tenant_violation',
        ], 403));

        // لا نكشف اسم الـ Model أو المعرّف في رسالة 404
        $exceptions->render(function (NotFoundHttpException $e, Request $request) {
            if ($request->is('api/*')) {
                return response()->json(['message' => 'العنصر غير موجود.'], 404);
            }

            return null;
        });
    })
    ->create();
