<?php

return [
    'trial_plan' => env('SAAS_TRIAL_PLAN', 'trial'),
    'trial_days' => (int) env('SAAS_TRIAL_DAYS', 14),

    // حالة الـ Modules الافتراضية لأي نشاط جديد (يغيّرها صاحب النشاط من الإعدادات)
    'modules' => [
        'orders' => true,
        // مفعّلة افتراضياً: معظم الأنشطة الصغيرة (مخبز، محل، موزّع) تتوقع تتبع الكمية
        // من أول يوم؛ من لا يحتاجها (نشاط خدمي بحت) يطفئها بنفسه من الإعدادات.
        'inventory' => true,
        'expenses' => true,
        'employees' => false,
        // ملاحظة: الموردون وفواتير الشراء متاحة دائماً حالياً وليست مربوطة بهذا المفتاح بعد؛
        // هذا العلم محجوز لربطه لاحقاً إن احتجنا إخفاء وحدة الموردين بالكامل لنشاط لا يشتري من موردين.
        'suppliers' => false,
    ],

    'default_units' => ['قطعة', 'كرتونة', 'كيس', 'كيلوغرام', 'لتر', 'علبة'],

    'default_expense_categories' => ['وقود', 'نقل', 'رواتب', 'إيجار', 'صيانة', 'اتصالات', 'مشتريات', 'أخرى'],

    // بادئة الترقيم لكل نوع وثيقة
    'sequences' => [
        'invoice' => 'INV-',
        'payment' => 'PAY-',
        'order' => 'ORD-',
        'return' => 'RET-',
        'expense' => 'EXP-',
        'purchase_invoice' => 'PINV-',
        'supplier_payment' => 'SPAY-',
    ],
];
