<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('businesses', function (Blueprint $table) {
            $table->id();
            $table->publicId();
            $table->string('name', 150);
            $table->string('phone', 32)->nullable();
            $table->string('address')->nullable();
            $table->char('currency', 3);
            $table->string('timezone', 64);
            $table->string('logo_path')->nullable();
            $table->string('status', 20)->default('active');
            $table->jsonb('settings')->default('{}');
            $table->timestampsTz();
            $table->softDeletesTz();

            $table->index('status');
        });

        DB::statement("ALTER TABLE businesses ADD CONSTRAINT businesses_status_check CHECK (status IN ('active','suspended','closed'))");

        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained('businesses')->restrictOnDelete();
            $table->foreignId('plan_id')->constrained('plans')->restrictOnDelete();
            $table->string('status', 20);
            $table->timestampTz('starts_at');
            $table->timestampTz('ends_at');
            $table->timestampTz('grace_ends_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestampsTz();

            $table->index(['business_id', 'status']);
            $table->index(['status', 'ends_at']);
        });

        DB::statement("ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_status_check CHECK (status IN ('trial','active','past_due','expired','cancelled'))");
        DB::statement('ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_period_check CHECK (ends_at > starts_at)');
    }

    public function down(): void
    {
        Schema::dropIfExists('subscriptions');
        Schema::dropIfExists('businesses');
    }
};
