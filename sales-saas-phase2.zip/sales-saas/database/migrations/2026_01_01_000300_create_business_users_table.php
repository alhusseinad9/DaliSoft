<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('business_users', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->foreignId('user_id')->constrained('users')->restrictOnDelete();
            // employee_id يُضاف بعد إنشاء جدول employees
            $table->string('status', 20)->default('active');
            $table->timestampTz('joined_at')->nullable();
            $table->timestampsTz();

            $table->unique(['business_id', 'user_id']);
            $table->index(['user_id', 'status']);
        });

        DB::statement("ALTER TABLE business_users ADD CONSTRAINT business_users_status_check CHECK (status IN ('active','disabled'))");

        Schema::create('business_modules', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->string('module', 50);
            $table->boolean('enabled')->default(false);
            $table->timestampsTz();

            $table->unique(['business_id', 'module']);
        });

        Schema::create('document_sequences', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->string('type', 30);
            $table->string('prefix', 20)->default('');
            $table->unsignedBigInteger('next_number')->default(1);
            $table->unsignedSmallInteger('padding')->default(6);
            $table->timestampsTz();

            $table->unique(['business_id', 'type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('document_sequences');
        Schema::dropIfExists('business_modules');
        Schema::dropIfExists('business_users');
    }
};
