<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->string('name', 100);
            $table->unsignedSmallInteger('sort')->default(0);
            $table->timestampsTz();
            $table->softDeletesTz();

            $table->tenantKey();
            $table->index(['business_id', 'sort']);
        });

        Schema::create('units', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->string('name', 50);
            $table->boolean('is_system')->default(false);
            $table->timestampsTz();

            $table->tenantKey();
            $table->unique(['business_id', 'name']);
        });

        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->tenantForeign('category_id', 'categories', true);
            $table->tenantForeign('unit_id', 'units');
            $table->string('name', 150);
            $table->string('sku', 64)->nullable();
            $table->string('barcode', 64)->nullable();
            $table->money('sale_price')->default(0);
            $table->money('cost_price')->nullable();
            $table->string('image_path')->nullable();
            $table->boolean('is_active')->default(true);
            $table->boolean('track_stock')->default(true);
            $table->quantity('stock_qty')->default(0);   // Cache؛ مصدر الحقيقة stock_movements
            $table->quantity('min_stock')->nullable();
            $table->timestampsTz();
            $table->softDeletesTz();

            $table->tenantKey();
            $table->index(['business_id', 'name']);
            $table->index(['business_id', 'barcode']);
            $table->index(['business_id', 'category_id']);
            $table->index(['business_id', 'is_active']);
        });

        DB::statement('CREATE UNIQUE INDEX products_business_sku_unique ON products (business_id, sku) WHERE sku IS NOT NULL AND deleted_at IS NULL');
        DB::statement('ALTER TABLE products ADD CONSTRAINT products_prices_check CHECK (sale_price >= 0 AND (cost_price IS NULL OR cost_price >= 0))');
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
        Schema::dropIfExists('units');
        Schema::dropIfExists('categories');
    }
};
