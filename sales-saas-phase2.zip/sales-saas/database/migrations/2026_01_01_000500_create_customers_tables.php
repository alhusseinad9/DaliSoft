<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('name', 150);
            $table->string('phone', 32)->nullable();
            $table->string('address')->nullable();
            $table->string('area', 100)->nullable();
            $table->text('notes')->nullable();
            $table->money('opening_balance')->default(0);
            $table->money('credit_limit')->nullable();
            $table->money('balance')->default(0);   // Cache؛ مصدر الحقيقة customer_ledger_entries
            $table->createdBy();
            $table->timestampsTz();
            $table->softDeletesTz();

            $table->tenantKey();
            $table->index(['business_id', 'name']);
            $table->index(['business_id', 'phone']);
            $table->index(['business_id', 'area']);
        });

        DB::statement('ALTER TABLE customers ADD CONSTRAINT customers_credit_limit_check CHECK (credit_limit IS NULL OR credit_limit >= 0)');

        // كشف الحساب: موجب = على العميل (مدين)، سالب = له (دائن)
        Schema::create('customer_ledger_entries', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('customer_id', 'customers');
            $table->string('source_type', 40);   // opening_balance | invoice | invoice_void | payment | payment_void | return | adjustment
            $table->unsignedBigInteger('source_id')->nullable();
            $table->string('description')->nullable();
            $table->money('debit')->default(0);
            $table->money('credit')->default(0);
            $table->timestampTz('occurred_at');
            $table->createdBy();
            $table->timestampTz('created_at')->useCurrent();

            $table->index(['business_id', 'customer_id', 'occurred_at']);
            $table->index(['business_id', 'source_type', 'source_id']);
        });

        DB::statement('ALTER TABLE customer_ledger_entries ADD CONSTRAINT ledger_amounts_check CHECK (debit >= 0 AND credit >= 0 AND (debit > 0 OR credit > 0))');
    }

    public function down(): void
    {
        Schema::dropIfExists('customer_ledger_entries');
        Schema::dropIfExists('customers');
    }
};
