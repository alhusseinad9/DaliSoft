<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('name', 150);
            $table->string('phone', 32)->nullable();
            $table->string('job_title', 100)->nullable();
            $table->date('hired_at')->nullable();
            $table->money('salary')->nullable();
            $table->string('status', 20)->default('active');
            $table->timestampsTz();
            $table->softDeletesTz();

            $table->tenantKey();
            $table->index(['business_id', 'status']);
        });

        DB::statement("ALTER TABLE employees ADD CONSTRAINT employees_status_check CHECK (status IN ('active','inactive'))");

        // ربط حساب الدخول بسجل الموظف داخل نفس النشاط فقط
        Schema::table('business_users', function (Blueprint $table) {
            $table->tenantForeign('employee_id', 'employees', true);
            $table->unique(['business_id', 'employee_id']);
        });
    }

    public function down(): void
    {
        Schema::table('business_users', function (Blueprint $table) {
            $table->dropUnique(['business_id', 'employee_id']);
            $table->dropForeign('business_users_employee_id_tenant_fk');
            $table->dropColumn('employee_id');
        });

        Schema::dropIfExists('employees');
    }
};
