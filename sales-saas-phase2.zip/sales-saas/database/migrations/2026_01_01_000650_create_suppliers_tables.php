<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('suppliers', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('name', 150);
            $table->string('phone', 32)->nullable();
            $table->string('address')->nullable();
            $table->money('opening_balance')->default(0);
            // balance: موجب = المورد مدين لنا (نادر) | سالب = نحن مدينون له (الحالة الشائعة)
            // نفس اتجاه رصيد العميل بالضبط، حتى تصلح نفس التسمية ("عليه"/"له") للطرفين معاً.
            $table->money('balance')->default(0);
            $table->createdBy();
            $table->timestampsTz();
            $table->softDeletesTz();

            $table->tenantKey();
            $table->index(['business_id', 'name']);
            $table->index(['business_id', 'phone']);
        });

        // كشف حساب المورد — Append-only، بنفس منطق customer_ledger_entries تماماً
        Schema::create('supplier_ledger_entries', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('supplier_id', 'suppliers');
            $table->string('source_type', 40); // opening_balance | purchase_invoice | purchase_invoice_void | supplier_payment
            $table->unsignedBigInteger('source_id')->nullable();
            $table->string('description')->nullable();
            $table->money('debit')->default(0);
            $table->money('credit')->default(0);
            $table->timestampTz('occurred_at');
            $table->createdBy();
            $table->timestampTz('created_at')->useCurrent();

            $table->index(['business_id', 'supplier_id', 'occurred_at']);
            $table->index(['business_id', 'source_type', 'source_id']);
        });

        DB::statement('ALTER TABLE supplier_ledger_entries ADD CONSTRAINT supplier_ledger_amounts_check CHECK (debit >= 0 AND credit >= 0 AND (debit > 0 OR credit > 0))');
    }

    public function down(): void
    {
        Schema::dropIfExists('supplier_ledger_entries');
        Schema::dropIfExists('suppliers');
    }
};
