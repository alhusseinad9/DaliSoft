<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('number', 30);
            $table->tenantForeign('customer_id', 'customers');
            $table->string('status', 20)->default('new');
            $table->money('subtotal')->default(0);
            $table->money('discount')->default(0);
            $table->money('total')->default(0);
            $table->text('notes')->nullable();
            $table->timestampTz('ordered_at');
            $table->createdBy();
            $table->timestampsTz();
            $table->softDeletesTz();

            $table->tenantKey();
            $table->unique(['business_id', 'number']);
            $table->index(['business_id', 'status', 'ordered_at']);
            $table->index(['business_id', 'customer_id']);
        });

        DB::statement("ALTER TABLE orders ADD CONSTRAINT orders_status_check CHECK (status IN ('new','confirmed','preparing','ready','delivered','cancelled','returned'))");

        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('order_id', 'orders');
            $table->tenantForeign('product_id', 'products');
            $table->string('product_name', 150);    // لقطة وقت الطلب
            $table->string('unit_name', 50)->nullable();
            $table->quantity('qty');
            $table->money('unit_price');
            $table->money('discount')->default(0);
            $table->money('line_total');
            $table->timestampsTz();

            $table->index(['business_id', 'order_id']);
        });

        DB::statement('ALTER TABLE order_items ADD CONSTRAINT order_items_values_check CHECK (qty > 0 AND unit_price >= 0 AND discount >= 0 AND line_total >= 0)');
    }

    public function down(): void
    {
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('orders');
    }
};
