<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // الفاتورة الصادرة لا تُعدَّل ولا تُحذف: التصحيح بالإلغاء (void) أو بمرتجع.
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('number', 30);
            $table->tenantForeign('customer_id', 'customers', true);  // null = بيع نقدي لعميل عابر
            $table->tenantForeign('order_id', 'orders', true);
            $table->string('status', 20)->default('draft');
            $table->timestampTz('issued_at')->nullable();
            $table->money('subtotal')->default(0);
            $table->money('discount')->default(0);
            $table->money('tax')->default(0);
            $table->money('total')->default(0);
            $table->money('paid_amount')->default(0);
            $table->money('due_amount')->default(0);
            $table->money('cost_total')->default(0);    // لحساب الربح
            $table->text('notes')->nullable();
            $table->createdBy();
            $table->timestampTz('voided_at')->nullable();
            $table->createdBy('voided_by');
            $table->string('void_reason')->nullable();
            $table->timestampsTz();

            $table->tenantKey();
            $table->unique(['business_id', 'number']);
            $table->index(['business_id', 'issued_at']);
            $table->index(['business_id', 'customer_id', 'issued_at']);
            $table->index(['business_id', 'status']);
            $table->index(['business_id', 'created_by', 'issued_at']);
        });

        DB::statement("ALTER TABLE invoices ADD CONSTRAINT invoices_status_check CHECK (status IN ('draft','issued','partially_paid','paid','void'))");
        DB::statement('ALTER TABLE invoices ADD CONSTRAINT invoices_amounts_check CHECK (total >= 0 AND paid_amount >= 0 AND due_amount >= 0 AND discount >= 0 AND tax >= 0)');
        DB::statement("ALTER TABLE invoices ADD CONSTRAINT invoices_void_check CHECK (status <> 'void' OR (voided_at IS NOT NULL AND void_reason IS NOT NULL))");
        DB::statement('ALTER TABLE invoices ADD CONSTRAINT invoices_credit_needs_customer CHECK (due_amount = 0 OR customer_id IS NOT NULL)');
        DB::statement("CREATE UNIQUE INDEX invoices_business_order_unique ON invoices (business_id, order_id) WHERE order_id IS NOT NULL AND status <> 'void'");

        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('invoice_id', 'invoices');
            $table->tenantForeign('product_id', 'products', true);
            $table->string('product_name', 150);    // لقطة وقت البيع
            $table->string('unit_name', 50)->nullable();
            $table->quantity('qty');
            $table->money('unit_price');
            $table->money('unit_cost')->default(0);
            $table->money('discount')->default(0);
            $table->money('line_total');
            $table->timestampsTz();

            $table->tenantKey();
            $table->index(['business_id', 'invoice_id']);
            $table->index(['business_id', 'product_id']);
        });

        DB::statement('ALTER TABLE invoice_items ADD CONSTRAINT invoice_items_values_check CHECK (qty > 0 AND unit_price >= 0 AND discount >= 0 AND line_total >= 0)');
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
    }
};
