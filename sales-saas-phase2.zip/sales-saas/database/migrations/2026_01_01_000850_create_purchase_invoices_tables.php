<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('purchase_invoices', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('number', 30);
            $table->tenantForeign('supplier_id', 'suppliers', true); // null = مورد غير محدد
            $table->string('status', 20)->default('issued'); // issued | partially_paid | paid | void
            $table->timestampTz('issued_at');
            $table->money('total')->default(0);
            $table->money('paid_amount')->default(0);
            $table->money('due_amount')->default(0);
            $table->createdBy();
            $table->timestampTz('voided_at')->nullable();
            $table->createdBy('voided_by');
            $table->string('void_reason')->nullable();
            $table->timestampsTz();

            $table->tenantKey();
            $table->unique(['business_id', 'number']);
            $table->index(['business_id', 'issued_at']);
            $table->index(['business_id', 'supplier_id', 'issued_at']);
            $table->index(['business_id', 'status']);
        });

        DB::statement("ALTER TABLE purchase_invoices ADD CONSTRAINT purchase_invoices_status_check CHECK (status IN ('issued','partially_paid','paid','void'))");
        DB::statement('ALTER TABLE purchase_invoices ADD CONSTRAINT purchase_invoices_amounts_check CHECK (total >= 0 AND paid_amount >= 0 AND due_amount >= 0)');
        DB::statement("ALTER TABLE purchase_invoices ADD CONSTRAINT purchase_invoices_void_check CHECK (status <> 'void' OR (voided_at IS NOT NULL AND void_reason IS NOT NULL))");
        DB::statement('ALTER TABLE purchase_invoices ADD CONSTRAINT purchase_invoices_credit_needs_supplier CHECK (due_amount = 0 OR supplier_id IS NOT NULL)');

        Schema::create('purchase_invoice_items', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('purchase_invoice_id', 'purchase_invoices');
            $table->tenantForeign('product_id', 'products', true);
            $table->string('product_name', 150);  // لقطة وقت الشراء
            $table->quantity('qty');
            $table->money('unit_cost');
            $table->money('line_total');
            $table->timestampsTz();

            $table->tenantKey();
            $table->index(['business_id', 'purchase_invoice_id']);
            $table->index(['business_id', 'product_id']);
        });

        DB::statement('ALTER TABLE purchase_invoice_items ADD CONSTRAINT purchase_invoice_items_values_check CHECK (qty > 0 AND unit_cost >= 0 AND line_total >= 0)');

        // دفعة لمورد — قد تغطي أكثر من فاتورة شراء، بنفس منطق payment_allocations تماماً
        Schema::create('supplier_payments', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('number', 30);
            $table->tenantForeign('supplier_id', 'suppliers');
            $table->string('method', 20);
            $table->money('amount');
            $table->timestampTz('paid_at');
            $table->string('status', 20)->default('posted');
            $table->text('notes')->nullable();
            $table->createdBy();
            $table->timestampsTz();

            $table->tenantKey();
            $table->unique(['business_id', 'number']);
            $table->index(['business_id', 'paid_at']);
            $table->index(['business_id', 'supplier_id', 'paid_at']);
        });

        DB::statement("ALTER TABLE supplier_payments ADD CONSTRAINT supplier_payments_method_check CHECK (method IN ('cash','transfer','card','other'))");
        DB::statement("ALTER TABLE supplier_payments ADD CONSTRAINT supplier_payments_status_check CHECK (status IN ('posted','void'))");
        DB::statement('ALTER TABLE supplier_payments ADD CONSTRAINT supplier_payments_amount_check CHECK (amount > 0)');

        Schema::create('supplier_payment_allocations', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('supplier_payment_id', 'supplier_payments');
            $table->tenantForeign('purchase_invoice_id', 'purchase_invoices');
            $table->money('amount');
            $table->timestampsTz();

            $table->unique(['supplier_payment_id', 'purchase_invoice_id']);
            $table->index(['business_id', 'purchase_invoice_id']);
        });

        DB::statement('ALTER TABLE supplier_payment_allocations ADD CONSTRAINT supplier_payment_allocations_amount_check CHECK (amount > 0)');
    }

    public function down(): void
    {
        Schema::dropIfExists('supplier_payment_allocations');
        Schema::dropIfExists('supplier_payments');
        Schema::dropIfExists('purchase_invoice_items');
        Schema::dropIfExists('purchase_invoices');
    }
};
