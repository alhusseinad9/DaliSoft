<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('number', 30);
            $table->tenantForeign('customer_id', 'customers', true);
            $table->string('method', 20);
            $table->money('amount');
            $table->timestampTz('paid_at');
            $table->string('status', 20)->default('posted');
            $table->text('notes')->nullable();
            $table->createdBy();
            $table->timestampTz('voided_at')->nullable();
            $table->createdBy('voided_by');
            $table->string('void_reason')->nullable();
            $table->timestampsTz();

            $table->tenantKey();
            $table->unique(['business_id', 'number']);
            $table->index(['business_id', 'paid_at']);
            $table->index(['business_id', 'customer_id', 'paid_at']);
            $table->index(['business_id', 'created_by', 'paid_at']);
        });

        DB::statement("ALTER TABLE payments ADD CONSTRAINT payments_method_check CHECK (method IN ('cash','transfer','card','other'))");
        DB::statement("ALTER TABLE payments ADD CONSTRAINT payments_status_check CHECK (status IN ('posted','void'))");
        DB::statement('ALTER TABLE payments ADD CONSTRAINT payments_amount_check CHECK (amount > 0)');

        // دفعة واحدة يمكن أن تغطي أكثر من فاتورة
        Schema::create('payment_allocations', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('payment_id', 'payments');
            $table->tenantForeign('invoice_id', 'invoices');
            $table->money('amount');
            $table->timestampsTz();

            $table->unique(['payment_id', 'invoice_id']);
            $table->index(['business_id', 'invoice_id']);
        });

        DB::statement('ALTER TABLE payment_allocations ADD CONSTRAINT payment_allocations_amount_check CHECK (amount > 0)');
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_allocations');
        Schema::dropIfExists('payments');
    }
};
