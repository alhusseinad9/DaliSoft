<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sales_returns', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('number', 30);
            $table->tenantForeign('invoice_id', 'invoices');
            $table->tenantForeign('customer_id', 'customers', true);
            $table->timestampTz('returned_at');
            $table->money('total');
            $table->money('cost_total')->default(0);
            $table->string('refund_method', 20);    // credit = يخصم من رصيد العميل | cash = يُعاد نقداً
            $table->string('status', 20)->default('posted');
            $table->string('reason')->nullable();
            $table->createdBy();
            $table->timestampsTz();

            $table->tenantKey();
            $table->unique(['business_id', 'number']);
            $table->index(['business_id', 'returned_at']);
            $table->index(['business_id', 'invoice_id']);
        });

        DB::statement("ALTER TABLE sales_returns ADD CONSTRAINT sales_returns_refund_check CHECK (refund_method IN ('credit','cash'))");
        DB::statement("ALTER TABLE sales_returns ADD CONSTRAINT sales_returns_status_check CHECK (status IN ('posted','void'))");
        DB::statement('ALTER TABLE sales_returns ADD CONSTRAINT sales_returns_total_check CHECK (total > 0)');

        Schema::create('sales_return_items', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('sales_return_id', 'sales_returns');
            $table->tenantForeign('invoice_item_id', 'invoice_items');
            $table->tenantForeign('product_id', 'products', true);
            $table->quantity('qty');
            $table->money('unit_price');
            $table->money('line_total');
            $table->timestampsTz();

            $table->index(['business_id', 'sales_return_id']);
            $table->index(['business_id', 'invoice_item_id']);
        });

        DB::statement('ALTER TABLE sales_return_items ADD CONSTRAINT sales_return_items_qty_check CHECK (qty > 0)');
    }

    public function down(): void
    {
        Schema::dropIfExists('sales_return_items');
        Schema::dropIfExists('sales_returns');
    }
};
