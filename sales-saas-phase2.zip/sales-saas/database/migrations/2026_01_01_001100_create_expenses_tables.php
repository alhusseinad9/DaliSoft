<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('expense_categories', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->string('name', 100);
            $table->boolean('is_system')->default(false);
            $table->timestampsTz();

            $table->tenantKey();
            $table->unique(['business_id', 'name']);
        });

        Schema::create('expenses', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->publicId();
            $table->string('number', 30);
            $table->tenantForeign('category_id', 'expense_categories');
            $table->tenantForeign('employee_id', 'employees', true);
            $table->money('amount');
            $table->date('spent_at');
            $table->string('method', 20);
            $table->text('notes')->nullable();
            $table->string('status', 20)->default('posted');
            $table->createdBy();
            $table->timestampTz('voided_at')->nullable();
            $table->createdBy('voided_by');
            $table->string('void_reason')->nullable();
            $table->timestampsTz();

            $table->unique(['business_id', 'number']);
            $table->index(['business_id', 'spent_at']);
            $table->index(['business_id', 'category_id', 'spent_at']);
        });

        DB::statement("ALTER TABLE expenses ADD CONSTRAINT expenses_method_check CHECK (method IN ('cash','transfer','card','other'))");
        DB::statement("ALTER TABLE expenses ADD CONSTRAINT expenses_status_check CHECK (status IN ('posted','void'))");
        DB::statement('ALTER TABLE expenses ADD CONSTRAINT expenses_amount_check CHECK (amount > 0)');
    }

    public function down(): void
    {
        Schema::dropIfExists('expenses');
        Schema::dropIfExists('expense_categories');
    }
};
