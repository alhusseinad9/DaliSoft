<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // سجل حركة المخزون: Append-only. qty موجبة للإضافة وسالبة للخصم.
        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->businessId();
            $table->tenantForeign('product_id', 'products');
            $table->string('type', 20);
            $table->quantity('qty');
            $table->quantity('balance_after');
            $table->money('unit_cost')->nullable();
            $table->string('source_type', 40)->nullable();
            $table->unsignedBigInteger('source_id')->nullable();
            $table->string('notes')->nullable();
            $table->createdBy();
            $table->timestampTz('created_at')->useCurrent();

            $table->index(['business_id', 'product_id', 'created_at']);
            $table->index(['business_id', 'source_type', 'source_id']);
        });

        DB::statement("ALTER TABLE stock_movements ADD CONSTRAINT stock_movements_type_check CHECK (type IN ('opening','sale','sale_void','return','purchase','adjustment'))");
        DB::statement('ALTER TABLE stock_movements ADD CONSTRAINT stock_movements_qty_check CHECK (qty <> 0)');
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_movements');
    }
};
