<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * طبقة الحماية الأخيرة: Row Level Security في PostgreSQL.
 * حتى لو نسي مطوّر الـ Scope أو كتب استعلاماً خاماً (DB::table / raw SQL)،
 * لن يرى أو يكتب إلا صفوف النشاط المضبوط في app.business_id.
 *
 * - FORCE: تطبَّق السياسة حتى على مالك الجداول.
 * - إعداد غير مضبوط = NULL = لا صفوف (fail closed).
 * - فحوص الـ Foreign Keys في PostgreSQL لا تتأثر بـ RLS.
 * - مستثنى: business_users و idempotency_keys (يُستعلم عنهما قبل/خارج سياق النشاط وبشروط صريحة).
 */
return new class extends Migration
{
    /** @var list<string> */
    private array $tenantTables = [
        'business_modules', 'document_sequences',
        'categories', 'units', 'products',
        'customers', 'customer_ledger_entries',
        'suppliers', 'supplier_ledger_entries',
        'employees',
        'orders', 'order_items',
        'invoices', 'invoice_items',
        'payments', 'payment_allocations',
        'purchase_invoices', 'purchase_invoice_items',
        'supplier_payments', 'supplier_payment_allocations',
        'sales_returns', 'sales_return_items',
        'expense_categories', 'expenses',
        'stock_movements',
        'audit_logs',
    ];

    /** جداول لا يُسمح فيها إلا بالإضافة */
    private array $appendOnlyTables = [
        'customer_ledger_entries', 'supplier_ledger_entries', 'stock_movements', 'audit_logs',
    ];

    public function up(): void
    {
        DB::unprepared(<<<'SQL'
            CREATE OR REPLACE FUNCTION app_current_business_id() RETURNS bigint
            LANGUAGE sql STABLE AS $$
                SELECT NULLIF(current_setting('app.business_id', true), '')::bigint
            $$;

            CREATE OR REPLACE FUNCTION app_prevent_mutation() RETURNS trigger
            LANGUAGE plpgsql AS $$
            BEGIN
                RAISE EXCEPTION 'Table % is append-only', TG_TABLE_NAME USING ERRCODE = 'P0001';
            END
            $$;
        SQL);

        foreach ($this->tenantTables as $table) {
            DB::unprepared("
                ALTER TABLE {$table} ENABLE ROW LEVEL SECURITY;
                ALTER TABLE {$table} FORCE ROW LEVEL SECURITY;
                CREATE POLICY tenant_isolation ON {$table}
                    USING (business_id = app_current_business_id())
                    WITH CHECK (business_id = app_current_business_id());
            ");
        }

        foreach ($this->appendOnlyTables as $table) {
            DB::unprepared("
                CREATE TRIGGER {$table}_append_only
                BEFORE UPDATE OR DELETE ON {$table}
                FOR EACH ROW EXECUTE FUNCTION app_prevent_mutation();
            ");
        }
    }

    public function down(): void
    {
        foreach ($this->appendOnlyTables as $table) {
            DB::unprepared("DROP TRIGGER IF EXISTS {$table}_append_only ON {$table};");
        }

        foreach ($this->tenantTables as $table) {
            DB::unprepared("
                DROP POLICY IF EXISTS tenant_isolation ON {$table};
                ALTER TABLE {$table} NO FORCE ROW LEVEL SECURITY;
                ALTER TABLE {$table} DISABLE ROW LEVEL SECURITY;
            ");
        }

        DB::unprepared('DROP FUNCTION IF EXISTS app_prevent_mutation(); DROP FUNCTION IF EXISTS app_current_business_id();');
    }
};
