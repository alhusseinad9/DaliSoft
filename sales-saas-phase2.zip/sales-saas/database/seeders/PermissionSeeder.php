<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Core\Auth\PermissionRegistry;
use Illuminate\Database\Seeder;

final class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        PermissionRegistry::sync();
    }
}
