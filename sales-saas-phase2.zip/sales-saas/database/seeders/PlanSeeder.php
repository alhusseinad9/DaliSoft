<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Platform\Models\Plan;
use Illuminate\Database\Seeder;

/** قيم أولية فقط — الأسعار والحدود تُعدَّل لاحقاً من لوحة المنصة. */
final class PlanSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            ['code' => 'trial', 'name' => 'تجريبي', 'price' => 0, 'duration_days' => 14, 'is_public' => false, 'sort' => 0,
                'limits' => ['max_users' => 3, 'max_products' => 100, 'modules' => ['orders', 'inventory', 'expenses', 'employees']]],
            ['code' => 'basic', 'name' => 'Basic', 'price' => 0, 'duration_days' => 30, 'is_public' => true, 'sort' => 1,
                'limits' => ['max_users' => 1, 'max_products' => 200, 'modules' => ['orders', 'expenses']]],
            ['code' => 'business', 'name' => 'Business', 'price' => 0, 'duration_days' => 30, 'is_public' => true, 'sort' => 2,
                'limits' => ['max_users' => 5, 'max_products' => 2000, 'modules' => ['orders', 'inventory', 'expenses', 'employees']]],
            ['code' => 'pro', 'name' => 'Pro', 'price' => 0, 'duration_days' => 30, 'is_public' => true, 'sort' => 3,
                'limits' => ['max_users' => 20, 'max_products' => null, 'modules' => ['orders', 'inventory', 'expenses', 'employees', 'suppliers']]],
        ];

        foreach ($plans as $plan) {
            Plan::query()->updateOrCreate(
                ['code' => $plan['code']],
                $plan + ['currency' => env('SAAS_CURRENCY', 'LYD'), 'is_active' => true]
            );
        }
    }
}
