-- يُنفَّذ مرة واحدة كـ postgres (superuser) قبل أول migrate.
-- مهم: التطبيق لا يتصل أبداً بمستخدم Superuser، لأن Superuser يتجاوز RLS.

CREATE ROLE app_owner LOGIN PASSWORD 'change-me-owner' NOSUPERUSER NOBYPASSRLS NOCREATEROLE;
CREATE ROLE app_user  LOGIN PASSWORD 'change-me-user'  NOSUPERUSER NOBYPASSRLS NOCREATEROLE;

CREATE DATABASE sales_saas      OWNER app_owner;
CREATE DATABASE sales_saas_test OWNER app_owner;

\c sales_saas
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO app_user;

-- كل جدول ينشئه app_owner (عبر migrate) يصبح متاحاً لـ app_user تلقائياً
ALTER DEFAULT PRIVILEGES FOR ROLE app_owner IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;
ALTER DEFAULT PRIVILEGES FOR ROLE app_owner IN SCHEMA public
    GRANT USAGE, SELECT ON SEQUENCES TO app_user;
ALTER DEFAULT PRIVILEGES FOR ROLE app_owner IN SCHEMA public
    GRANT EXECUTE ON FUNCTIONS TO app_user;

-- المرحلة 4 (لوحة المنصة فقط، اتصال منفصل pgsql_platform):
-- CREATE ROLE app_platform LOGIN PASSWORD '...' NOSUPERUSER BYPASSRLS;
-- مع نفس DEFAULT PRIVILEGES أعلاه، وصلاحيات قراءة في الغالب.
