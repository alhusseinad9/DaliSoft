<?php

use App\Core\Auth\Http\AuthController;
use Illuminate\Support\Facades\Route;

/*
| كل مسارات /api/v1 تعمل ضمن مجموعة web (جلسة + CSRF) لأن الواجهة SPA على نفس النطاق.
| المصادقة عبر Sanctum SPA Cookie؛ لا Tokens في LocalStorage.
*/

Route::post('auth/login', [AuthController::class, 'login'])
    ->middleware('throttle:login')
    ->name('auth.login');

Route::middleware('auth:sanctum')->group(function (): void {
    Route::get('auth/me', [AuthController::class, 'me'])->name('auth.me');
    Route::post('auth/logout', [AuthController::class, 'logout'])->name('auth.logout');
    Route::post('auth/switch-business', [AuthController::class, 'switchBusiness'])->name('auth.switch');

    // كل ما بداخل هذه المجموعة محصور في النشاط الحالي
    Route::middleware(['tenant', 'throttle:api'])->group(function (): void {
        require app_path('Modules/Customers/routes.php');
        require app_path('Modules/Suppliers/routes.php');
        require app_path('Modules/Invoicing/routes.php');
        require app_path('Modules/Payments/routes.php');
        require app_path('Modules/Purchasing/routes.php');
        require app_path('Modules/SupplierPayments/routes.php');
        require app_path('Modules/Returns/routes.php');
        require app_path('Modules/Catalog/routes.php');
        require app_path('Modules/Inventory/routes.php');
        require app_path('Modules/Expenses/routes.php');
        require app_path('Modules/Employees/routes.php');
        require app_path('Modules/Reports/routes.php');
        require app_path('Modules/Settings/routes.php');
    });
});
