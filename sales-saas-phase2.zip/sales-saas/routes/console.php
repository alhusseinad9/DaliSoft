<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schedule;

// مفاتيح Idempotency لا حاجة لها بعد 24 ساعة
Schedule::call(fn () => DB::table('idempotency_keys')->where('created_at', '<', now()->subDay())->delete())
    ->hourly()
    ->name('prune-idempotency-keys')
    ->withoutOverlapping();

// المرحلة 5: النسخ الاحتياطي اليومي (spatie/laravel-backup)
// Schedule::command('backup:run --only-db')->dailyAt('02:00');
// Schedule::command('backup:clean')->dailyAt('03:00');
