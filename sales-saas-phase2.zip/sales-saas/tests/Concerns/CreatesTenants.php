<?php

declare(strict_types=1);

namespace Tests\Concerns;

use App\Core\Auth\PermissionRegistry;
use App\Core\Auth\ProvisionBusiness;
use App\Core\Tenancy\TenantContext;
use App\Models\Business;
use App\Models\BusinessUser;
use App\Models\User;
use App\Modules\Customers\Actions\CreateCustomer;
use App\Modules\Customers\Models\Customer;
use App\Modules\Catalog\Models\Product;
use App\Modules\Catalog\Models\Unit;
use App\Modules\Invoicing\Actions\IssueInvoice;
use App\Modules\Invoicing\Models\Invoice;
use App\Modules\Suppliers\Actions\CreateSupplier;
use App\Modules\Suppliers\Models\Supplier;
use Illuminate\Support\Str;
use Spatie\Permission\PermissionRegistrar;

trait CreatesTenants
{
    protected function setUpTenancy(): void
    {
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        PermissionRegistry::sync();
    }

    protected function makeUser(string $name = 'User'): User
    {
        return User::create([
            'name' => $name,
            'email' => Str::lower(Str::random(10)).'@example.test',
            'password' => 'Secret12345',
        ]);
    }

    /** @return array{0: Business, 1: User} */
    protected function makeBusiness(string $name = 'Business'): array
    {
        $owner = $this->makeUser("{$name} Owner");

        $business = app(ProvisionBusiness::class)->handle($owner, [
            'name' => $name,
            'currency' => 'LYD',
            'timezone' => 'Africa/Tripoli',
        ]);

        return [$business, $owner];
    }

    protected function addMember(Business $business, string $role): User
    {
        $user = $this->makeUser(ucfirst($role));

        BusinessUser::create([
            'business_id' => $business->id,
            'user_id' => $user->id,
            'status' => BusinessUser::STATUS_ACTIVE,
            'joined_at' => now(),
        ]);

        $this->inTenant($business, fn () => $user->assignRole($role));
        $user->unsetRelation('roles');

        return $user;
    }

    protected function asMember(User $user, Business $business): static
    {
        return $this->actingAs($user)->withSession(['current_business_id' => $business->id]);
    }

    protected function inTenant(Business $business, callable $callback): mixed
    {
        return app(TenantContext::class)->runAs($business->id, $callback);
    }

    protected function makeCustomer(Business $business, User $actor, array $data = []): Customer
    {
        return $this->inTenant($business, fn () => app(CreateCustomer::class)->handle(
            $data + ['name' => 'Customer '.Str::random(5)],
            $actor
        ));
    }

    protected function idempotencyHeader(): array
    {
        return ['Idempotency-Key' => (string) Str::ulid()];
    }

    protected function makeSupplier(Business $business, User $actor, array $data = []): Supplier
    {
        return $this->inTenant($business, fn () => app(CreateSupplier::class)->handle(
            $data + ['name' => 'Supplier '.Str::random(5)],
            $actor
        ));
    }

    /** منتج يتابع المخزون افتراضياً، بسعر وتكلفة بسيطين للحسابات في الاختبارات. */
    protected function makeProduct(Business $business, array $data = []): Product
    {
        return $this->inTenant($business, function () use ($data) {
            $unit = Unit::create(['name' => 'قطعة']);

            // stock_qty و min_stock عمداً غير قابلين للتعبئة الجماعية (BelongsToBusiness/$fillable)
            // حتى لا تتغير الكمية إلا عبر StockService مع أثر مسجَّل — فتُضبط هنا بعد الإنشاء مباشرة.
            $stockQty = $data['stock_qty'] ?? '100.000';
            $minStock = $data['min_stock'] ?? '0';
            unset($data['stock_qty'], $data['min_stock']);

            $product = Product::create($data + [
                'unit_id' => $unit->id,
                'name' => 'منتج '.Str::random(5),
                'sale_price' => '10.000',
                'cost_price' => '6.000',
                'is_active' => true,
                'track_stock' => true,
            ]);

            $product->forceFill(['stock_qty' => $stockQty, 'min_stock' => $minStock])->save();

            return $product->fresh();
        });
    }

    protected function issueInvoice(Business $business, User $actor, array $data): Invoice
    {
        return $this->inTenant($business, fn () => app(IssueInvoice::class)->handle($data, $actor));
    }
}
