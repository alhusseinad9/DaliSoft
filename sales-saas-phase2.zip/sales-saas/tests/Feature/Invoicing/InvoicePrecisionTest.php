<?php

declare(strict_types=1);

namespace Tests\Feature\Invoicing;

use App\Modules\Catalog\Models\Product;
use App\Modules\Customers\Models\Customer;
use App\Modules\Invoicing\Actions\IssueInvoice;
use App\Modules\Invoicing\Actions\VoidInvoice;
use App\Modules\Invoicing\Exceptions\CreditLimitExceededException;
use App\Modules\Inventory\Exceptions\InsufficientStockException;
use App\Modules\Payments\Actions\RecordPayment;
use App\Modules\Returns\Actions\CreateSalesReturn;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Tests\Concerns\CreatesTenants;
use Tests\TestCase;

/**
 * هذه الاختبارات تثبّت بالضبط المشاكل المحاسبية التي اكتُشفت ثم صُحِّحت أثناء
 * بناء المعاينة التفاعلية (JS) قبل ترجمتها لهذا الكود الحقيقي: التحصيل الذي
 * لا يرتبط بفاتورة محددة، والإلغاء الذي يُفقد أثر المبلغ المحصَّل، وتكلفة
 * الصنف التي لا تُحفظ وقت البيع. كل اختبار هنا يمنع عودة أحد هذه الأخطاء.
 */
final class InvoicePrecisionTest extends TestCase
{
    use CreatesTenants;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTenancy();
    }

    public function test_payment_allocates_to_oldest_invoice_first_and_updates_each_invoices_status(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $customer = $this->makeCustomer($business, $owner);

        $old = $this->issueInvoice($business, $owner, [
            'pay_way' => 'credit',
            'customer_id' => $customer->id,
            'items' => [['qty' => '1', 'unit_price' => '100']],
        ]);
        $old->forceFill(['issued_at' => now()->subDays(2)])->save();

        $new = $this->issueInvoice($business, $owner, [
            'pay_way' => 'credit',
            'customer_id' => $customer->id,
            'items' => [['qty' => '1', 'unit_price' => '50']],
        ]);
        $new->forceFill(['issued_at' => now()->subDay()])->save();

        // عميل دينه الإجمالي 150: ندفع 120 — يجب أن تُسدَّد الأقدم (100) بالكامل، والثانية جزئياً (20 من 50)
        $this->inTenant($business, function () use ($customer, $owner): void {
            $customer->refresh();
            app(RecordPayment::class)->handle($customer, '120', 'cash', $owner);
        });

        $old->refresh();
        $new->refresh();
        $customer->refresh();

        $this->assertSame('100.000', $old->paid_amount);
        $this->assertSame('0.000', $old->due_amount);
        $this->assertSame('paid', $old->status);

        $this->assertSame('20.000', $new->paid_amount);
        $this->assertSame('30.000', $new->due_amount);
        $this->assertSame('partially_paid', $new->status);

        $this->assertSame('30.000', $customer->balance); // 150 - 120 = 30 المتبقي عليه
    }

    public function test_payment_overflow_beyond_all_dues_becomes_unallocated_credit_not_lost(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $customer = $this->makeCustomer($business, $owner);

        $invoice = $this->issueInvoice($business, $owner, [
            'pay_way' => 'credit',
            'customer_id' => $customer->id,
            'items' => [['qty' => '1', 'unit_price' => '100']],
        ]);

        $payment = $this->inTenant($business, function () use ($customer, $owner) {
            $customer->refresh();

            // يدفع 150 على دين قدره 100 فقط
            return app(RecordPayment::class)->handle($customer, '150', 'cash', $owner);
        });

        $invoice->refresh();
        $customer->refresh();

        $this->assertSame('100.000', $invoice->paid_amount);
        $this->assertSame('0.000', $invoice->due_amount);
        $this->assertSame('50.000', $payment->unallocatedAmount(), 'الفائض 50 يجب أن يبقى محسوباً لا أن يضيع');
        $this->assertSame('-50.000', $customer->balance, 'رصيد العميل يصبح دائناً (له عندنا) بقيمة الفائض بالضبط');
    }

    public function test_void_preserves_the_true_paid_amount_and_can_credit_the_customer(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $customer = $this->makeCustomer($business, $owner);

        $invoice = $this->issueInvoice($business, $owner, [
            'pay_way' => 'cash_partial',
            'paid_amount' => '100',
            'customer_id' => $customer->id,
            'items' => [['qty' => '1', 'unit_price' => '150']],
        ]);

        $this->assertSame('100.000', $invoice->paid_amount);
        $this->assertSame('50.000', $invoice->due_amount);

        $customer->refresh();
        $this->assertSame('50.000', $customer->balance);

        $voided = $this->inTenant($business, fn () => app(VoidInvoice::class)->handle(
            $invoice->fresh(), $owner, 'العميل ألغى الطلب', creditCustomerForPaidAmount: true
        ));

        // النقطة الحرجة: paid_amount يبقى 100 كما هو تماماً — لا يُكتب فوقه أبداً
        $this->assertSame('100.000', $voided->paid_amount, 'المبلغ المحصَّل الحقيقي يجب أن يبقى محفوظاً بعد الإلغاء');
        $this->assertSame('void', $voided->status);

        $customer->refresh();
        // الدين (50) يُلغى + المحصَّل (100) يتحول لرصيد دائن = رصيد نهائي -100 (له عندنا 100)
        $this->assertSame('-100.000', $customer->balance);
    }

    public function test_void_without_crediting_the_paid_amount_leaves_it_as_cash_refund_outside_the_system(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $customer = $this->makeCustomer($business, $owner);

        $invoice = $this->issueInvoice($business, $owner, [
            'pay_way' => 'cash_partial',
            'paid_amount' => '100',
            'customer_id' => $customer->id,
            'items' => [['qty' => '1', 'unit_price' => '150']],
        ]);

        $voided = $this->inTenant($business, fn () => app(VoidInvoice::class)->handle(
            $invoice->fresh(), $owner, 'استرجاع نقدي', creditCustomerForPaidAmount: false
        ));

        $this->assertSame('100.000', $voided->paid_amount);

        $customer->refresh();
        // فقط الدين (50) يُلغى؛ الـ100 افتُرض أنها أُرجعت نقداً يدوياً، فلا تمسّ رصيد العميل
        $this->assertSame('0.000', $customer->balance);
    }

    public function test_invoice_item_keeps_its_cost_snapshot_even_after_product_cost_changes_later(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $product = $this->makeProduct($business, ['cost_price' => '6.000', 'sale_price' => '10.000']);

        $invoice = $this->issueInvoice($business, $owner, [
            'pay_way' => 'cash_full',
            'items' => [['product_id' => $product->id, 'qty' => '5', 'unit_price' => '10']],
        ]);

        $item = $invoice->items->first();
        $this->assertSame('6.000', $item->unit_cost);
        $this->assertSame('20.000', $invoice->estimatedProfit()); // 5 * (10 - 6)

        // تغيّرت تكلفة المنتج لاحقاً (فاتورة شراء جديدة بسعر أعلى)
        $this->inTenant($business, fn () => $product->forceFill(['cost_price' => '9.000'])->save());

        $invoice->refresh()->load('items');
        $this->assertSame('6.000', $invoice->items->first()->unit_cost, 'التكلفة المحفوظة بالفاتورة يجب ألا تتأثر');
        $this->assertSame('20.000', $invoice->estimatedProfit(), 'الربح التاريخي يجب أن يبقى محسوباً بتكلفة يوم البيع');
    }

    public function test_sales_return_cannot_exceed_the_remaining_sold_quantity(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $product = $this->makeProduct($business);

        $invoice = $this->issueInvoice($business, $owner, [
            'pay_way' => 'cash_full',
            'items' => [['product_id' => $product->id, 'qty' => '3', 'unit_price' => '10']],
        ]);
        $itemId = $invoice->items->first()->id;

        // مرتجع أول لكمية 2 — مقبول
        $this->inTenant($business, fn () => app(CreateSalesReturn::class)->handle(
            $invoice->fresh(), [['invoice_item_id' => $itemId, 'qty' => '2']], 'cash', null, $owner
        ));

        // محاولة إرجاع 2 إضافية (المتاح الآن 1 فقط) يجب أن ترفض
        $this->expectException(ValidationException::class);
        $this->inTenant($business, fn () => app(CreateSalesReturn::class)->handle(
            $invoice->fresh(), [['invoice_item_id' => $itemId, 'qty' => '2']], 'cash', null, $owner
        ));
    }

    public function test_credit_limit_exceeded_is_blocked_unless_explicitly_overridden(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $customer = $this->makeCustomer($business, $owner, ['credit_limit' => '50']);

        $this->expectException(CreditLimitExceededException::class);
        $this->issueInvoice($business, $owner, [
            'pay_way' => 'credit',
            'customer_id' => $customer->id,
            'items' => [['qty' => '1', 'unit_price' => '100']],
        ]);
    }

    public function test_credit_limit_override_flag_allows_the_sale_through(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $customer = $this->makeCustomer($business, $owner, ['credit_limit' => '50']);

        $invoice = $this->issueInvoice($business, $owner, [
            'pay_way' => 'credit',
            'customer_id' => $customer->id,
            'override_credit_limit' => true,
            'items' => [['qty' => '1', 'unit_price' => '100']],
        ]);

        $this->assertSame('100.000', $invoice->due_amount);
    }

    public function test_selling_more_than_available_stock_is_blocked_unless_explicitly_allowed(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $product = $this->makeProduct($business, ['stock_qty' => '2']);

        $this->expectException(InsufficientStockException::class);
        $this->issueInvoice($business, $owner, [
            'pay_way' => 'cash_full',
            'items' => [['product_id' => $product->id, 'qty' => '5', 'unit_price' => '10']],
        ]);
    }

    public function test_allow_negative_stock_flag_lets_the_sale_through_and_logs_it(): void
    {
        [$business, $owner] = $this->makeBusiness();
        $product = $this->makeProduct($business, ['stock_qty' => '2']);

        $this->issueInvoice($business, $owner, [
            'pay_way' => 'cash_full',
            'allow_negative_stock' => true,
            'items' => [['product_id' => $product->id, 'qty' => '5', 'unit_price' => '10']],
        ]);

        $product->refresh();
        $this->assertSame('-3.000', $product->stock_qty);
    }
}
