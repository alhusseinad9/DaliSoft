<?php

declare(strict_types=1);

namespace Tests\Feature\TenantIsolation;

use App\Models\BusinessUser;
use App\Modules\Customers\Models\Customer;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\CreatesTenants;
use Tests\TestCase;

/** عزل البيانات عبر الـ API: مستخدم نشاط A لا يرى ولا يعدّل ولا يحذف بيانات نشاط B. */
final class CustomerApiIsolationTest extends TestCase
{
    use CreatesTenants;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTenancy();
    }

    public function test_listing_returns_only_current_business_customers(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        [$bizB, $ownerB] = $this->makeBusiness('B');

        $mine = $this->makeCustomer($bizA, $ownerA, ['name' => 'عميل A']);
        $this->makeCustomer($bizB, $ownerB, ['name' => 'عميل B']);

        $this->asMember($ownerA, $bizA)
            ->getJson('/api/v1/customers')
            ->assertOk()
            ->assertJsonCount(1, 'data')
            ->assertJsonPath('data.0.id', $mine->public_id)
            ->assertJsonMissingPath('data.0.business_id');
    }

    public function test_cannot_view_update_or_delete_other_business_customer(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        [$bizB, $ownerB] = $this->makeBusiness('B');
        $foreign = $this->makeCustomer($bizB, $ownerB, ['name' => 'Original']);

        $client = $this->asMember($ownerA, $bizA);

        $client->getJson("/api/v1/customers/{$foreign->public_id}")->assertNotFound();
        $client->patchJson("/api/v1/customers/{$foreign->public_id}", ['name' => 'Hacked'])->assertNotFound();
        $client->deleteJson("/api/v1/customers/{$foreign->public_id}")->assertNotFound();

        $this->inTenant($bizB, function () use ($foreign): void {
            $fresh = Customer::query()->findOrFail($foreign->id);
            $this->assertSame('Original', $fresh->name);
            $this->assertNull($fresh->deleted_at);
        });
    }

    public function test_business_id_in_payload_is_ignored(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        [$bizB] = $this->makeBusiness('B');

        $this->asMember($ownerA, $bizA)
            ->postJson('/api/v1/customers', ['name' => 'X', 'business_id' => $bizB->id], $this->idempotencyHeader())
            ->assertCreated();

        $this->assertSame(1, $this->inTenant($bizA, fn () => Customer::query()->count()));
        $this->assertSame(0, $this->inTenant($bizB, fn () => Customer::query()->count()));
    }

    public function test_user_cannot_select_business_they_do_not_belong_to(): void
    {
        [$bizA] = $this->makeBusiness('A');
        [, $ownerB] = $this->makeBusiness('B');

        $this->asMember($ownerB, $bizA)
            ->getJson('/api/v1/customers')
            ->assertForbidden()
            ->assertJsonPath('code', 'business_access_denied');
    }

    public function test_switch_business_rejects_foreign_business(): void
    {
        [$bizA] = $this->makeBusiness('A');
        [$bizB, $ownerB] = $this->makeBusiness('B');

        $this->asMember($ownerB, $bizB)
            ->postJson('/api/v1/auth/switch-business', ['business' => $bizA->public_id])
            ->assertForbidden();
    }

    public function test_guest_and_missing_business_are_rejected(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');

        $this->getJson('/api/v1/customers')->assertUnauthorized();

        $this->actingAs($ownerA)
            ->getJson('/api/v1/customers')
            ->assertForbidden()
            ->assertJsonPath('code', 'business_not_selected');
    }

    public function test_permissions_are_enforced_in_backend(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        $sales = $this->addMember($bizA, 'sales');
        $customer = $this->makeCustomer($bizA, $ownerA);

        $this->asMember($sales, $bizA)
            ->postJson('/api/v1/customers', ['name' => 'جديد'], $this->idempotencyHeader())
            ->assertCreated();

        $this->asMember($sales, $bizA)
            ->deleteJson("/api/v1/customers/{$customer->public_id}")
            ->assertForbidden();
    }

    public function test_role_in_one_business_does_not_leak_to_another(): void
    {
        [, $ownerA] = $this->makeBusiness('A');
        [$bizB, $ownerB] = $this->makeBusiness('B');

        // مالك النشاط A يُضاف إلى النشاط B كمندوب مبيعات فقط
        BusinessUser::create([
            'business_id' => $bizB->id,
            'user_id' => $ownerA->id,
            'status' => BusinessUser::STATUS_ACTIVE,
            'joined_at' => now(),
        ]);
        $this->inTenant($bizB, fn () => $ownerA->assignRole('sales'));
        $ownerA->unsetRelation('roles');

        $customerInB = $this->makeCustomer($bizB, $ownerB);

        $this->asMember($ownerA, $bizB)
            ->deleteJson("/api/v1/customers/{$customerInB->public_id}")
            ->assertForbidden();
    }

    public function test_cannot_delete_customer_with_balance(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        $customer = $this->makeCustomer($bizA, $ownerA, ['opening_balance' => '150.500']);

        $this->asMember($ownerA, $bizA)
            ->deleteJson("/api/v1/customers/{$customer->public_id}")
            ->assertStatus(422)
            ->assertJsonPath('code', 'customer_has_balance');
    }

    public function test_idempotency_prevents_duplicate_creation(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        $headers = $this->idempotencyHeader();

        $first = $this->asMember($ownerA, $bizA)->postJson('/api/v1/customers', ['name' => 'مرة واحدة'], $headers)->assertCreated();
        $second = $this->asMember($ownerA, $bizA)->postJson('/api/v1/customers', ['name' => 'مرة واحدة'], $headers)->assertCreated();

        $second->assertHeader('Idempotent-Replay', 'true');
        $this->assertSame($first->json('data.id'), $second->json('data.id'));
        $this->assertSame(1, $this->inTenant($bizA, fn () => Customer::query()->count()));

        $this->asMember($ownerA, $bizA)
            ->postJson('/api/v1/customers', ['name' => 'بيانات أخرى'], $headers)
            ->assertStatus(422)
            ->assertJsonPath('code', 'idempotency_key_reused');
    }
}
