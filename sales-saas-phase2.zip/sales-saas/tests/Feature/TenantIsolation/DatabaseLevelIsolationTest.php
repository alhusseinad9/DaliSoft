<?php

declare(strict_types=1);

namespace Tests\Feature\TenantIsolation;

use App\Core\Sequences\SequenceService;
use App\Core\Tenancy\Exceptions\MissingTenantException;
use App\Core\Tenancy\Exceptions\TenantViolationException;
use App\Modules\Customers\Models\Customer;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\Concerns\CreatesTenants;
use Tests\TestCase;

/**
 * العزل على مستوى Eloquent وعلى مستوى PostgreSQL (RLS + Composite FKs + Triggers).
 * هذه الاختبارات تتجاوز الـ Global Scope عمداً لتثبت أن قاعدة البيانات نفسها تحمي البيانات.
 */
final class DatabaseLevelIsolationTest extends TestCase
{
    use CreatesTenants;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTenancy();
    }

    private function requireRlsEnforced(): void
    {
        $role = DB::selectOne('select rolsuper, rolbypassrls from pg_roles where rolname = current_user');

        if ($role->rolsuper || $role->rolbypassrls) {
            $this->markTestSkipped('مستخدم قاعدة البيانات Superuser أو يملك BYPASSRLS؛ RLS لا يُطبَّق عليه. استخدم app_owner (انظر docs/sql/roles.sql).');
        }
    }

    public function test_eloquent_query_without_tenant_fails_closed(): void
    {
        $this->expectException(MissingTenantException::class);

        Customer::query()->count();
    }

    public function test_cannot_create_record_for_another_business(): void
    {
        [$bizA] = $this->makeBusiness('A');
        [$bizB] = $this->makeBusiness('B');

        $this->expectException(TenantViolationException::class);

        $this->inTenant($bizA, function () use ($bizB): void {
            $customer = new Customer(['name' => 'X']);
            $customer->forceFill(['business_id' => $bizB->id])->save();
        });
    }

    public function test_cannot_move_record_to_another_business(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        [$bizB] = $this->makeBusiness('B');
        $customer = $this->makeCustomer($bizA, $ownerA);

        $this->expectException(TenantViolationException::class);

        $this->inTenant($bizA, function () use ($customer, $bizB): void {
            $customer->forceFill(['business_id' => $bizB->id])->save();
        });
    }

    public function test_rls_hides_other_business_rows_even_for_raw_queries(): void
    {
        $this->requireRlsEnforced();

        [$bizA, $ownerA] = $this->makeBusiness('A');
        [$bizB] = $this->makeBusiness('B');
        $this->makeCustomer($bizA, $ownerA);

        $this->assertSame(1, $this->inTenant($bizA, fn () => DB::table('customers')->count()));
        $this->assertSame(0, $this->inTenant($bizB, fn () => DB::table('customers')->count()));
        $this->assertSame(0, $this->inTenant($bizB, fn () => Customer::withoutGlobalScopes()->count()));

        // بلا نشاط محدد: لا شيء
        $this->assertSame(0, DB::table('customers')->count());
    }

    public function test_rls_rejects_inserting_rows_for_another_business(): void
    {
        $this->requireRlsEnforced();

        [$bizA] = $this->makeBusiness('A');
        [$bizB] = $this->makeBusiness('B');

        $error = $this->captureQueryException(fn () => $this->inTenant($bizB, fn () => DB::transaction(
            fn () => DB::table('customers')->insert([
                'business_id' => $bizA->id,
                'public_id' => (string) Str::ulid(),
                'name' => 'Injected',
                'created_at' => now(),
                'updated_at' => now(),
            ])
        )));

        $this->assertSame('42501', $error->getCode()); // insufficient_privilege: new row violates row-level security policy
    }

    public function test_composite_foreign_key_blocks_cross_tenant_references(): void
    {
        [$bizA] = $this->makeBusiness('A');
        [$bizB, $ownerB] = $this->makeBusiness('B');
        $foreignCustomer = $this->makeCustomer($bizB, $ownerB);

        // قيد في دفتر النشاط A يشير إلى عميل من النشاط B
        $error = $this->captureQueryException(fn () => $this->inTenant($bizA, fn () => DB::transaction(
            fn () => DB::table('customer_ledger_entries')->insert([
                'business_id' => $bizA->id,
                'customer_id' => $foreignCustomer->id,
                'source_type' => 'adjustment',
                'debit' => '10.000',
                'credit' => '0',
                'occurred_at' => now(),
            ])
        )));

        $this->assertSame('23503', $error->getCode()); // foreign_key_violation
    }

    public function test_ledger_is_append_only(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        $customer = $this->makeCustomer($bizA, $ownerA, ['opening_balance' => '100']);

        $error = $this->captureQueryException(fn () => $this->inTenant($bizA, fn () => DB::transaction(
            fn () => DB::table('customer_ledger_entries')->where('customer_id', $customer->id)->update(['debit' => '1'])
        )));

        $this->assertSame('P0001', $error->getCode());
    }

    public function test_opening_balance_is_recorded_in_ledger(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        $customer = $this->makeCustomer($bizA, $ownerA, ['opening_balance' => '-25.250']);

        $this->inTenant($bizA, function () use ($customer): void {
            $entry = $customer->ledgerEntries()->sole();
            $this->assertSame('0.000', $entry->debit);
            $this->assertSame('25.250', $entry->credit);
            $this->assertSame('-25.250', $customer->fresh()->balance);
        });
    }

    public function test_document_numbers_are_sequential_per_business(): void
    {
        [$bizA] = $this->makeBusiness('A');
        [$bizB] = $this->makeBusiness('B');
        $sequences = app(SequenceService::class);

        $a = $this->inTenant($bizA, fn () => DB::transaction(fn () => [$sequences->next('invoice'), $sequences->next('invoice')]));
        $b = $this->inTenant($bizB, fn () => DB::transaction(fn () => $sequences->next('invoice')));

        $this->assertSame(['INV-000001', 'INV-000002'], $a);
        $this->assertSame('INV-000001', $b);
    }

    private function captureQueryException(callable $callback): QueryException
    {
        try {
            $callback();
        } catch (QueryException $e) {
            return $e;
        }

        $this->fail('Expected a QueryException, none was thrown.');
    }
}
