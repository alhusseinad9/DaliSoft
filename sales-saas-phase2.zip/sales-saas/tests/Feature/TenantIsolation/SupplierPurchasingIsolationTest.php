<?php

declare(strict_types=1);

namespace Tests\Feature\TenantIsolation;

use App\Modules\Purchasing\Actions\IssuePurchaseInvoice;
use App\Modules\Purchasing\Models\PurchaseInvoice;
use App\Modules\Suppliers\Models\Supplier;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\CreatesTenants;
use Tests\TestCase;

/** يثبّت أن وحدتي الموردين والمشتريات الجديدتين تخضعان لنفس عزل الأنشطة المطبّق على بقية النظام. */
final class SupplierPurchasingIsolationTest extends TestCase
{
    use CreatesTenants;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->setUpTenancy();
    }

    public function test_supplier_and_purchase_invoice_are_invisible_from_another_business(): void
    {
        [$bizA, $ownerA] = $this->makeBusiness('A');
        [$bizB, $ownerB] = $this->makeBusiness('B');

        $supplierA = $this->makeSupplier($bizA, $ownerA);
        $productA = $this->makeProduct($bizA);

        $purchaseA = $this->inTenant($bizA, fn () => app(IssuePurchaseInvoice::class)->handle([
            'supplier_id' => $supplierA->id,
            'pay_way' => 'credit',
            'items' => [['product_id' => $productA->id, 'qty' => '10', 'unit_cost' => '5']],
        ], $ownerA));

        $this->assertSame(0, $this->inTenant($bizB, fn () => Supplier::query()->count()));
        $this->assertSame(0, $this->inTenant($bizB, fn () => PurchaseInvoice::query()->count()));

        $this->assertSame(1, $this->inTenant($bizA, fn () => Supplier::query()->count()));
        $this->assertSame('-50.000', $supplierA->fresh()->balance, 'المورد يصبح مستحقاً له 50 (نحن مدينون له)');
    }
}
